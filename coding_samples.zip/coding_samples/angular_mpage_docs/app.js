// ISSUES WITH DATE PICKER - date picker hack takes day num and adds +1 to number.
// This addresses TimeZone issues. However, when beginning of month is selected,
// the previous month end-date has an extra day added to month/
// ( e.g. selected date 11/01 - printed date 10/32 ). Might need to convert to ui.jquery datepicker.

var app = angular.module('docs',['mpages']);

//alert(window.external.MPAGESOVERRIDEPRINT);

app.controller('main',function($scope,mpages,$filter,$timeout){

/*=======================================
/*			Global Vars
/*=====================================*/
/*
	$scope.person_id = 59794727;
	$scope.encntr_id = 57652658;
	$scope.person_id2 = 69987038;
	$scope.encntr_id2 = 68707280;
*/

	//$scope.person_id;
	//$scope.encntr_id = 0;
	$scope.lookbackDate = "";
	$scope.eventStart = "";
	$scope.orderStart = "";

	$scope.searchParams = 1;

	$scope.numOfResults = 1;

		$scope.globalDropDownObj = {
		showCatalogTypesDropDown:false,
		showActivityTypesDropDown:false,
		showCatalogDropDown:false,
		showOrderStatusesDropDown:false,
		showDeptStatusesDropDown:false,
		showDispClinCatDropDown:false,
		showEncntrTypeDropDown:false,
		showEncntrTypeClassDropDown:false,
		showMedServDropDown:false,
		showformSearchDropDown:false,
		showResultsDropDown:false,
		showNurseUnitDropDown:false
	}

$scope.test = function(x){ console.log(x); }

/*========================================
/*			Helper Functions
/*======================================*/

	// Number of returned values vs. Returned values by given date //
	// Must be used in conjunction with ng-change.
	// ng-change="setNum()" should be placed on a form's number of results field

	$scope.setNum = function() {
		if ( $scope.numOfResults > 0 )
			{
				//alert($scope.numOfResults);
				$scope.searchParams = $scope.numOfResults;
				$scope.lookbackDate = "";
			}
	}


	// ng-change="setDate()" should be placed on form's date lookbackDate field
	$scope.setDate = function() {
		if ( $scope.lookbackDate != "" )
			{
				var date = formatDate($filter('date')(new Date($scope.lookbackDate), 'dd-MMM-yyyy'));
				//date = "'"+date.toUpperCase()+"'";
				//alert(date);
				$scope.searchParams = date;
				$scope.numOfResults = 0;
			}
	}

	$scope.orderDate = function() {

				if ($scope.orderStart !=""){
				//console.log(eventStart);
				var date = formatDate($filter('date')(new Date($scope.orderStart), 'dd-MMM-yyyy'));
				//date = "'"+date.toUpperCase()+"'";
				//alert(date);
				$scope.eventStart = date;
				}
				else
					$scope.eventStart = "";



	}

	$scope.encStartDate = function(){

				var date =  formatDate($filter('date')(new Date($scope.encntrStartDP), 'dd-MMM-yyyy'));
				$scope.encntrStart = date;


	}

	$scope.encEndDate = function(){

				var date = formatDate($filter('date')(new Date($scope.encntrEndDP), 'dd-MMM-yyyy'));
				$scope.encntrEnd =  date;


	}


	function formatDate(dateStr){
		var dateArray = [];
		dateArray = dateStr.split("-");
		//console.log(dateArray);
		dateArray[0] = parseInt(dateArray[0])+1;
		dateStr = dateArray.join("-");
		return dateStr.toUpperCase();
	}

	function convertDate(x){
		x = $filter('date')(new Date(x), 'dd-MMM-yyyy');
	}

	$scope.timeout = {};

	$scope.codeValueSearch = function(codeSet, queryTerm, recName){
		if ( !angular.isDefined(queryTerm) || queryTerm.length <= 3)
			{ return; }
		else if (queryTerm.length >= 3){
			if ($scope.timeout.promise){$timeout.cancel($scope.timeout.promise);}
			$scope.timeout.promise = $timeout(function(){
				mpages.loadCCL({
					recordName: recName,
					scriptName: 'nmh_get_search_code_values',
					prompts: [codeSet,queryTerm.replace(/ /,'')]
				});
			},500)
		}

	};

	$scope.codeSetSearch = function(queryTerm, recName){

			mpages.loadCCL({
				recordName: recName,
				scriptName: 'nmh_get_search_code_sets',
				prompts: [queryTerm.replace(/ /,'')]
			});


	};




	$scope.resetGlobalDropDown = function(event){
		var where = angular.element(event.target);
		for ( var dropDowns in $scope.globalDropDownObj )
			{$scope.globalDropDownObj[dropDowns] = false;}

	}


/*===============================
/* 		loadCCL scripts
/*=============================*/



	$scope.getCodeSets = function(){
		mpages.loadCCL({
			recordName: 'codeSets',
			scriptName: 'nmh_get_search_code_sets',
			prompts: [ $scope.codeSets ]
		});
	}

	$scope.patientSearch = function(){
		mpages.loadCCL({
			recordName: 'patientSearch',
			scriptName: "nmh_get_patients_by_"+$scope.ng_code_type,
			prompts: ["MINE",$scope.patientQuery]
		});
	};

	$scope.pullDemographics = function(){
		mpages.loadCCL({
			recordName: 'patientDemographics',
			scriptName: 'nmh_get_patient_demographics',
			prompts: ['','',$scope.person_id,$scope.encntr_id]
		});
	};

	$scope.problemsDiagnoses = function(){
		mpages.loadCCL({
			recordName: 'patientProblems',
			scriptName: 'nmh_get_diagnoses_problems',
			prompts: ['','',$scope.person_id,$scope.encntr_id]
		});
	};

	$scope.notes = function(){
		mpages.loadCCL({
			recordName: 'notes',
			scriptName: 'nmh_get_notes',
			prompts: ['',$scope.person_id,$scope.encntr_id,'','','','']
		});
	};

/* CLINICAL EVENTS */
/* P_ID, E_ID, PARENT_EVENTS, EVENTS, EVENT_START */

	//$scope.event = 'Pulse|Respiration';
	$scope.event_codes = "";

	$scope.clinicalEvents = function(){
		mpages.loadCCL({
			recordName:'clinicalEvents',
			scriptName:'nmh_get_clinical_event_data',
			prompts: [ $scope.person_id, $scope.encntr_id,'',$scope.event, $scope.searchParams ]
		});
	};

/*
* ORDERS
* 1 P_ID , 2 E_ID, 3 CATALOG_TYPES, 4 ACTIVITY_TYPES, 5 CATALOGS, 6 ORDER_STATUSES, 7 DEPT_STATUSES, 8 DETAILS,
*  9 EVENT_START, 10 DCP_CLIN_CAT, 11 INCLUDE_TEMPLATE_ORDS, 12 INCLUDE_CE_DATA, 13 OUTPUT, 14 OUTDEV, 15 ORIG_ORD_FLAG
*/
	$scope.catalog_types = ""; //3
	$scope.activity_types =""; //4
	$scope.catalogs = ""; //5
	$scope.order_statuses = ''; //6
	$scope.dept_statuses = ""; //7
	$scope.details = ""; //8
	 // event_start 9
	$scope.dcp_clin_cat = ""; //10
	$scope.inc_template_ord = ""; //11
	$scope.inc_ce_data = ""; //12
	$scope.output = "";
	$scope.outdev = "";
	$scope.orig_ord_flag = "";


	$scope.origOrdFlag = function(){
		if (typeof $scope.orig_ord_flag === 'number')
			{ console.log("ok");}
		else  console.log(typeof $scope.orig_ord_flag);
	}



	$scope.whichBtn = function(event){
		var whichOne = angular.element(event.target);
		console.log(whichOne);
	}


	$scope.orders = function(){

		mpages.loadCCL({
			recordName:'orders',
			scriptName:'nmh_get_orders_data',
			prompts: [$scope.person_id, $scope.encntr_id,	$scope.catalog_types, $scope.activity_types, $scope.catalogs,$scope.order_statuses,$scope.dept_statuses,$scope.details,$scope.eventStart,$scope.dcp_clin_cat,$scope.inc_template_ord,$scope.inc_ce_data,$scope.output,$scope.outdev,$scope.orig_ord_flag]

				/*          prompts: [123, 456, ‘3’, ‘4’, ‘5’, ‘ORDERED|ORDERINPROCESS|PENDINGCOMPLETE’,’7’,’YES’,’9’,’MEDICATIONS’,’11’,’12’,’13’,’14’,’15’] */
		});
	};

/*
*  FORMS
*  Prompts: P_ID, E_ID, formSearch, FIELDS, EVENT_START
*/

	// model for form search
	$scope.formSearch = "";
	// array of returned searches
	$scope.formSearchGroup = [];
	// contains returned form field list items
	$scope.fieldItems = "";
	// model for field select box
	$scope.fieldSearch = "";
	// array of selected form fields
	$scope.fieldSearchGroup = "";

	$scope.fieldModel = [];


	$scope.formSearchFn = function(searchTerm, recName){
		if ( !angular.isDefined(searchTerm) || searchTerm.length <= 3)
			{ return; }
		else if (searchTerm.length >= 3){

			if ($scope.timeout.promise){$timeout.cancel($scope.timeout.promise);}
				$scope.timeout.promise = $timeout(function(){
					mpages.loadCCL({
						recordName: recName,
						scriptName: 'nmh_get_search_form_codes',
						prompts: [searchTerm.replace(/ /,'')]
					});
				},500);
		}
	};

	$scope.collectFormFields = function(x){
		$scope.fieldSearch = $scope.fieldModel.join('|');
		//console.log(fieldSearch);
	}

	$scope.setFormResults = function (y){$scope.formResults = y;}

	$scope.forms = function(){
		mpages.loadCCL({
			recordName:'forms',
			scriptName:'nmh_get_forms_data',
			prompts: [$scope.person_id,$scope.encntr_id,$scope.formSearch,$scope.fieldSearch,$scope.searchParams]
			//prompts: [72732822,69067289,'PTINITIALEVALUATIONFORM',$scope.fieldSearch,$scope.searchParams]
		});
	}




/*
* ENCOUNTERS
* Prompts: OUTDEV, DISCH_START, DISCH_END, FAC, ENCNTR_TYPE_CLASS, MED_SERV, UNIT, OUTPUT, ENCNTR_TYPE
*/
	$scope.outdev ='';
	$scope.encntrStart = "";
	$scope.encntrEnd = "";
	$scope.fac = "";
	$scope.encntr_type = "";
	$scope.encntr_type_class = "";
	$scope.med_serv = "";
	$scope.nurseUnit = "";
	$scope.encntrStartDP = "";
	$scope.encntrEndDP = "";
	$scope.facilites = "";
	$scope.collectFacilties = function(){

		$scope.facilites = $scope.fac.join('|');

	}


	$scope.encounters = function(){
		mpages.loadCCL({
			recordName:'encounters',
			scriptName:'nmh_get_encntrs_by_date',
			prompts: [$scope.outdev,$scope.encntrStart,$scope.encntrEnd,$scope.facilites,$scope.encntr_type_class,$scope.med_serv,$scope.nurseUnit,$scope.encntr_type,'']
			//prompts: ['', 0, 0, 'NMH','' ,'' ,'FIENBERG15E|FIENBERG16E|FIENBERG16W|FIENBERG15W|FIENBERGFMOU|FIENBERGCRU','','']
		});

	}

			// OUTDEV, DISCH_START, DISCH_END, FAC, ENCNTR_TYPE_CLASS, MED_SERV, UNIT, OUTPUT, ENCNTR_TYPE

	$scope.setDetails = function (y){$scope.selectedDetails = y;}
	$scope.setResults = function (y){$scope.resultsList = y;}

});