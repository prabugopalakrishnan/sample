/*NOTE:  if "signout_folder" has data, make sure "ccl_report" and "ccl_params" is empty, and vice versa*/
/**Exceptions is for signouts with version "new", "ccl_params" should patient list id */
/**Neph acute is the only one using signout_folder currently */
/*Move this data to SQL DB with webservice to output JSON in this same format*/
/*For version = new , pass patient list id as a ccl param*/
var signoutData = {};
signoutData.NM_SURGERY = [{
	  	"name": "Blue Service",
	  	"patient_list" : "NMH_BLUE_SVC",
	  	"signout_form" : "SURGICALSIGNOUTBLUESERVICEFORM",
	  	"contact_form" : "SOCONTACTINFOBLUESERVICEFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "9",
	  	"version"	: "old"
	},{
	  	"name": "Breast Service",
	  	"patient_list" : "NMH_BREAST_SVC",
	  	"signout_form" : "SURGICALSIGNOUTBREASTSERVICEFORM",
	  	"contact_form" : "SOCONTACTINFOBREASTSERVICEFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "25",
	  	"version"	: "old"
	},{
	  	"name": "Cardiac Service",
	  	"patient_list" : "NMH_CARDIAC_SURG",
	  	"signout_form" : "SURGICALSIGNOUTCARDIACSURGFORM",
	  	"contact_form" : "SOCONTACTINFOCARDIACSURGERYFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_CARDIAC",
	  	"ccl_params" :"16",
	  	"version"	: "old"
	},{
	  	"name": "Colorectal Service",
	  	"patient_list" : "NMH_COL_SURG",
	  	"signout_form" : "SURGICALSIGNOUTCOLORECTALSURGFORM",
	  	"contact_form" : "SOCONTACTINFOCOLORECTALSURGFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "6",
	  	"version"	: "old"
	},{
	  	"name": "CTICU / NSICU",
	  	"patient_list" : "Feinberg HF",/*"NMH_CTICU_NSICU",*/
	  	"signout_form" : "SURGICALSIGNOUTCTICUNSICUFORM",
	  	"contact_form" : "SOCONTACTINFOCTICUNSICUFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_CTICU_N",
	  	"ccl_params" : 33366225,/*24584247*/
	  	"version"	: "new"
	},{
	  	"name": "Endocrine Surgery",
	  	"patient_list" : "NMH_ENDOCRINE_SURG",
	  	"signout_form" : "SURGICALSIGNOUTENDOCRINEFORM",
	  	"contact_form" : "SOCONTACTINFOENDOCRINEFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "17",
	  	"version"	: "old"
	},{
	  	"name": "ENT - Purple",
	  	"patient_list" : "NMH_ENT_PURPLE",/*"NMH_CTICU_NSICU",*/
	  	"signout_form" : "SURGICALSIGNOUTENTFORM",
	  	"contact_form" : "SOCONTACTINFOENTPURPLEFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_ENT_P",
	  	"ccl_params" : "30",
	  	"version"	: "old"
	},{
	  	"name": "ENT - White",
	  	"patient_list" : "NMH_ENT_WHITE",/*"NMH_CTICU_NSICU",*/
	  	"signout_form" : "SURGICALSIGNOUTENTFORM",
	  	"contact_form" : "SOCONTACTINFOENTWHITEFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_ENT_W",
	  	"ccl_params" : "31",
	  	"version"	: "old"
	},{
	  	"name": "EP",
	  	"patient_list" : "NMH EP",/*original name is "NMH_EP"*/
	  	"signout_form" : "SURGICALSIGNOUTEP",
	  	"contact_form" : "SOCONTACTINFOEP",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_EP_N",
	  	"ccl_params" : 24273969,/*30*/
	  	"version"	: "new"
	},{
	  	"name": "General Signout",///This is here to be on customize section/ another under hospital medicine for noncustom
	  	"patient_list" : "",
	  	"signout_form" : "PHYSICIANSIGNOUTFORM",
	  	"contact_form" : "",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_GENERAL",
	  	"ccl_params" : "1",
	  	"version"	: "old"
	},{
	  	"name": "General Surgery",
	  	"patient_list" : "NMH_GEN_SURG",
	  	"signout_form" : "SURGICALSIGNOUTGENERALSURGFORM",
	  	"contact_form" : "SOCONTACTINFOGENERALSURGERYFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_NEW",
	  	"ccl_params" : "0",/*1*/
	  	"version"	: "new"
	},{
	  	"name": "Interventional Radiology",
	  	"patient_list" : "NMH_IR", //IR Signout?
	  	"signout_form" : "SURGICALSIGNOUTIR",
	  	"contact_form" : "",/*Intentionally left blank, since they do not want or need contact form*/
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_IR_N",
	  	"ccl_params" : 25862594,/*36*/
	  	"version"	: "new"
	},{
	  	"name": "Mueller Service", //No patients in patient list - hasnt been updated since Dec 2014
	  	"patient_list" : "NMH_MUELLER_SVC",
	  	"signout_form" : "SURGICALSIGNOUTMUELLERSERVICEFORM",
	  	"contact_form" : "SOCONTACTINFOMUELLERSERVICEFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "10",
	  	"version"	: "old"
	},{
	    "name": "Neurosurgery Signout",/*  This is in New Signouts, but they are using old one only.  Only the report in old signout has been updated*/
	  	"patient_list" : "NMH_NEU_SURG",
	  	"signout_form" : "SURGICALSIGNOUTNEUROSURGFORM",
	  	"contact_form" : "SOCONTACTINFONEUROSURGERYFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_NSURG",
	  	"ccl_params" : 23030301,/*"1",*/
	  	"version"	: "new"
	},/*{
    "name": "Ophthamology",
  	"patient_list" : "NMH_OPHTHO_CONSULT", HAS NOT BEEN updated since DEC 2013
  	"signout_form" : "SURGICALSIGNOUTOPHTHALMOLOGYFORM",
  	"contact_form" : "SOCONTACTINFOOPHTHALMOLOGYFORM",
  	"signout_folder" : "",
  	"ccl_report" : "NMH_SIGNOUT_SURGERY_OPHTH_N",
  	"ccl_params" : "23030337",//24
  	"version"	: "new"
	},*/

	{
	    "name": "OBGYN Gyn",
	  	"patient_list" : "OBGYN Gyn",
		"signout_form" : "SIGNOUTFORMOBGYNFORM",
	  	"contact_form" : "SOCONTACTINFOOBGYNFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_OBGYN",
	  	"ccl_params" : 30396947.00,/*38*/
	  	"version"	: "new"
	},{
	    "name": "OBGYN MFM",
	  	"patient_list" : "OBGYN MFM",
		"signout_form" : "SIGNOUTFORMOBGYNFORM",
	  	"contact_form" : "SOCONTACTINFOOBGYNMFM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_OBGYN",
	  	"ccl_params" : 30447135.00,/*38*/
	  	"version"	: "new"
	},{
	    "name": "OBGYN Onc",
	  	"patient_list" : "OBGYN Onc",
		"signout_form" : "SIGNOUTFORMOBGYNFORM",
	  	"contact_form" : "SOCONTACTINFOOBGYNONC",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_OBGYN",
	  	"ccl_params" : 30417821.00,/*38*/
	  	"version"	: "new"
	},{
	    "name": "Orthopaedic Joint Replacement",
	  	"patient_list" : "NMH_ORTHO_JOINTS",//someone renamed this to NMH_ORTHO_JOINT but since it is 'new', it might be okay
	  	"signout_form" : "SURGICALSIGNOUTORTHOJOINTFORM",
	  	"contact_form" : "SOCONTACTINFOORTHOJOINTFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_ORTHO_JOINT_N",
	  	"ccl_params" : 24972700,/*35*/
	  	"version"	: "new"
	},{
	    "name": "Orthopaedic Spine",
	  	"patient_list" : "NMH_ORTHO_SPINE",
	  	"signout_form" : "SURGICALSIGNOUTORTHOSPINEFORM",
	  	"contact_form" : "SOCONTACTINFOORTHOSPINEFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_ORTHO_SPINE_N",
	  	"ccl_params" : 24972705,/*34*/
	  	"version"	: "new"
	},{
	    "name": "Orthopaedic Trauma",
	  	"patient_list" : "NMH_ORTHO_TRAUMA",
	  	"signout_form" : "SURGICALSIGNOUTORTHOTRAUMAFORM",
	  	"contact_form" : "SOCONTACTINFOORTHOTRAUMAFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_ORTHO_TRAUMA_N",
	  	"ccl_params" : 24972710,/*33*/
	  	"version"	: "new"
	},{
	    "name": "Plastic Surgery",
	  	"patient_list" : "NMH_PLASTICS_SURGERY",
	  	"signout_form" : "SURGICALSIGNOUTPLASTICSSURGERYFORM",
	  	"contact_form" : "SOCONTACTINFOPLASTICSURGERY",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_PLASTIC",
	  	"ccl_params" : "29",/*29 - dribk*/
	  	"version"	: "old"
	},{
	    "name": "SICU",/*exists in old, but they are identical output, so no need to maintain old anymore please.*/
	  	"patient_list" : "NMH_SICU", /* may not work with custom pt_list, so use this then javascript:CCLLINK("NMH_SIGNOUT_SURGERY_SICU","MINE,22",1)*/
	  	"signout_form" : "SURGICALSIGNOUTSICUFORM",
	  	"contact_form" : "SOCONTACTINFOSICUFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_SICU",
	  	"ccl_params" : "22",/*22*/
	  	"version"	: "old"
	},{
	  	"name": "Stem Cell Transplant",
	  	"patient_list" : "NMH_STEM_CELL",
	  	"signout_form" : "SURGICALSIGNOUTSTEMCELLTRANSFORM",
	  	"contact_form" : "SOCONTACTINFOSTEMCELLFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_STEMC_N",
	  	"ccl_params" : 23030515,/*23*/
	  	"version"	: "new"
	},{
	  	"name": "Surgical Oncology",
	  	"patient_list" : "NMH_SURG_ONC",
	  	"signout_form" : "SURGICALSIGNOUTSURGICALONCFORM",
	  	"contact_form" : "SOCONTACTINFOSURGICALONCFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "3",
	  	"version"	: "old"
	},{
	  	"name": "Thoracic Surgery",
	  	"patient_list" : "NMH_THOR_SURG",
	  	"signout_form" : "SURGICALSIGNOUTTHORACICSURGFORM",
	  	"contact_form" : "SOCONTACTINFOTHORACICSURGERYFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "5",
	  	"version"	: "old"
	},{
	  	"name": "Transplant",
	  	"patient_list" : "NMH_TRANSPLANT",/*In both new and old, but the are usin ghte old one */
	  	"signout_form" : "SURGICALSIGNOUTTRANSPLANTSURGFORM",
	  	"contact_form" : "SOCONTACTINFOTRANSPLANTFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_TRANSPLANT",
	  	"ccl_params" : "8",
	  	"version"	: "old"
	},{
	  	"name": "Trauma/Emergency Surgery",
	  	"patient_list" : "NMH_TR/ES",
	  	"signout_form" : "SURGICALSIGNOUTTRAUMAFORM",
	  	"contact_form" : "SOCONTACTINFOTRAUMASURGERYFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_TRAUMA_N",
	  	"ccl_params" : 23030292,/*7*/
	  	"version"	: "new"
	},{
	  	"name": "Urology Alumni",
	  	"patient_list" : "NMH_SURGERY_UROLOGY_ALUMNI",
	  	"signout_form" : "SURGICALSIGNOUTUROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFOUROLOGYALUMNIFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "41",
	  	"version"	: "old"
	},{
	  	"name": "Urology Andrology/Endourology",
	  	"patient_list" : "NMH_SURGERY_UROLOGY_ANDRO/ENDOUROLOGY",
	  	"signout_form" : "SURGICALSIGNOUTUROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFOUROLOGYANDROLENDOFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "42",
	  	"version"	: "old"
	},/*{
	  	"name": "Urology Blue",
	  	"patient_list" : "NMH_GU_BLUE",
	  	"signout_form" : "SURGICALSIGNOUTUROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFOGUBLUEFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "19",
	  	"version"	: "old"
	},*/{
	  	"name": "Urology Consults",
	  	"patient_list" : "NMH_GU_CONSULT",
	  	"signout_form" : "SURGICALSIGNOUTUROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFOGUCONSULTFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "21",
	  	"version"	: "old"
	},/*{
	  	"name": "Urology Green",
	  	"patient_list" : "NMH_GU_GREEN",
	  	"signout_form" : "SURGICALSIGNOUTUROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFOGUGREENFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "20",
	  	"version"	: "old"
	},*/{
	  	"name": "Urology Oncology",
	  	"patient_list" : "NMH_SURGERY_UROLOGY_ONCOLOGY",
	  	"signout_form" : "SURGICALSIGNOUTUROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFOUROLOGYONCOLOGYFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "39",
	  	"version"	: "old"
	},{
	  	"name": "Urology Private",
	  	"patient_list" : "NMH_SURGERY_UROLOGY_PRIVATE",
	  	"signout_form" : "SURGICALSIGNOUTUROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFOUROLOGYPRIVATEFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "43",
	  	"version"	: "old"
	},{
	  	"name": "Urology Reconstruction",
	  	"patient_list" : "NMH_SURGERY_UROLOGY_RECONSTRUCTION",
	  	"signout_form" : "SURGICALSIGNOUTUROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFOUROLOGYRECONSTRUCTFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "40",
	  	"version"	: "old"
	},/*{
	  	"name": "Urology Red",
	  	"patient_list" : "NMH_GU_RED",
	  	"signout_form" : "SURGICALSIGNOUTUROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFOGUREDFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY",
	  	"ccl_params" : "18",
	  	"version"	: "old"
	},*/	{
	    "name": "Vascular Surgery",
	  	"patient_list" : "NMH_VASC_SURG",
	  	"signout_form" : "SURGICALSIGNOUTVASCULARSURGFORM",
	  	"contact_form" : "SOCONTACTINFOVASCULARSURGERYFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_VASCULAR",
	  	"ccl_params" : "4",
	  	"version"	: "old"
	}
];

signoutData.zNM_HOSPITAL_MEDICINE = [{
	  	"name": "Gastroenterology",/*NOTE - missing patient list or renamed?*/
	  	"patient_list" : "NMH_GI",/*THIS is missing or renamed, need to look into this more*/
	  	"signout_form" : "SURGICALSIGNOUTGASTROENTEROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFOGASTROENTEROLOGYFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_GAS_N",
	  	"ccl_params" : 24694758,/*31*/ /*Currenlty using patient list id of "GI consult" patient list*/
	  	"version"	: "new"
	},{
	  	"name": "General Signout",///this is here under hospital medicine for noncustom /and again in the customize section under NM Surgery
	  	"patient_list" : "",
	  	"signout_form" : "PHYSICIANSIGNOUTFORM",
	  	"contact_form" : "",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_GENERAL",
	  	"ccl_params" : "1",
	  	"version"	: "old"
	},{
	  	"name": "Hospitalist - 15th Floor Feinberg #1",
	  	"patient_list" : "Hospitalist - 15th Floor Feinberg #1",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSP15EFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "1",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - 15th Floor Feinberg #2",
	  	"patient_list" : "Hospitalist - 15th Floor Feinberg #2",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSP15FLOATFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "3",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - 15th Floor Feinberg #3",
	  	"patient_list" : "Hospitalist - 15th Floor Feinberg #3",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSP153FORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "14",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - 16 East #1",
	  	"patient_list" : "Hospitalist - 16 East #1",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSP16EFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "4",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - 16 East #2",
	  	"patient_list" : "Hospitalist - 16 East #2",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSP16FLOATFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "5",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - 16 West #1",
	  	"patient_list" : "Hospitalist - 16 West #1",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPSS1FORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "9",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - 16 West #2",
	  	"patient_list" : "Hospitalist - 16 West #2",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPSS2FORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "10",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - Admissions",
	  	"patient_list" : "Hospitalist - Admissions",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPACESWING",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "20",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - Contingency",
	  	"patient_list" : "Hospitalist - Contingency List",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPCONTINGENCY",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "21",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - Day Swing",
	  	"patient_list" : "Hospitalist - Day Swing",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPDAYSWINGFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "15",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - Flex",
	  	"patient_list" : "Hospitalist - Flex List",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPFLEX",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "23",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - Heme/Onc Gold #1",
	  	"patient_list" : "Hospitalist - Heme/Onc Gold #1",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPONC1FORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "6",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - Heme/Onc Gold #2",
	  	"patient_list" : "Hospitalist - Heme/Onc Gold #2",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPONC2FORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "7",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - Heme/Onc Gold #3",
	  	"patient_list" : "Hospitalist - Heme/Onc Gold #3",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPONC3FORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "8",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - Heme/Onc Gold #4",
	  	"patient_list" : "Hospitalist - Heme/Onc Gold #4",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPONC4FORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "17",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - M4",
	  	"patient_list" : "Hospitalist - M4",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSP15WFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "2",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - Observation",
	  	"patient_list" : "Hospitalist - Observation",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPOBSERVATIONFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "13",
	  	"version"	: "old"
  	},{
	  	"name": "Hospitalist - Overflow #1",
	  	"patient_list" : "Hospitalist - Overflow #1",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPOVERFLOWFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_HOSP_CROSS_COVER",
	  	"ccl_params" : "12",
	  	"version"	: "old"
  	},{
	  	"name": "ID Transplant",
	  	"patient_list" : "NMH_ID_Transplant",
	  	"signout_form" : "SURGICALSIGNOUTID",
	  	"contact_form" : "SOCONTACTINFOID",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_ID_N",
	  	"ccl_params" : 24114949,/*31*/
	  	"version"	: "new"
	},{
	  	"name": "ID Medicine",
	  	"patient_list" : "NMH_ID_Medicine",
	  	"signout_form" : "SURGICALSIGNOUTID",
	  	"contact_form" : "SOCONTACTINFOID",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_ID_N",
	  	"ccl_params" : 24114966,/*31*/
	  	"version"	: "new"
	},{
	  	"name": "ID Surgery",
	  	"patient_list" : "NMH_ID_Surgery",
	  	"signout_form" : "SURGICALSIGNOUTID",
	  	"contact_form" : "SOCONTACTINFOID",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_ID_N",
	  	"ccl_params" : 24114973,/*31*/
	  	"version"	: "new"
	},{
	  	"name": "MICU / CCU",
	  	"patient_list" : "NMH_MICU_CCU",/*This patient list has only old discharged patients .  Are they even using this ?*/
	  	"signout_form" : "SURGICALSIGNOUTMICUCCUFORM",/*Only being used by Abbigail Dooer*/
	  	"contact_form" : "SOCONTACTINFOMICUCCUFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_MICU_CCU_N",
	  	"ccl_params" : 23032330,/*27*/
	  	"version"	: "new"
	},{
	    "name": "Nephrology Acute",/* All 4 Nephrology signouts are in both old and new, but only being used in the old.*/
	  	"patient_list" : "NMH_NEPH_ACUTE",
	  	"signout_form" : "SURGICALSIGNOUTNEPHROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFONEPHACUTEFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_NEPH_INTERIM",
	  	"ccl_params" : "13",
	  	"version"	: "old"
	},{
	    "name": "Nephrology Dialysis",
	  	"patient_list" : "NMH_NEPH_DIAL",
	  	"signout_form" : "SURGICALSIGNOUTNEPHROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFONEPHDIALYSISFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_NEPH_INTERIM",
	  	"ccl_params" : "15",
	  	"version"	: "old"
	},{
	    "name": "Nephrology ICU",
	  	"patient_list" : "NMH_NEPH_ICU",
	  	"signout_form" : "SURGICALSIGNOUTNEPHROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFONEPHICUFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_NEPH_INTERIM",
	  	"ccl_params" : "29",
	  	"version"	: "old"
	},{
	    "name": "Nephrology Transplant",
	  	"patient_list" : "NMH_NEPH_TRANS",
	  	"signout_form" : "SURGICALSIGNOUTNEPHROLOGYFORM",
	  	"contact_form" : "SOCONTACTINFONEPHTRANSPLANTFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_NEPH_INTERIM",
	  	"ccl_params" : "14",
	  	"version"	: "old"
	},{
	    "name": "Respiratory",
	  	"patient_list" : "NMH_RESP",
	  	"signout_form" : "SURGICALSIGNOUTRESPFORM",
	  	"contact_form" : "SOCONTACTINFORESPFORM",
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_SIGNOUT_SURGERY_RESP",
	  	"ccl_params" : "32",
	  	"version"	: "old"
	}
];

signoutData.zzNM_PSYCHIATRY = [{
    "name": "Psych Consult",
  	"patient_list" : "NMH_PSYCH_CONSULT",
  	"signout_form" : "PSYCHCONSULTSIGNOUTFORM",
  	"contact_form" : "SOCONTACTINFOPSYCHCONSULTSFORM",
  	"signout_folder" : "",
  	"ccl_report" : "NMH_SIGNOUT_PSYCH_N",
  	"ccl_params" : 26516754,/*37*/
  	"version"	: "new"
},{
  	"name": "General Signout",///this is here under hospital medicine for noncustom /and again in the customize section under NM Surgery
  	"patient_list" : "",
  	"signout_form" : "PHYSICIANSIGNOUTFORM",
  	"contact_form" : "",
  	"signout_folder" : "",
  	"ccl_report" : "NMH_SIGNOUT_GENERAL",
  	"ccl_params" : "1",
  	"version"	: "old"
}]

signoutData.zzzNLFH_HOSPITAL_MEDICINE = [{
/*Angular1.2  sorts this alphbetically so add "zzz" in front and filter it out - https://github.com/angular/angular.js/issues/6210 - Fixed in Angular 1.4*/
/*A-F uses – and not - */
	    "name": "Hospitalist LF – All",
	  	"patient_list" : "Hospitalist LF – All",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFALL",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 25467980,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF – A",
	  	"patient_list" : "Hospitalist LF – A",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFA",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 25467984,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF – B",
	  	"patient_list" : "Hospitalist LF – B",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFB",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 25467986,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF – C",
	  	"patient_list" : "Hospitalist LF – C",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFC",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 25467990,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF – D",
	  	"patient_list" : "Hospitalist LF – D",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFD",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 25467993,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF – E",
	  	"patient_list" : "Hospitalist LF – E",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFE",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 25467996,//0,Hospitalist LF – E
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF – F",
	  	"patient_list" : "Hospitalist LF – F",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFF",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 25467999,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF - G",
	  	"patient_list" : "Hospitalist LF - G",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFG",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 26054771,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF - Swing 1",
	  	"patient_list" : "Hospitalist LF - Swing 1",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFSWING1",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 26055160,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF - Swing 2",
	  	"patient_list" : "Hospitalist LF - Swing 2",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFSWING2",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 26055162,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF - Night Float 1",
	  	"patient_list" : "Hospitalist LF - Night Float 1",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFNIGHTFLOAT1",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 26055036.00,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF - Night Float 2",
	  	"patient_list" : "Hospitalist LF - Night Float 2",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFNIGHTFLOAT2",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 26055042,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF - PA 1",
	  	"patient_list" : "Hospitalist LF - PA 1",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFPA1",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 26055116,
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF - PA 2",
	  	"patient_list" : "Hospitalist LF - PA 2",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFPA2",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 26055124.00,//Hospitalist LF - PA 2
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF - PA 3",
	  	"patient_list" : "Hospitalist LF - PA 3",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFPA3",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 26055136,//Hospitalist LF - PA 3
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF - PA 4",
	  	"patient_list" : "Hospitalist LF - PA 4",
	  	"signout_form" : "HOSPITALISTSIGNOUTFORM",
	  	"contact_form" : "SOCONTACTINFOHOSPLFPA5",
	  	"signout_folder" : "",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 26055143,//0,Hospitalist LF - PA 4
	  	"version"	: "new"
    },{
	    "name": "Hospitalist LF - PA 5",
	  	"patient_list" : "Hospitalist LF - PA 5",
	  	"signout_form" : "",
	  	"contact_form" : "SOCONTACTINFOHOSPLFPA1",
	  	"signout_folder" : "HOSPITALISTSIGNOUTFORM",
	  	"ccl_report" : "nmh_signout_hosp_cross_cvr_new",
	  	"ccl_params" : 26055138,//"Hospitalist LF - PA 5",
	  	"version"	: "new"
    }
];  

signoutData.zzzzNM_LABOR_DELIVERY = [{
	    "name": "Labor & Delivery",
	  	"patient_list" : "",///pulls patients from PRENTICE8LD unit
	  	"signout_form" : "PHYSICIANSIGNOUTFORM", /*Not sure if using old or new one*/
	  	"contact_form" : "",/*NO CONTACT FORM NEEED*/
	  	"signout_folder" : "",
	  	"ccl_report" : "NMH_RPT_LD_DETAILS",
	  	"ccl_params" : "1",
	  	"version"	: "old"
   }]

