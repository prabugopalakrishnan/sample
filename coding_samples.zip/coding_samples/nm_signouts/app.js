'use strict';

var app = angular.module('signouts3000',['mpages']);

app.factory('progressIndicatorService', function() {
    var target = document.createElement("div");
    target.id = "progressIndicator";
    target.style.margin = "0px auto";
 	document.body.appendChild(target);

    var spinner = new Spinner({color:'#61468B', hwaccelBoolean: true});
    return {
        startSpinner: function() {
            $(target).fadeIn('slow');
            spinner.spin(target);
        },
        stopSpinner:function () {
            $(target).fadeOut('fast');
            spinner.stop();
        }
    };
});

app.filter('filterHeaders', function() {
	return function (input) {
		return input.replace(/_/g, " ").replace(/z/g,"");
    };
});

app.controller('signoutHome',function($scope, mpages, progressIndicatorService, $timeout){
	// init.
	// if signoutData is present...
	// make a collection of ccl calls to obtain contact info for each so
	// make ccl calls
	// match returned data with so obj
	// assign obj to view.
	mpages.progressbar.start();


	$scope.sortfunc = function(obj){ return obj._DATA.ROOM; }

	//$scope.onload_contact = true ///toggle if contact details of all signouts should load onload of page, or by button click per signout.

	var init = (function(){
		var cclContactBatch={},
			i = 0,
			keys = [];

		var batch_signout_contact_calls = function(signoutData){
			keys = _.keys(signoutData);
			_.each(keys,function(key){

				if(signoutData[key].length>0){
					try{
						cclContactBatch[key]=[];
						_.each(signoutData[key],function(so){
							cclContactBatch[key].push({
								scriptName: "nmh_signout_get_contacts",
								prompts: ['',so.contact_form]
							});
						});
					}catch(e){console.log(e);}
				}
			});
			get_signout_contacts(cclContactBatch,signoutData);
		}


		var get_signout_contacts = function(cclContactBatch,signoutData){
			var batchCnt = 5;

			if(angular.isDefined(cclContactBatch)){
				mpages.loadCCL(cclContactBatch.NM_SURGERY,
					function(data,done){
						if(data){ parse_signout_contact_data(data,signoutData.NM_SURGERY); };
						if(done){
							$scope.signoutData = signoutData;
							mpages.loadCCL(cclContactBatch.zNM_HOSPITAL_MEDICINE,
								function(data,done){
									if(data){ parse_signout_contact_data(data,signoutData.zNM_HOSPITAL_MEDICINE); };
									if(done){
										$scope.signoutData = signoutData;
										mpages.loadCCL(cclContactBatch.zzNM_PSYCHIATRY,
											function(data,done){
												if(data){ parse_signout_contact_data(data,signoutData.zzNM_PSYCHIATRY); };
												if(done){
													$scope.signoutData = signoutData;
													mpages.loadCCL(cclContactBatch.zzzNLFH_HOSPITAL_MEDICINE,
														function(data,done){
															if(data){ parse_signout_contact_data(data,signoutData.zzzNLFH_HOSPITAL_MEDICINE); };
															if(done){
																$scope.signoutData = signoutData;
																mpages.loadCCL(cclContactBatch.zzzzNM_LABOR_DELIVERY,
																	function(data,done){
																		if(data){ parse_signout_contact_data(data,signoutData.zzzzNM_LABOR_DELIVERY); };
																		if(done){
																			$scope.signoutData = signoutData;
																			mpages.progressbar.complete();
																		}
																	},
																	function(error){console.log(error)},
																	batchCnt
																);
															}
														},
														function(error){console.log(error)},
														batchCnt
													);
												}
											},
											function(error){console.log(error)},
											batchCnt
										);	
									}
								},
								function(error){console.log(error)},
								batchCnt
							);
						}
					},
					function(error){console.log(error)},
					batchCnt
				);
			}
		}

		var parse_signout_contact_data = function(data,signoutData){
			_.each(data,function(ccl_data){
				_.each(signoutData,function(config_data){
					if(config_data.contact_form == ccl_data.FORM_NAME){
						try{
							config_data.contact_info = {
								NAME:ccl_data.NAME,
								PHONE:ccl_data.PHONE,
								PAGER:ccl_data.PAGER,
								REF_ID:ccl_data.REF_ID,
								ACT_ID:ccl_data.ACT_ID,
							};
						}catch(e){console.log(e)}
					}
				 });
			})
		}
		return{
			begin:batch_signout_contact_calls,
			get_signout_contacts:get_signout_contacts,
			parse_signout_contact_data:parse_signout_contact_data
		}
	})();


	init.begin(signoutData);


	$scope.loadPatients = (function(so){

		var get_plist = function(so){ // get patient list if not availale.
			if(so.patient_list == ""){
				for(var x=0; x < $scope.custom.patient_lists.length;x++){
					if($scope.custom.patient_lists[x].NAME.search(/C. SIGNOUT/i) == -1){
						if($scope.custom.patient_lists[x].NAME.search(/Signout/i) > -1){
							so.patient_list = $scope.custom.patient_lists[x].NAME;
							so.patient_list_id = $scope.custom.patient_lists[x].PATIENT_LIST_ID;
							break;
						}
					}
				}
			}
			progressIndicatorService.startSpinner();
			if(angular.isDefined(so)){ // coming from standard signout.
				if(so.show_plist != true){ //only execute rest if the button is opening up the list instead of closing it.
					if(angular.isDefined(so.patient_list) && so.patient_list!='' && !angular.isDefined(so.patient_list_id)){ // if no patient_list_id has been found... retrieve it.

						if(!angular.isNumber(so.ccl_params)){
							mpages.loadCCL({scriptName:'nmh_signout_patient_id',prompts: ["MINE", so.patient_list.replace("'","@apost")]},
								function(data,done){
									if(done & angular.isDefined(data)){
										so.patient_list_id = data[0].LIST_ID;
										if(so.patient_list_id > 0){
											get_patients(so);
										} else {
											progressIndicatorService.stopSpinner();
											alert("The patient list name associated with this signout, '"+so.patient_list+"' has been renamed or deleted.");
										}

									}
								},
								function(e){alert(JSON.stringify(e));});
							
						} else {
							so.patient_list_id = so.ccl_params;
							get_patients(so);
						}

					} else if(so.PATIENT_LIST_ID>0 || so.patient_list_id>0) { // if patient_list_id is present... usually from CUSTOM
						get_patients(so);
					}
				} else { progressIndicatorService.stopSpinner(); }
			} else {
				progressIndicatorService.stopSpinner();
				alert("No patient list associated with sign-out");
			}
			
		}

		var get_patients = function(config_obj){
			if(angular.isDefined(config_obj) && config_obj.patient_list_id > 0 || config_obj.PATIENT_LIST_ID > 0){
				//$scope.custom.get_plist_data_done = false;
				var pat_list_id = 0;
				if(config_obj.patient_list_id > 0){
					pat_list_id = config_obj.patient_list_id;// from general signout
				} else if(config_obj.PATIENT_LIST_ID > 0){
					pat_list_id = config_obj.PATIENT_LIST_ID; // from custom signout
				}
	        	mpages.loadCCL({scriptName:'nmh_get_plist_data',prompts: ["MINE",pat_list_id]},
	    			function(data,done){
	    				if(done & angular.isDefined(data)){
							config_obj.patients = data[0].LIST;
							$scope.custom.get_plist_data_done = true;

							if(data[0].LIST.length > 0){
	    						get_patient_form_info(config_obj);
	    					} else {
	    						progressIndicatorService.stopSpinner();
	    					}
	    				}
	    			},
	    			function(e){alert(e)});
	    	}
		}

		var get_patient_form_info = function(config_obj){
			var patient_batch = [];
			if(angular.isDefined(config_obj) && config_obj.patients){
				var x ={},
				_signout_form = "";

				if(angular.isDefined(config_obj.signout_form)){ 
					_signout_form = config_obj.signout_form 
				}

				if(_signout_form != ""){
					_.each(config_obj.patients,function(patient){ 
						patient_batch.push({scriptName: "nmh_signout_get_so_form",prompts: ['',patient.PERSON_ID,patient.ENCNTR_ID,_signout_form]})
					});
					if(patient_batch.length == config_obj.patients.length){
						try{
							mpages.loadCCL(patient_batch,
								function(data,done){
									if(data){
										if(data[0].REF_ID>0){
											config_obj.REF_ID=data[0].REF_ID; 
										}
										_.each(data,function(form_data){
											var pat = _.find(config_obj.patients,function(config_pat){
												return config_pat.PERSON_ID == form_data.P_ID
											});

											if(angular.isDefined(pat)){
												pat.ACT_ID = form_data.ACT_ID;
												pat.REF_ID = form_data.REF_ID;
											}
										});
										if($scope.plist_selection){
											if($scope.plist_selection.NAME.search(/Signout/i) > -1){
												$scope.custom.signout.ccl_report = "NMH_SIGNOUT_GENERAL_NEW";
												$scope.custom_report = false;
												window.setTimeout(function(){
													//race condition happening. $digest conflict
													angular.element("#signoutReportSelector").val(3).triggerHandler('change');
												}, 500);
											}
										}
										progressIndicatorService.stopSpinner();
									}
								},
								function(e){alert(e)}
							)
						}catch(e){alert(e);}
					}
				} else {
					progressIndicatorService.stopSpinner();
					if($scope.plist_selection){
						if($scope.plist_selection.NAME.search(/Signout/i) > -1){
							$scope.custom.signout.ccl_report = "NMH_SIGNOUT_GENERAL_NEW";
							$scope.custom_report = false;
							window.setTimeout(function(){
								//race condition happening. $digest conflict
								angular.element("#signoutReportSelector").val(3).triggerHandler('change');
							}, 500);
						}
					}
				}
			}
		}

		var launch_patient_form_info = function(ev,p,e,s){
			mpages.loadCCL({recordName:'hackMultipleUsersForm',scriptName:'nmh_signout_get_so_form',prompts: ['',p,e,s]},
				function(data,done){
					if(done){ 
						mpages.execFormLink(ev, data[0].P_ID, data[0].E_ID, data[0].REF_ID, data[0].ACT_ID)
					}
				}, function(error){ alert(error); $scope.idErrors.push(error); mpages.progressbar.complete();}
			);
		}
		return{
			get_plist:get_plist,
			get_patients:get_patients,
			launch_patient_form_info:launch_patient_form_info,
			get_patient_form_info:get_patient_form_info
		}
	})();

/*********************************
/ CUSTOM
*/

	$scope.custom = (function(){

		var load_reports = function(){
			$scope.custom.config = [];
			_.each(signoutData,function(sod){
				_.each(sod,function(s){
					if(s.version == 'new' || s.name == "General Signout"){
						$scope.custom.config.push(s);
					}
				});
			});
		}


		var get_patient_list = function(){
				if(mpages.params.userId){
					mpages.loadCCL({recordName:'patientLists',scriptName:'nmh_get_patient_lists_by_user',prompts: ["MINE",mpages.params.userId]},
				        function (data,done){
				            if(done){
				            	$scope.custom.patient_lists = data[0].LIST;
				            	updt_plist_class();
				            	angular.element("#advanced_panel").fadeIn('slow');
				            }
				        }, function(error){ alert(error); $scope.idErrors.push(error); mpages.progressbar.complete();}
				    );
				}else{alert("Unable to find userId. Please check URL.")}
		};


		var updt_plist_class = function(){
			//race condition happening. Add slight delay to let select fully populate
			$timeout(function(){
				_.each(angular.element("#custom_patient_list select > option"),function(opt,index){
					var filtered = _.filter($scope.custom.patient_lists,function(pat, index){
						return opt.value == pat.PATIENT_LIST_ID;
					});
					if(filtered && filtered.length)
						angular.element(opt).addClass((filtered[0].ACTIVE_IND) ? 'green': 'red');
				});
			;},
				100
			);
		};

		var set_patient_list = function(plist_selection){
			$scope.custom.match_found = false;
			$scope.plist_selection = plist_selection;
			if(plist_selection.NAME.search(/Signout/i) > -1 || plist_selection == ""){
				$scope.custom.signout = {
					patient_list_id:plist_selection.PATIENT_LIST_ID, // set patient list from passed plist_selection.
					patient_list:plist_selection.NAME,
            		name : "General Signout",
            		ccl_report:"NMH_SIGNOUT_GENERAL_NEW",
					ccl_params:"1",
					contact:{ ref_id:"", act_id:"" },
					signout_folder:"",
					signout_form:"PHYSICIANSIGNOUTFORM"
				}
				
				$scope.loadPatients.get_plist($scope.custom.signout);

			}
			
			if (angular.isDefined(plist_selection) && plist_selection!=null && plist_selection.NAME!="") {

				_.each($scope.signoutData,function(type){
					_.each(type,function(so_config){
						if(so_config.patient_list == plist_selection.NAME ){
							$scope.custom.match_found=true;
							$scope.custom.custom_report = false;
							try{
								$scope.custom.signout = {
									patient_list_id:plist_selection.PATIENT_LIST_ID, // set patient list from passed plist_selection.
									patient_list:so_config.patient_list,
				            		name:so_config.name,
				            		ccl_report:so_config.ccl_report,
									ccl_params:so_config.ccl_params,
									contact:{ ref_id:so_config.contact_info.REF_ID, act_id:so_config.contact_info.ACT_ID },
									signout_folder:so_config.signout_folder,
									signout_form:so_config.signout_form
				            	}
				            	$scope.loadPatients.get_plist($scope.custom.signout);
							}catch(e){alert(e); progressIndicatorService.stopSpinner();}
						}
					});
					if($scope.custom.match_found==false){
						if($scope.plist_selection.NAME.search(/Signout/) == -1){
							$scope.custom.custom_report = true;
						} else {
							$scope.custom.custom_report = false;
						}
						$scope.custom.signout = {
									patient_list_id:plist_selection.PATIENT_LIST_ID, // set patient list from passed plist_selection.
									patient_list:plist_selection.NAME
								}
						$scope.loadPatients.get_plist($scope.custom.signout);
					}
				});
			}
		};


		var set_report_data = function(){

			var report_found = false;
			// update customized form
//alert($scope.custom.signout.name+" is custom.signout.name");
				$scope.custom.signout.ccl_report = "";
				$scope.custom.signout.ccl_params = "";
				$scope.custom.signout.contact = { ref_id:0, act_id:0 };
				$scope.custom.signout.signout_folder = "";
				$scope.custom.signout.signout_form = "";
				_.each($scope.signoutData,function(sod){
					_.each(sod, function(so){

						if(so.name == $scope.custom.signout.name){
							if(so.patient_list == $scope.plist_selection.NAME ){
								$scope.custom.match_found=true;
							} else {
								$scope.custom.match_found=false;
							}
							try{
								$scope.custom.signout.ccl_report 		= so.ccl_report;
								$scope.custom.signout.ccl_params 		= so.ccl_params;
								$scope.custom.signout.contact 			= { ref_id:so.contact_info.REF_ID, act_id:so.contact_info.ACT_ID };
								$scope.custom.signout.signout_folder	= so.signout_folder;
								$scope.custom.signout.signout_form 		= so.signout_form;
								report_found = true;
								update_form_ids()
							}catch(e){console.log(e)}
						}
					});
				});
			

		};

		var update_form_ids = function(){

			if($scope.custom.signout.signout_form != ""){
				var patient_batch = [];
				_.each($scope.custom.signout.patients,function(patient){ 
					patient_batch.push({scriptName: "nmh_signout_get_so_form",prompts: ['',patient.PERSON_ID,patient.ENCNTR_ID,$scope.custom.signout.signout_form]})
				});
				if(patient_batch.length==$scope.custom.signout.patients.length){
					try{
						mpages.loadCCL(patient_batch,
							function(data,done){
								if(data){
									if(data[0].REF_ID>0){ 
										$scope.custom.signout.patients.REF_ID=data[0].REF_ID; 
									} 
									_.each(data,function(form_data){
										var pat = _.find($scope.custom.signout.patients,function(config_pat){
											return config_pat.PERSON_ID == form_data.P_ID
										});

										if(angular.isDefined(pat)){
											pat.ACT_ID = form_data.ACT_ID;
											pat.REF_ID = form_data.REF_ID;
										}
									});

									progressIndicatorService.stopSpinner();
								}
							},
							function(e){alert(e)}
						)
					}catch(e){alert(e);}
				}
			} else {
				progressIndicatorService.stopSpinner();
			}
		}

		return{
			load_reports:load_reports,
			get_patient_list:get_patient_list,
			updt_plist_class:updt_plist_class,
			set_report_data:set_report_data,
			update_form_ids:update_form_ids,
			set_patient_list:set_patient_list
		}

    })();

    //Called by button in Advanced section
	$scope.modifyContact = function($event, custom){
		mpages.execFormLink($event, 48070436, 40126229, custom.signout.contact.ref_id, custom.signout.contact.act_id);
	}

	$scope.slideAdvancedPanel = function(c){
		if(c){
			angular.element('#advanced_panel').slideDown( "slow");
		} else {
			angular.element('#advanced_panel').slideUp( "slow");
		}
	}

	$scope.custom.patient_lists = {};
	$scope.custom.signout = {
		name:"",
		patient_list:"",
		report:"",
		ccl_report:"",
		ccl_params:"",
		contact:{
			ref_id:0,
			act_id:0
		}
	};

});


//fgnass.github.com/spin.js#v1.3.3
!function(a,b){"object"==typeof exports?module.exports=b():"function"==typeof define&&define.amd?define(b):a.Spinner=b()}(this,function(){"use strict";function a(a,b){var c,d=document.createElement(a||"div");for(c in b)d[c]=b[c];return d}function b(a){for(var b=1,c=arguments.length;c>b;b++)a.appendChild(arguments[b]);return a}function c(a,b,c,d){var e=["opacity",b,~~(100*a),c,d].join("-"),f=.01+c/d*100,g=Math.max(1-(1-a)/b*(100-f),a),h=k.substring(0,k.indexOf("Animation")).toLowerCase(),i=h&&"-"+h+"-"||"";return m[e]||(n.insertRule("@"+i+"keyframes "+e+"{0%{opacity:"+g+"}"+f+"%{opacity:"+a+"}"+(f+.01)+"%{opacity:1}"+(f+b)%100+"%{opacity:"+a+"}100%{opacity:"+g+"}}",n.cssRules.length),m[e]=1),e}function d(a,b){var c,d,e=a.style;for(b=b.charAt(0).toUpperCase()+b.slice(1),d=0;d<l.length;d++)if(c=l[d]+b,void 0!==e[c])return c;return void 0!==e[b]?b:void 0}function e(a,b){for(var c in b)a.style[d(a,c)||c]=b[c];return a}function f(a){for(var b=1;b<arguments.length;b++){var c=arguments[b];for(var d in c)void 0===a[d]&&(a[d]=c[d])}return a}function g(a){for(var b={x:a.offsetLeft,y:a.offsetTop};a=a.offsetParent;)b.x+=a.offsetLeft,b.y+=a.offsetTop;return b}function h(a,b){return"string"==typeof a?a:a[b%a.length]}function i(a){return"undefined"==typeof this?new i(a):(this.opts=f(a||{},i.defaults,o),void 0)}function j(){function c(b,c){return a("<"+b+' xmlns="urn:schemas-microsoft.com:vml" class="spin-vml">',c)}n.addRule(".spin-vml","behavior:url(#default#VML)"),i.prototype.lines=function(a,d){function f(){return e(c("group",{coordsize:k+" "+k,coordorigin:-j+" "+-j}),{width:k,height:k})}function g(a,g,i){b(m,b(e(f(),{rotation:360/d.lines*a+"deg",left:~~g}),b(e(c("roundrect",{arcsize:d.corners}),{width:j,height:d.width,left:d.radius,top:-d.width>>1,filter:i}),c("fill",{color:h(d.color,a),opacity:d.opacity}),c("stroke",{opacity:0}))))}var i,j=d.length+d.width,k=2*j,l=2*-(d.width+d.length)+"px",m=e(f(),{position:"absolute",top:l,left:l});if(d.shadow)for(i=1;i<=d.lines;i++)g(i,-2,"progid:DXImageTransform.Microsoft.Blur(pixelradius=2,makeshadow=1,shadowopacity=.3)");for(i=1;i<=d.lines;i++)g(i);return b(a,m)},i.prototype.opacity=function(a,b,c,d){var e=a.firstChild;d=d.shadow&&d.lines||0,e&&b+d<e.childNodes.length&&(e=e.childNodes[b+d],e=e&&e.firstChild,e=e&&e.firstChild,e&&(e.opacity=c))}}var k,l=["webkit","Moz","ms","O"],m={},n=function(){var c=a("style",{type:"text/css"});return b(document.getElementsByTagName("head")[0],c),c.sheet||c.styleSheet}(),o={lines:12,length:7,width:5,radius:10,rotate:0,corners:1,color:"#000",direction:1,speed:1,trail:100,opacity:.25,fps:20,zIndex:2e9,className:"spinner",top:"auto",left:"auto",position:"relative"};i.defaults={},f(i.prototype,{spin:function(b){this.stop();var c,d,f=this,h=f.opts,i=f.el=e(a(0,{className:h.className}),{position:h.position,width:0,zIndex:h.zIndex}),j=h.radius+h.length+h.width;if(b&&(b.insertBefore(i,b.firstChild||null),d=g(b),c=g(i),e(i,{left:("auto"==h.left?d.x-c.x+(b.offsetWidth>>1):parseInt(h.left,10)+j)+"px",top:("auto"==h.top?d.y-c.y+(b.offsetHeight>>1):parseInt(h.top,10)+j)+"px"})),i.setAttribute("role","progressbar"),f.lines(i,f.opts),!k){var l,m=0,n=(h.lines-1)*(1-h.direction)/2,o=h.fps,p=o/h.speed,q=(1-h.opacity)/(p*h.trail/100),r=p/h.lines;!function s(){m++;for(var a=0;a<h.lines;a++)l=Math.max(1-(m+(h.lines-a)*r)%p*q,h.opacity),f.opacity(i,a*h.direction+n,l,h);f.timeout=f.el&&setTimeout(s,~~(1e3/o))}()}return f},stop:function(){var a=this.el;return a&&(clearTimeout(this.timeout),a.parentNode&&a.parentNode.removeChild(a),this.el=void 0),this},lines:function(d,f){function g(b,c){return e(a(),{position:"absolute",width:f.length+f.width+"px",height:f.width+"px",background:b,boxShadow:c,transformOrigin:"left",transform:"rotate("+~~(360/f.lines*j+f.rotate)+"deg) translate("+f.radius+"px,0)",borderRadius:(f.corners*f.width>>1)+"px"})}for(var i,j=0,l=(f.lines-1)*(1-f.direction)/2;j<f.lines;j++)i=e(a(),{position:"absolute",top:1+~(f.width/2)+"px",transform:f.hwaccel?"translate3d(0,0,0)":"",opacity:f.opacity,animation:k&&c(f.opacity,f.trail,l+j*f.direction,f.lines)+" "+1/f.speed+"s linear infinite"}),f.shadow&&b(i,e(g("#000","0 0 4px #000"),{top:"2px"})),b(d,b(i,g(h(f.color,j),"0 0 1px rgba(0,0,0,.1)")));return d},opacity:function(a,b,c){b<a.childNodes.length&&(a.childNodes[b].style.opacity=c)}});var p=e(a("group"),{behavior:"url(#default#VML)"});return!d(p,"transform")&&p.adj?j():k=d(p,"animation"),i});