'use strict';
/*
    This app uses nmh_get_tdb_request which is a CCL wrapper that calls the same services used by the N BB Product Dispense, and ORV apps in this instance.

    1. Due to how integers need to be formatted in CCL(must have ".00" after the floating number), certain parameters that we pass to nmh_get_tdb_request need to be encapsulated by a prefix and suffix string.
    "F8BEG" is the first string
    "F8ERND" is the last string
    This is used for passing the SERVICE_RESOURCE_CD, PERSON_ID, and ACTIVITY_TYPES, ORDER_ID only when using nmh_get_tdb_request

    2.For passing dq8 dates we need to do the same thing but use a different prefix/suffix.
    "DQ8BEG" is the first string
    "DQ8END" is the end string
    This is used by the COLLECT_DT_TM_BEGIN, and COLLECT_DT_TM_END variables only when using nmh_get_tdb_request
*/

var app = angular.module('bloodBankDispensary',['mpages']);

app.factory('progressIndicatorService', function() {
    var target = angular.element('#progressIndicator')[0];
    var spinner = new Spinner({color:'#61468B', hwaccelBoolean: true});
    return {
        startSpinner: function() {
            $(target).fadeIn('slow');
            spinner.spin(target);
        },
        stopSpinner:function () {
            $(target).fadeOut('fast');
            spinner.stop();
        }
    };
});

app.controller('bloodBankController',function($scope, mpages, progressIndicatorService, $timeout){

    $scope.pObj = {};
    $scope.idErrors = [];

    $scope.fac = [
	    {name:'Northwestern Memorial Hospital', display:'N BB Product Dispense'},
	    {name:'Northwestern Lake Forest Hospital', display:'LF BBK Product Orders Bench'}
  	];
	$scope.fac_selected = $scope.fac[0];

    $scope.numLimit = 125;
    $scope.readDiagnosis = function(numLimit){
        $scope.readMore = !$scope.readMore;
        $scope.numLimit = numLimit == 10000 ? $scope.numLimit = 125 : $scope.numLimit = 10000;
    };

    var hyphen = "-";

    var loadNewPatients = setInterval(function(){
        if (angular.element("#container_top").is(":visible")){
            $scope.$apply(function() {
                $scope.loadFac($scope.fac_selected);
            });
        }
    }, 90000);

    $scope.$on('$destroy', function(){
        clearInterval(loadNewPatients);
    });
    $scope.$on('$locationChangeStart', function(){
       clearInterval(loadNewPatients);
    });

 	$scope.loadFac = function(facility){
  		angular.element("#container_fac").fadeOut();
        if (angular.element("#container_top").is(":visible")) angular.element("#container_top").fadeOut('fast');

	    var SERVICE_REQUEST_DISPENSE = {};
	    SERVICE_REQUEST_DISPENSE.TEMP = {
	        "ACTIVE_FLAG" : 0,
	        "DISPLAY" : facility,
	        "CATALOG_CD" : 0.000000,
	        "ACCESSION" : "",
	        "ACT_TYPE_MEANS" : [],
	        "ACT_SUB_MEANS" : [],
	        "LOCATION_CD" : 0.000000,
	        "BEGINSTRING" : "",
	        "LEVELFLAG" : 3,
	        "NUMBER_TO_RETURN" : 0,
	        "CATALOG_CDS" : [],
	        "TASK_ASSAY_CDS" : [],
	        "ORGANIZATIONS" : [],
	        "RESOURCE_SECURITY_IND" : 1
	    };

	    var CCLPending =[
	        //Pending Inquiries - N BB Product Dispense - from Pathnet(OrderResultsViewer.exe) to get "SERVICE_RESOURCE_CD"
	        {recordName:'pending_n_bb_productdispense',scriptName:'nmh_get_tdb_request',prompts: ["MINE", 250007,250017,250090, SERVICE_REQUEST_DISPENSE]}
        ];

	    mpages.progressbar.start();

	    mpages.loadCCL(CCLPending,
	        function (data,done){
	            if(done){

	                var SERVICE_REQUEST_DISPENSE2 = {};
	                SERVICE_REQUEST_DISPENSE2.TEMP2 = {
	                    "NBR_TO_GET" : 0,
	                    "SERVICE_RESOURCE_CD" : "F8BEG"+mpages.data.pending_n_bb_productdispense.QUAL[0].SERVICE_RESOURCE_CD+"F8END",
	                    "CATALOG_CD" : 0,
	                    "IN_LAB_ONLY_IND" : 0,
	                    "BATCH_SELECTION" : "",
	                    "OUTPUT_DIST" : "",
	                    "RESOURCE_SEC_IND" : 1,
	                    "STATUS_FLAG" : 0
	                };

	                var CCLPendingCoded =[
	                    //Pending Inquiries passing "SERVICE_RESOURCE_CD" to get list of patients from PathNET app
	                    {recordName:'pending_n_bb_productdispense2',scriptName:'nmh_get_tdb_request',prompts: ["MINE", 250007,250006,250060, SERVICE_REQUEST_DISPENSE2]}
	                ];

	                mpages.loadCCL(CCLPendingCoded,
	                    function (data,done){

	                        var BLOODPATIENTS = {};
	                        var a = [];

	                        if (mpages.data.pending_n_bb_productdispense2.PEND_LIST.length > 0){
	                            for (var i = 0; i < mpages.data.pending_n_bb_productdispense2.PEND_LIST.length; i++){
	                                var receivedDate = new Date(mpages.dq8(mpages.data.pending_n_bb_productdispense2.PEND_LIST[i].RECEIVED_DT_TM)).getFullYear() != 1899 ? mpages.dq8(mpages.data.pending_n_bb_productdispense2.PEND_LIST[i].RECEIVED_DT_TM).format('m/d/Y H:i') : "";
	                                var acc = mpages.data.pending_n_bb_productdispense2.PEND_LIST[i].ACCESSION.replace("0000120", "1-");
	                                var accession = [acc.slice(0, 4), hyphen, acc.slice(4,7), hyphen, acc.slice(8, 13)].join('');
	                                a.push({
	                                    RECEIVED_DT_TM: receivedDate,
	                                    ORDER_MNEMONIC: mpages.data.pending_n_bb_productdispense2.PEND_LIST[i].ORDER_MNEMONIC,
	                                    REPORT_PRIORITY_DISP: mpages.data.pending_n_bb_productdispense2.PEND_LIST[i].REPORT_PRIORITY_DISP,
	                                    ACCESSION: accession,
	                                    NAME_FULL_FORMATTED: mpages.data.pending_n_bb_productdispense2.PEND_LIST[i].NAME_FULL_FORMATTED,
	                                    MRN_ALIAS: mpages.data.pending_n_bb_productdispense2.PEND_LIST[i].MRN_ALIAS,
	                                    CONTAINER_LOCATION_DISP: mpages.data.pending_n_bb_productdispense2.PEND_LIST[i].CONTAINER_LOCATION_DISP,
	                                    PERSON_ID: mpages.data.pending_n_bb_productdispense2.PEND_LIST[i].PERSON_ID,
	                                    ENCNTR_ID: mpages.data.pending_n_bb_productdispense2.PEND_LIST[i].ENCNTR_ID
	                                });
	                            }
	                        }

	                        BLOODPATIENTS = a;
	                        $scope.BLOODPATIENTS = BLOODPATIENTS;

	                        mpages.progressbar.complete();
	                        angular.element('#container_top').fadeIn('fast', function() { angular.element("#patientRefresh").fadeIn('fast');});
	                    }, function(error){ alert(error.requestText); $scope.idErrors.push(error.requestText); }
	                );
	            }
	        }, function(error){ alert(error.requestText);$scope.idErrors.push(error.requestText); }
	    );
        var now = new Date();
        var date = [ now.getMonth() + 1, now.getDate(), now.getFullYear() ];
        var time = [ now.getHours(), now.getMinutes(), now.getSeconds() ];
        var suffix = ( time[0] < 12 ) ? "AM" : "PM";
        time[0] = ( time[0] < 12 ) ? time[0] : time[0] - 12;
        time[0] = time[0] || 12;
        for ( var i = 1; i < 3; i++ ) {
            if ( time[i] < 10 ) {
                time[i] = "0" + time[i];
            }
        }
        $scope.lastLoaded = date.join("/") + " " + time.join(":") + " " + suffix;
	}

    function apptsDate(){
        var d = new Date();
        d.setDate(d.getDate() - 30);
        return d.format('d-M-Y');
    }

    $scope.formatMyDate = function(x){// make all dates consistent
    	var formattedDate = new Date(x);
		var m =  formattedDate.getMonth();
		m += 1;
		m = m < 10 ? "0" + m : m;
		var d = formattedDate.getDate();
		d = d < 10 ? "0" + d : d;
		var y = "20"+formattedDate.getYear();
        var h = formattedDate.getHours() ? (formattedDate.getHours() < 10 ? "0" : "") + formattedDate.getHours() + ":" : "00:";

        var mi = formattedDate.getMinutes() ? (formattedDate.getMinutes() < 10 ? "0" : "") + formattedDate.getMinutes() : "00";
        if (h == "00" && mi == "00") h = mi = "";
		formattedDate = m + "/" + d + "/" + y + " "+h+mi;
        formattedDate = new Date(x).getFullYear() != 1899 ? formattedDate : "";
        return formattedDate;
    }

    $scope.htmlify = function(format){
        var format = $('<span />').html(format).text();
        return format;
    }

    $scope.loadPatient = function (p,e){
        progressIndicatorService.startSpinner();
        angular.element("#loadingPercentage").html("Loading: 10%...");
        if ($("#container_bottom").is(':visible')) $("#container_bottom").fadeOut(500);

        var today = new Date().format('d-M-Y').toUpperCase();
        var past = new Date();
        past.setDate(past.getDate() - 30);
        past = past.format('d-M-Y').toUpperCase();

        var activity_type_code = 287;

        var SERVICE_REQUEST_ORV = {};
        SERVICE_REQUEST_ORV.TEMP = {
            PERSON_ID : "F8BEG"+p+"F8END",
            COLLECT_DT_TM_BEGIN : "DQ8BEG"+past+" 00:00DQ8END",
            COLLECT_DT_TM_END :  "DQ8BEG"+today+" 23:59:59DQ8END",
            ACTIVITY_TYPES : [{"ACTIVITY_TYPE_CD" : "F8BEG"+activity_type_code+"F8END"}],
            CATALOG_CD : 0,
            ENCOUNTER_ID : 0,
            ORD_RQSTN_ID : 0
        };

        var SERVICE_REQUEST_DIAGNOSIS = {};
        SERVICE_REQUEST_DIAGNOSIS.TEMP =  {
            PERSON_ID : "F8BEG"+p+"F8END",
            ENCOUNTER_ID : 0 ///This is required even though the script is not expecting it
        };

        var SERVICE_REQUEST_AUTODIRECTED = {};
        SERVICE_REQUEST_AUTODIRECTED.TEMP = {
            "PERSON_ID" : "F8BEG"+p+"F8END",
            "RETRIEVE_DATA" : "T",
            "FACILITY_CD" : 0.000000
        };

        var CCLScripts = [
            {recordName:"demographics",scriptName: "nmh_get_patient_demographics",prompts:["MINE", "", p, e]},
            {recordName:'blood',scriptName:'nmh_mp_get_bloodbank_summary',prompts: ["MINE", p, e]},
            {recordName:'autodirected',scriptName:'nmh_get_tdb_request',prompts: ["MINE", 225030,225109,225571, SERVICE_REQUEST_AUTODIRECTED]},
            {recordName:'orders_to_dispense',scriptName:'nmh_get_tdb_request',prompts: ["MINE", 250005, 250002, 250148, SERVICE_REQUEST_ORV]},
            {recordName:'diagnosis',scriptName:'nmh_get_tdb_request',prompts: ["MINE", 250005, 200043, 200329, SERVICE_REQUEST_DIAGNOSIS]},
            {recordName:'appts',scriptName:'nmh_get_patient_appts',prompts: ["MINE", p,'ONCTRANSFUSIONRBCS2UNITSLF|ONCTRANSFUSIONRBCSPLTLF|RWCEXCHANGETRANSFUSION|RWCEXCHANGETRANSFUSIONBEDSIDE|RWCTRANSFUSION1UNIT|RWCTRANSFUSION2UNIT|RWCTRANSFUSION3UNIT',apptsDate()]},
            {recordName:'transfuse_blood_product',scriptName:'nmh_get_orders_data',prompts: [p, e,'','','TRANSFUSEBLOODPRODUCTNURSECARE','','','YES','','BLOODBANK','','YES','','']}
        ];
        angular.element("#loadingPercentage").html("Loading: 30%...");
        mpages.loadCCL(CCLScripts,
            function(data,done){
                if(done){
                    angular.element("#loadingPercentage").html("Percentage Loaded: 60%...Parsing Data");

                    /******DEMOGRAPHICS***********/
                    $scope.location = "";
                    $scope.diagnosis = "";

                    if(mpages.data.demographics.UNIT){
                        $scope.location += 'UNIT: ' + mpages.data.demographics.UNIT;
                    }
                    if(mpages.data.demographics.UNIT && (mpages.data.demographics.ROOM || mpages.data.demographics.BED)){
                         $scope.location += ","
                    }
                    if(mpages.data.demographics.ROOM){
                        $scope.location += ' ROOM: ' + mpages.data.demographics.ROOM;
                    }
                        if(mpages.data.demographics.ROOM && (mpages.data.demographics.UNIT || mpages.data.demographics.BED)){
                         $scope.location += ",";
                    }
                    if(mpages.data.demographics.BED){
                        $scope.location +=  ' BED: ' + mpages.data.demographics.BED;
                    }
                    if(mpages.data.diagnosis.ENCOUNTER_QUAL.length > 0){
                        for(var d=0; d < mpages.data.diagnosis.ENCOUNTER_QUAL.length; d++){
                            if(mpages.data.diagnosis.ENCOUNTER_QUAL[d].REASON_FOR_VISIT != ""){
                                $scope.diagnosis += mpages.data.diagnosis.ENCOUNTER_QUAL[d].REASON_FOR_VISIT;
                                $scope.diagnosis = $('<span />').html($scope.diagnosis).text();
                                if(d != (mpages.data.diagnosis.ENCOUNTER_QUAL.length-1)){
                                    $scope.diagnosis += ", ";
                                }
                            }
                        }
                    }

                    /******Assigned Products with Autologous/Directed and Crossmatched (REPLY)********/
                    /******CROSSMATCHED without auto/directed********/
                    $scope.CROSSMATCH = {};
                    var CROSSMATCHED = [];
                    if (mpages.data.blood.CPROD_CNT > 0){
                        for (var z = 0; z < mpages.data.blood.CROSS_QUAL.length; z++){
                            CROSSMATCHED.push({
                                DATETIME : mpages.data.blood.CROSS_QUAL[z].CROSSMATCH,
                                PRODUCT: mpages.data.blood.CROSS_QUAL[z].TYPE,
                                UNIT : mpages.data.blood.CROSS_QUAL[z].NUMBER,
                                TYPE : mpages.data.blood.CROSS_QUAL[z].ABORH,
                                LOCATION : mpages.data.blood.CROSS_QUAL[z].LOCATION,
                                ATTRIB : mpages.data.blood.CROSS_QUAL[z].ATTRIB
                            });
                        }
                    }

                    /******Auto/Directed********/
                    var tempAutoDirectCrossmatched = [];
                    var AUTODIRECTED = [];
                    if (mpages.data.autodirected.QUAL.length > 0){
                        for (var z = 0; z < mpages.data.autodirected.QUAL.length; z++){
                            for (var ad = 0; ad < mpages.data.autodirected.QUAL[z].QUAL2.length; ad++){
                                var autologous_directed = mpages.data.autodirected.QUAL[z].QUAL2[ad].EVENT_TYPE_DISP;
                            }
                            if(autologous_directed == "Crossmatched"){
                                tempAutoDirectCrossmatched.push({
                                    UNIT : mpages.data.autodirected.QUAL[z].PRODUCT_NBR
                                })
                            } else {
                                AUTODIRECTED.push({
                                    ASSIGNED : mpages.dq8(mpages.data.autodirected.QUAL[z].EXPECTED_USAGE_DT_TM).format('m/d/Y H:i') + " (Expected Usage)",
                                    TYPE : mpages.data.autodirected.QUAL[z].PRODUCT_DISP,
                                    NUMBER : mpages.data.autodirected.QUAL[z].PRODUCT_NBR,
                                    ABORH : mpages.data.autodirected.QUAL[z].CUR_ABO_DISP+" "+mpages.data.autodirected.QUAL[z].CUR_RH_DISP,
                                    LOCATION : autologous_directed,
                                    QUANTITY : autologous_directed,
                                    ATTRIB : autologous_directed
                                });
                            }
                        }
                    }

                    /******DISPENSED PRODUCTS********/
                    $scope.DISPENSEDPRODUCTS = {};
                    var DISPENSED = [];
                    if (mpages.data.blood.DPROD_CNT > 0){
                        for (var z = 0; z < mpages.data.blood.DISP_QUAL.length; z++){
                            var autologous_directed = "";
                            for (var a = 0; a < AUTODIRECTED.length; a++){
                                if(AUTODIRECTED[a].NUMBER == mpages.data.blood.DISP_QUAL[z].NUMBER){
                                    autologous_directed = " ("+AUTODIRECTED[a].ATTRIB+")";
                                    AUTODIRECTED.splice(a, 1);
                                }
                            }
                            DISPENSED.push({
                                DISPENSED : mpages.data.blood.DISP_QUAL[z].DISPENSED,
                                TYPE : mpages.data.blood.DISP_QUAL[z].TYPE+autologous_directed,
                                NUMBER : mpages.data.blood.DISP_QUAL[z].NUMBER,
                                ABORH : mpages.data.blood.DISP_QUAL[z].ABORH,
                                LOCATION : mpages.data.blood.DISP_QUAL[z].LOCATION,
                                QUANTITY : mpages.data.blood.DISP_QUAL[z].QUANTITY,
                                ATTRIB : mpages.data.blood.DISP_QUAL[z].ATTRIB
                            });
                        }
                    }

                    /******TRANSFUSED PRODUCTS********///Red Indicator no longer wanted
                    var TRANSFUSEDPRODUCTS = {};
                    var TPRODUCTS = [];

                    if (mpages.data.blood.TRANS_CNT > 0){
                        for (var z = 0; z < mpages.data.blood.TRANS_CNT; z++){
                            var autologous_directed = "";
                            for (var a = 0; a < AUTODIRECTED.length; a++){
                                if(AUTODIRECTED[a].NUMBER == mpages.data.blood.TRANS_QUAL[z].NUMBER){
                                    autologous_directed = " ("+AUTODIRECTED[a].ATTRIB+")";
                                    AUTODIRECTED.splice(a, 1);
                                }
                            }
                            TPRODUCTS.push({
                                TRANSFUSED : mpages.data.blood.TRANS_QUAL[z].TRANSFUSED,
                                TYPE: mpages.data.blood.TRANS_QUAL[z].TYPE+autologous_directed,
                                NUMBER : mpages.data.blood.TRANS_QUAL[z].NUMBER,
                                ABORH : mpages.data.blood.TRANS_QUAL[z].ABORH,
                                LOCATION : mpages.data.blood.TRANS_QUAL[z].LOCATION,
                                QUANTITY : mpages.data.blood.TRANS_QUAL[z].QUANTITY,
                                ATTRIB : $('<span />').html(mpages.data.blood.TRANS_QUAL[z].ATTRIB).text()
                            });
                        }
                    }

                    /******Crossmatched with Auto/Directed and Assigned PRODUCTS********/
                    $scope.ASSIGNEDPRODUCTS = {};
                    var ASSIGNED = [];
                    if (mpages.data.blood.APROD_CNT > 0){
                        for (var z = 0; z < mpages.data.blood.ASSIGN_QUAL.length; z++){
                            var checkMatch = false;
                            for (var a = 0; a < tempAutoDirectCrossmatched.length; a++){
                                if(tempAutoDirectCrossmatched[a].UNIT == mpages.data.blood.ASSIGN_QUAL[z].NUMBER){
                                   CROSSMATCHED.push({
                                        DATETIME :  mpages.data.blood.ASSIGN_QUAL[z].ASSIGNED,
                                        PRODUCT: mpages.data.blood.ASSIGN_QUAL[z].TYPE,
                                        UNIT : mpages.data.blood.ASSIGN_QUAL[z].NUMBER,
                                        TYPE : mpages.data.blood.ASSIGN_QUAL[z].ABORH,
                                        LOCATION : mpages.data.blood.ASSIGN_QUAL[z].LOCATION,
                                        ATTRIB : $('<span />').html(mpages.data.blood.ASSIGN_QUAL[z].ATTRIB).text()
                                    });
                                   checkMatch = true;
                                   break;
                                }
                            }
                            if(checkMatch == false){
                                ASSIGNED.push({
                                    ASSIGNED : mpages.data.blood.ASSIGN_QUAL[z].ASSIGNED,
                                    TYPE : mpages.data.blood.ASSIGN_QUAL[z].TYPE,
                                    NUMBER : mpages.data.blood.ASSIGN_QUAL[z].NUMBER,
                                    ABORH : mpages.data.blood.ASSIGN_QUAL[z].ABORH,
                                    LOCATION : mpages.data.blood.ASSIGN_QUAL[z].LOCATION,
                                    QUANTITY : mpages.data.blood.ASSIGN_QUAL[z].QUANTITY,
                                    ATTRIB : $('<span />').html(mpages.data.blood.ASSIGN_QUAL[z].ATTRIB).text()
                                });
                            }
                        }
                    }



                    $scope.TRANSFUSEDPRODUCTS = TPRODUCTS;
                    $scope.CROSSMATCH = CROSSMATCHED;
                    $scope.ASSIGNEDPRODUCTS = ASSIGNED.concat(AUTODIRECTED);
                    $scope.DISPENSEDPRODUCTS = DISPENSED;


                    /******ORDERS to Dispense and Specimen History********/
                    $scope.ORDERABLES = [];////ORDERS TO DISPENSE
                    $scope.SPECIMENS = [];////SPECIMEN HISTORY

                    if (mpages.data.orders_to_dispense.QUAL_CNT > 0){

                        /******ORDERS TO DISPENSE********/
                        var ORDERTYPES = ["DCRYOa", "DCRYOi", "DGran", "DPLASi", "DPLASa", "DPLTa", "DPLTi", "DRBCa", "DRBCi", "DRhIg", "DVessel", "Issue Multiple Blood Products (Emergency)"];

                        for (var i = 0; i < mpages.data.orders_to_dispense.QUAL_CNT; i++){
                            if($.inArray(mpages.data.orders_to_dispense.QUAL[i].ORDER_MNEMONIC, ORDERTYPES) != -1){
                                var acc = mpages.data.orders_to_dispense.QUAL[i].ACCESSION.replace("0000120", "1-");
                                var accession = [acc.slice(0, 4), hyphen, acc.slice(4,7), hyphen, acc.slice(8, 13)].join('');
                                var collectedDate = new Date(mpages.dq8(mpages.data.orders_to_dispense.QUAL[i].DRAWN_DT_TM)).getFullYear() != 1899 ? mpages.dq8(mpages.data.orders_to_dispense.QUAL[i].DRAWN_DT_TM).format('m/d/Y H:i') : "";

                                $scope.ORDERABLES.push({
                                    orders: mpages.data.orders_to_dispense.QUAL[i].ORDER_ID,
                                    accession: accession,
                                    COLLECTED: collectedDate,
                                    STATUS: mpages.data.orders_to_dispense.QUAL[i].ORDER_STATUS_DISP
                                });
                            }
                        }

                        /****SPECIMEN HISTORY****/
                        var SPECIMENTYPES = ["BCODE", "DHOLD", "ABRH", "ABSC"];//must add ABSC order to get the ABSC Interp data

                        for (var s = 0; s < mpages.data.orders_to_dispense.QUAL_CNT; s++){
                            if($.inArray(mpages.data.orders_to_dispense.QUAL[s].ORDER_MNEMONIC, SPECIMENTYPES) != -1){
                                var acc = mpages.data.orders_to_dispense.QUAL[s].ACCESSION.replace("0000120", "1-");
                                var accession = [acc.slice(0, 4), hyphen, acc.slice(4,7), hyphen, acc.slice(8, 13)].join('');
                                var collectedDate = new Date(mpages.dq8(mpages.data.orders_to_dispense.QUAL[s].DRAWN_DT_TM)).getFullYear() != 1899 ? mpages.dq8(mpages.data.orders_to_dispense.QUAL[s].DRAWN_DT_TM).format('m/d/Y H:i') : "";

                                $scope.SPECIMENS.push({
                                    orders: mpages.data.orders_to_dispense.QUAL[s].ORDER_ID,
                                    accession: accession,
                                    COLLECTED: collectedDate,
                                    STATUS: mpages.data.orders_to_dispense.QUAL[s].ORDER_STATUS_DISP
                                });
                            }
                        }
                    }

                    /****ORDERS TO DISPENSE (Request)****/
                    $scope.SPECIMENHISTORY = [];//set this here so Specimen History table in html will not display header if not needed

                    if($scope.ORDERABLES.length > 0 || $scope.SPECIMENS.length > 0){
                        var ALLORDERABLES = {};
                        var ALLSPECIMENS = {};
                        var CCLOrdersScripts = [];

                        for (var x = 0; x < $scope.ORDERABLES.length; x++){
                            ALLORDERABLES["SERVICE_REQUEST_ORV"+x] = {};
                            ALLORDERABLES["SERVICE_REQUEST_ORV"+x].TEMP = {};
                            ALLORDERABLES["SERVICE_REQUEST_ORV"+x].TEMP = {
                                "ORDER_ID" : "F8BEG"+$scope.ORDERABLES[x].orders+"F8END",
                                "ENTIRE_ACCESSION_IND" : 1
                            }
                            CCLOrdersScripts.push({recordName:'orders_to_dispense'+x,scriptName:'nmh_get_tdb_request',prompts: ["MINE", 250005, 225157, 225082, ALLORDERABLES["SERVICE_REQUEST_ORV"+x]]});
                        }
                         /****SPECIMEN HISTORY (Request)****/
                        for (var x = 0; x < $scope.SPECIMENS.length; x++){
                            ALLSPECIMENS["SERVICE_REQUEST_ORV"+x] = {};
                            ALLSPECIMENS["SERVICE_REQUEST_ORV"+x].TEMP = {};
                            ALLSPECIMENS["SERVICE_REQUEST_ORV"+x].TEMP = {
                                "ORDER_ID" : "F8BEG"+$scope.SPECIMENS[x].orders+"F8END",
                                "ENTIRE_ACCESSION_IND" : 1
                            }
                            CCLOrdersScripts.push({recordName:'specimen_history'+x,scriptName:'nmh_get_tdb_request',prompts: ["MINE", 250005, 225157, 225082, ALLSPECIMENS["SERVICE_REQUEST_ORV"+x]]});
                        }

                        p = 60;
                        mpages.loadCCL(CCLOrdersScripts,
                            function(data,done){
                            	if(data){
                            		remainPercentage = 20/CCLOrdersScripts.length;
                            		p=p+remainPercentage;
			            			angular.element("#loadingPercentage").html("Percentage Loaded: "+p+"%");
			            		}
                                if(done){
			            			angular.element("#loadingPercentage").html("Percentage Loaded: 100%... Parsing Data...");
                                    /******ORDERS TO DISPENSE (Reply) ********/
                                    var ORDERSTODISPENSE = {};
                                    var ORDERSDETAILS = [];

                                    for (var e = 0; e < $scope.ORDERABLES.length; e++){
                                        if (mpages.data["orders_to_dispense"+e].QUAL[0].ASSAYS_CNT > 0){
                                            var NUMOFDOSES, PTUBESTATION, CONTACTPHONE;
                                            NUMOFDOSES = PTUBESTATION = CONTACTPHONE = "";
                                            for (var z = 0; z < mpages.data["orders_to_dispense"+e].QUAL[0].ASSAYS_CNT; z++){
                                                if(mpages.data["orders_to_dispense"+e].QUAL[0].ASSAYS[z].TASK_ASSAY_DISP == "&#35; of Doses"){
                                                    NUMOFDOSES = mpages.data["orders_to_dispense"+e].QUAL[0].ASSAYS[z].RESULT[0].RESULT_VALUE_ALPHA;
                                                    /*collectedDate = new Date(mpages.dq8(mpages.data["orders_to_dispense"+e].QUAL[0].ASSAYS[z].RESULT[0].PERFORM_DT_TM)).getFullYear() != 1899 ? mpages.dq8(mpages.data["orders_to_dispense"+e].QUAL[0].ASSAYS[z].RESULT[0].PERFORM_DT_TM).format('m/d/Y H:i') : "";*/
                                                }
                                                if(mpages.data["orders_to_dispense"+e].QUAL[0].ASSAYS[z].TASK_ASSAY_DISP == "P-Tube Station"){
                                                    PTUBESTATION = mpages.data["orders_to_dispense"+e].QUAL[0].ASSAYS[z].RESULT[0].ASCII_TEXT;
                                                    PTUBESTATION = $('<span />').html(PTUBESTATION).text();
                                                }
                                                if(mpages.data["orders_to_dispense"+e].QUAL[0].ASSAYS[z].TASK_ASSAY_DISP == "Contact Phone &#35;"){
                                                    CONTACTPHONE = mpages.data["orders_to_dispense"+e].QUAL[0].ASSAYS[z].RESULT[0].ASCII_TEXT;
                                                }
                                            }

                                            if (mpages.data["orders_to_dispense"+e].QUAL[0].ORDER_MNEMONIC != "AddRBCa" && mpages.data["orders_to_dispense"+e].QUAL[0].ORDER_MNEMONIC != "PLTa"){
                                                ORDERSDETAILS.push({
                                                    RESULT_VALUE_DT_TM : $scope.ORDERABLES[e].COLLECTED,
                                                    ACCESSION: $scope.ORDERABLES[e].accession,
                                                    ORDER : mpages.data["orders_to_dispense"+e].QUAL[0].ORDER_MNEMONIC,
                                                    NUMOFDOSES : NUMOFDOSES,
                                                    PTUBESTATION : PTUBESTATION,
                                                    CONTACTPHONE : CONTACTPHONE
                                                });
                                            }
                                        }

                                        if(!ORDERSDETAILS[e] == undefined){//dont display if there is no Collected Date/Time
                                            ORDERSDETAILS.splice(e, 1);
                                        }
                                        try {
                                            //user has rtf blob data from a 'comment' recorded in OrderResultsViewer app
                                            if(ORDERSDETAILS[e].RESULT_VALUE_DT_TM == ""){
                                                ORDERSDETAILS.splice(e, 1);
                                            }
                                        } catch(err) {
                                            console.log(err.message)
                                            ORDERSDETAILS.splice(e, 1);
                                        }

                                    }

                                    $scope.ORDERSTODISPENSE = ORDERSDETAILS;

                                    /******SPECIMEN HISTORY (Reply) ********/
                                    var SPECIMENDETAILS = [];

                                    for (var e = 0; e < $scope.SPECIMENS.length; e++){

                                        if($.isEmptyObject(mpages.data["specimen_history"+e].QUAL) != true){//sometimes there are empty orders

                                            SPECIMENDETAILS[e] = {
                                                RESULT_VALUE_DT_TM : "",
                                                ACCESSION : "",
                                                BBID : "",
                                                ABORHTYPE : "",
                                                ABSCINTERP : "",
                                                EXPIRATION : ""
                                            }

                                            for (var q = 0; q < mpages.data["specimen_history"+e].QUAL.length; q++){

                                                ///Need to check if only specified specimen types due to orders returning different order id when in an order set
                                                if($.inArray(mpages.data["specimen_history"+e].QUAL[q].ORDER_MNEMONIC, SPECIMENTYPES) != -1){

                                                    if (mpages.data["specimen_history"+e].QUAL[q].ASSAYS_CNT > 0){

                                                        var ACCESSION, BBID, ABORHTYPE, ABSCINTERP, EXPIRATION;
                                                        ACCESSION = BBID = ABORHTYPE = ABSCINTERP =  EXPIRATION = "" ;

                                                        if(SPECIMENDETAILS[e].ACCESSION == "" || SPECIMENDETAILS[e].ACCESSION == undefined){
                                                            SPECIMENDETAILS[e].ACCESSION = $scope.SPECIMENS[e].accession;
                                                        }
                                                        if(SPECIMENDETAILS[e].RESULT_VALUE_DT_TM == "" || SPECIMENDETAILS[e].RESULT_VALUE_DT_TM == undefined){
                                                            SPECIMENDETAILS[e].RESULT_VALUE_DT_TM = $scope.SPECIMENS[e].COLLECTED;
                                                        }


                                                        for (var z = 0; z < mpages.data["specimen_history"+e].QUAL[q].ASSAYS_CNT; z++){

                                                            if(mpages.data["specimen_history"+e].QUAL[q].ASSAYS[z].TASK_ASSAY_DISP == "BBID"){
                                                                if(SPECIMENDETAILS[e].BBID == "" || SPECIMENDETAILS[e].BBID == undefined){
                                                                    BBID = mpages.data["specimen_history"+e].QUAL[q].ASSAYS[z].RESULT[0].ASCII_TEXT;
                                                                    BBID = $('<span />').html(BBID).text();

                                                                    SPECIMENDETAILS[e].BBID = BBID;
                                                                }
                                                            }

                                                            if(mpages.data["specimen_history"+e].QUAL[q].ASSAYS[z].TASK_ASSAY_DISP == "TT ABORh"){
                                                                if(SPECIMENDETAILS[e].ABORHTYPE == "" || SPECIMENDETAILS[e].ABORHTYPE == undefined){
                                                                    ABORHTYPE += mpages.data["specimen_history"+e].QUAL[q].ASSAYS[z].RESULT[0].RESULT_VALUE_ALPHA;
                                                                }
                                                            }

                                                            if(mpages.data["specimen_history"+e].QUAL[q].ASSAYS[z].TASK_ASSAY_DISP == "aABORh"){
                                                                if(SPECIMENDETAILS[e].ABORHTYPE == "" || SPECIMENDETAILS[e].ABORHTYPE == undefined){
                                                                    if (ABORHTYPE != "") ABORHTYPE += ", ";
                                                                    ABORHTYPE += mpages.data["specimen_history"+e].QUAL[q].ASSAYS[z].RESULT[0].RESULT_VALUE_ALPHA;

                                                                    SPECIMENDETAILS[e].ABORHTYPE = ABORHTYPE;

                                                                }
                                                            }

                                                            if(mpages.data["specimen_history"+e].QUAL[q].ASSAYS[z].TASK_ASSAY_DISP == "ABSC Interp"){
                                                                if(SPECIMENDETAILS[e].ABSCINTERP == "" || SPECIMENDETAILS[e].ABSCINTERP == undefined){
                                                                    ABSCINTERP = mpages.data["specimen_history"+e].QUAL[q].ASSAYS[z].RESULT[0].RESULT_VALUE_ALPHA;

                                                                    SPECIMENDETAILS[e].ABSCINTERP = ABSCINTERP
                                                                }
                                                            }
                                                        }
                                                        if(SPECIMENDETAILS[e].ABORHTYPE == ""){
                                                            if(mpages.data["specimen_history"+e].QUAL[q].ORDER_MNEMONIC == "DHOLD"){
                                                                SPECIMENDETAILS[e].ABORHTYPE = "Draw and Hold";
                                                            } else if($scope.SPECIMENS[e].STATUS != "Ordered" && $scope.SPECIMENS[e].STATUS != "Order Complete"){
                                                                SPECIMENDETAILS[e].ABORHTYPE = $scope.SPECIMENS[e].STATUS;
                                                            }
                                                        }

                                                        if(SPECIMENDETAILS[e].EXPIRATION == "" || SPECIMENDETAILS[e].EXPIRATION == undefined){
                                                            SPECIMENDETAILS[e].EXPIRATION = mpages.data.blood.SPECIMEN_CNT > 0 ? mpages.data.blood.SPEC_QUAL[0].EXPIRATION : "NONE";
                                                        }
                                                    }
                                                }
                                            }

                                            if(SPECIMENDETAILS[e].RESULT_VALUE_DT_TM == "" || SPECIMENDETAILS[e] == null || SPECIMENDETAILS[e] == undefined){//dont display if there is no Collected Date/Time
                                               SPECIMENDETAILS.splice(e, 1);
                                            }
                                        }
                                    }

                                    SPECIMENDETAILS = _.uniq(SPECIMENDETAILS,false, function(item,key,a){ return JSON.stringify(item) });
                                    $scope.SPECIMENHISTORY = _.compact(SPECIMENDETAILS);

                                    angular.element("#container_bottom").fadeIn(500);
                                    $scope.bottom = true;
                                    progressIndicatorService.stopSpinner();
                                    angular.element("#loadingPercentage").empty();

                                }
                            }, function(error){ alert(error.requestText);$scope.idErrors.push(error.requestText); }
                        );
                    }

                    if($scope.ORDERABLES.length == 0 && $scope.SPECIMENS.length == 0){
                        angular.element("#container_bottom").fadeIn(500);
                        $scope.bottom = true;
                        progressIndicatorService.stopSpinner();
                        angular.element("#loadingPercentage").empty();
                    }
                }
            }, function(error){ alert(error.requestText);$scope.idErrors.push(error.requestText); }
        );
    };
});

//fgnass.github.com/spin.js#v1.3.3
!function(a,b){"object"==typeof exports?module.exports=b():"function"==typeof define&&define.amd?define(b):a.Spinner=b()}(this,function(){"use strict";function a(a,b){var c,d=document.createElement(a||"div");for(c in b)d[c]=b[c];return d}function b(a){for(var b=1,c=arguments.length;c>b;b++)a.appendChild(arguments[b]);return a}function c(a,b,c,d){var e=["opacity",b,~~(100*a),c,d].join("-"),f=.01+c/d*100,g=Math.max(1-(1-a)/b*(100-f),a),h=k.substring(0,k.indexOf("Animation")).toLowerCase(),i=h&&"-"+h+"-"||"";return m[e]||(n.insertRule("@"+i+"keyframes "+e+"{0%{opacity:"+g+"}"+f+"%{opacity:"+a+"}"+(f+.01)+"%{opacity:1}"+(f+b)%100+"%{opacity:"+a+"}100%{opacity:"+g+"}}",n.cssRules.length),m[e]=1),e}function d(a,b){var c,d,e=a.style;for(b=b.charAt(0).toUpperCase()+b.slice(1),d=0;d<l.length;d++)if(c=l[d]+b,void 0!==e[c])return c;return void 0!==e[b]?b:void 0}function e(a,b){for(var c in b)a.style[d(a,c)||c]=b[c];return a}function f(a){for(var b=1;b<arguments.length;b++){var c=arguments[b];for(var d in c)void 0===a[d]&&(a[d]=c[d])}return a}function g(a){for(var b={x:a.offsetLeft,y:a.offsetTop};a=a.offsetParent;)b.x+=a.offsetLeft,b.y+=a.offsetTop;return b}function h(a,b){return"string"==typeof a?a:a[b%a.length]}function i(a){return"undefined"==typeof this?new i(a):(this.opts=f(a||{},i.defaults,o),void 0)}function j(){function c(b,c){return a("<"+b+' xmlns="urn:schemas-microsoft.com:vml" class="spin-vml">',c)}n.addRule(".spin-vml","behavior:url(#default#VML)"),i.prototype.lines=function(a,d){function f(){return e(c("group",{coordsize:k+" "+k,coordorigin:-j+" "+-j}),{width:k,height:k})}function g(a,g,i){b(m,b(e(f(),{rotation:360/d.lines*a+"deg",left:~~g}),b(e(c("roundrect",{arcsize:d.corners}),{width:j,height:d.width,left:d.radius,top:-d.width>>1,filter:i}),c("fill",{color:h(d.color,a),opacity:d.opacity}),c("stroke",{opacity:0}))))}var i,j=d.length+d.width,k=2*j,l=2*-(d.width+d.length)+"px",m=e(f(),{position:"absolute",top:l,left:l});if(d.shadow)for(i=1;i<=d.lines;i++)g(i,-2,"progid:DXImageTransform.Microsoft.Blur(pixelradius=2,makeshadow=1,shadowopacity=.3)");for(i=1;i<=d.lines;i++)g(i);return b(a,m)},i.prototype.opacity=function(a,b,c,d){var e=a.firstChild;d=d.shadow&&d.lines||0,e&&b+d<e.childNodes.length&&(e=e.childNodes[b+d],e=e&&e.firstChild,e=e&&e.firstChild,e&&(e.opacity=c))}}var k,l=["webkit","Moz","ms","O"],m={},n=function(){var c=a("style",{type:"text/css"});return b(document.getElementsByTagName("head")[0],c),c.sheet||c.styleSheet}(),o={lines:12,length:7,width:5,radius:10,rotate:0,corners:1,color:"#000",direction:1,speed:1,trail:100,opacity:.25,fps:20,zIndex:2e9,className:"spinner",top:"auto",left:"auto",position:"relative"};i.defaults={},f(i.prototype,{spin:function(b){this.stop();var c,d,f=this,h=f.opts,i=f.el=e(a(0,{className:h.className}),{position:h.position,width:0,zIndex:h.zIndex}),j=h.radius+h.length+h.width;if(b&&(b.insertBefore(i,b.firstChild||null),d=g(b),c=g(i),e(i,{left:("auto"==h.left?d.x-c.x+(b.offsetWidth>>1):parseInt(h.left,10)+j)+"px",top:("auto"==h.top?d.y-c.y+(b.offsetHeight>>1):parseInt(h.top,10)+j)+"px"})),i.setAttribute("role","progressbar"),f.lines(i,f.opts),!k){var l,m=0,n=(h.lines-1)*(1-h.direction)/2,o=h.fps,p=o/h.speed,q=(1-h.opacity)/(p*h.trail/100),r=p/h.lines;!function s(){m++;for(var a=0;a<h.lines;a++)l=Math.max(1-(m+(h.lines-a)*r)%p*q,h.opacity),f.opacity(i,a*h.direction+n,l,h);f.timeout=f.el&&setTimeout(s,~~(1e3/o))}()}return f},stop:function(){var a=this.el;return a&&(clearTimeout(this.timeout),a.parentNode&&a.parentNode.removeChild(a),this.el=void 0),this},lines:function(d,f){function g(b,c){return e(a(),{position:"absolute",width:f.length+f.width+"px",height:f.width+"px",background:b,boxShadow:c,transformOrigin:"left",transform:"rotate("+~~(360/f.lines*j+f.rotate)+"deg) translate("+f.radius+"px,0)",borderRadius:(f.corners*f.width>>1)+"px"})}for(var i,j=0,l=(f.lines-1)*(1-f.direction)/2;j<f.lines;j++)i=e(a(),{position:"absolute",top:1+~(f.width/2)+"px",transform:f.hwaccel?"translate3d(0,0,0)":"",opacity:f.opacity,animation:k&&c(f.opacity,f.trail,l+j*f.direction,f.lines)+" "+1/f.speed+"s linear infinite"}),f.shadow&&b(i,e(g("#000","0 0 4px #000"),{top:"2px"})),b(d,b(i,g(h(f.color,j),"0 0 1px rgba(0,0,0,.1)")));return d},opacity:function(a,b,c){b<a.childNodes.length&&(a.childNodes[b].style.opacity=c)}});var p=e(a("group"),{behavior:"url(#default#VML)"});return!d(p,"transform")&&p.adj?j():k=d(p,"animation"),i});