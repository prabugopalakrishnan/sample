<?php

	include("/var/www/vhosts/coldwellbankerapps.com/httpdocs/wi_flyers/dbSave.inc");

	$backupFile = '/var/www/vhosts/coldwellbankerapps.com/httpdocs/wi_flyers/bak/'.date("m-d-y").'backup.sql.gz';

	$command = "mysqldump --opt -h $dbhost -u$dbuser -p$dbpass $dbname | gzip > $backupFile";
	system($command);
	
	$Name = "Cron Daemon";
	$email = "root@coldwellbankerapps.com"; 
	$recipient = "prabu.gopalakrishnan@cbexchange.com"; 
	$subject = "Cron - WiFli DB Backup Successfull";
	$header = "From: ". $Name . " <" . $email . ">\r\n";	
	mail($recipient, $subject, $subject, $header); 
	
	mysql_close($conn);
?>