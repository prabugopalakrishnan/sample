<?php
if($_POST['text']){
		
	include "db.inc";
	
	$mlsid = mysql_real_escape_string($_POST['text']);
	
	$sql = 'SELECT distinct MLSID FROM Listings WHERE (MLSID LIKE "%'. $mlsid . '%") AND (StateID="57") LIMIT 7';
	
	$result = mysql_query($sql);
	
	while ($row = mysql_fetch_assoc($result)) 	{
		$posts[] = array($row['MLSID'] => $row['MLSID']);
	}
	echo json_encode($posts);
	mysql_close($conn);

} else {
	header("location:http://coldwellbankerapps.com");	
}
?>
