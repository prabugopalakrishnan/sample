<?php

if($_POST["agentname"]){
	
	$agentname = trim($_POST['agentname']);
	$direct =  trim($_POST['direct']);
	
	$fax =  trim($_POST['fax']);
	$email =  trim($_POST['email']);		
	$agentsite = trim($_POST['agentsite']);															
	$agentaddress =  trim($_POST['agentaddress']);	
	$agentphoto =  trim($_POST['agentphoto']);
	$propstyle =  trim($_POST['propstyle']);
	$price =  trim($_POST['price']);
	$taxes =  trim($_POST['taxes']);
	$association =  trim($_POST['association']);
	$taxkey =  trim($_POST['taxkey']);
	$villagelabel = trim($_POST['villagelabel']);
	$village =  trim($_POST['village']);
	$county =  trim($_POST['county']);
	$schooldistrict =  trim($_POST['schooldistrict']);		

	$location =  trim($_POST['location']);
	$lotsize =  trim($_POST['lotsize']);
	$approximateage =  trim($_POST['approximateage']);
	$exterior =  trim($_POST['exterior']);
	$roof =  trim($_POST['roof']);
	$basement =  trim($_POST['basement']);
	$garage =  trim($_POST['garage']);
	$heatsystem =  trim($_POST['heatsystem']);
	$centralair =  trim($_POST['centralair']);
	$budget =  trim($_POST['budget']);
	$elementaryschool =  trim($_POST['elementaryschool']);
	$middleschool =  trim($_POST['middleschool']);
	$highschool =  trim($_POST['highschool']);
	$water =  trim($_POST['water']);
	$sanitarysystem =  trim($_POST['sanitarysystem']);
	$floodplain =  trim($_POST['floodplain']);
	$occupancy =  trim($_POST['occupancy']);
	$code =  trim($_POST['code']);
	$mlsid =  trim($_POST['mlsid']);
	$description =  $_POST['description'];
	$inclusions =  trim($_POST['inclusions']);
	$exclusions =  trim($_POST['exclusions']);
	$directions =  trim($_POST['directions']);	
	
	$housephoto = trim($_POST['housephoto']);
	$address = trim($_POST['address']);
	$proptype =  trim($_POST['proptype']);	
	$totalrooms = trim($_POST['totalrooms']);
	$bedrooms = trim($_POST['bedrooms']);	
	$bathspart =  trim($_POST['baths']);
	
	$level1 =  trim($_POST['level1']);
	$livingroom =  trim($_POST['livingroom']);	
	$livingroomlabel =  trim($_POST['livingroomlabel']);
	$level1Hidden =  trim($_POST['level1Hidden']);
	$livingroomHidden =  trim($_POST['livingroomHidden']);	
	$livingroomlabelHidden =  trim($_POST['livingroomlabelHidden']);
	
	$level2 =  trim($_POST['level2']);	
	$diningroom =  trim($_POST['diningroom']);
	$diningroomlabel =  trim($_POST['diningroomlabel']);
	$level2Hidden =  trim($_POST['level2Hidden']);	
	$diningroomHidden =  trim($_POST['diningroomHidden']);
	$diningroomlabelHidden =  trim($_POST['diningroomlabelHidden']);
	
	$level3 =  trim($_POST['level3']);	
	$kitchen =  trim($_POST['kitchen']);
	$kitchenlabel =  trim($_POST['kitchenlabel']);
	$level3Hidden =  trim($_POST['level3Hidden']);	
	$kitchenHidden =  trim($_POST['kitchenHidden']);
	$kitchenlabelHidden =  trim($_POST['kitchenlabelHidden']);
	
	$level4 =  trim($_POST['level4']);
	$familyroom =  trim($_POST['familyroom']);
	$familyroomlabel =  trim($_POST['familyroomlabel']);
	$level4Hidden =  trim($_POST['level4Hidden']);
	$familyroomHidden =  trim($_POST['familyroomHidden']);
	$familyroomlabelHidden =  trim($_POST['familyroomlabelHidden']);
	
	$level5 =  trim($_POST['level5']);
	$powderroom =  trim($_POST['powderroom']);
	$powderroomlabel =  trim($_POST['powderroomlabel']);
	$level5Hidden =  trim($_POST['level5Hidden']);
	$powderroomHidden =  trim($_POST['powderroomHidden']);
	$powderroomlabelHidden =  trim($_POST['powderroomlabelHidden']);
	
	$level6 =  trim($_POST['level6']);
	$bath =  trim($_POST['bath']);
	$bathlabel =  trim($_POST['bathlabel']);
	$level6Hidden =  trim($_POST['level6Hidden']);
	$bathHidden =  trim($_POST['bathHidden']);
	$bathlabelHidden =  trim($_POST['bathlabelHidden']);
	
	$level7 =  trim($_POST['level7']);
	$masterbedroom =  trim($_POST['masterbedroom']);
	$masterbedroomlabel =  trim($_POST['masterbedroomlabel']);
	$level7Hidden =  trim($_POST['level7Hidden']);
	$masterbedroomHidden =  trim($_POST['masterbedroomHidden']);
	$masterbedroomlabelHidden =  trim($_POST['masterbedroomlabelHidden']);
	
	$level8 =  trim($_POST['level8']);
	$masterbath =  trim($_POST['masterbath']);
	$masterbathlabel =  trim($_POST['masterbathlabel']);
	$level8Hidden =  trim($_POST['level8Hidden']);
	$masterbathHidden =  trim($_POST['masterbathHidden']);
	$masterbathlabelHidden =  trim($_POST['masterbathlabelHidden']);
	
	$level9 =  trim($_POST['level9']);
	$bedroom1 =  trim($_POST['bedroom1']);
	$bedroom1label =  trim($_POST['bedroom1label']);
	$level9Hidden =  trim($_POST['level9Hidden']);
	$bedroom1Hidden =  trim($_POST['bedroom1Hidden']);
	$bedroom1labelHidden =  trim($_POST['bedroom1labelHidden']);
	
	$level10 =  trim($_POST['level10']);
	$bedroom2 =  trim($_POST['bedroom2']);
	$bedroom2label =  trim($_POST['bedroom2label']);
	$level10Hidden =  trim($_POST['level10Hidden']);
	$bedroom2Hidden =  trim($_POST['bedroom2Hidden']);
	$bedroom2labelHidden =  trim($_POST['bedroom2labelHidden']);
	
	$level11 =  trim($_POST['level11']);
	$bedroom3 =  trim($_POST['bedroom3']);
	$bedroom3label =  trim($_POST['bedroom3label']);
	$level11Hidden =  trim($_POST['level11Hidden']);
	$bedroom3Hidden =  trim($_POST['bedroom3Hidden']);
	$bedroom3labelHidden =  trim($_POST['bedroom3labelHidden']);
	
	$level12 =  trim($_POST['level12']);
	$utilityroom =  trim($_POST['utilityroom']);
	$utilityroomlabel =  trim($_POST['utilityroomlabel']);
	$level12Hidden =  trim($_POST['level12Hidden']);
	$utilityroomHidden =  trim($_POST['utilityroomHidden']);
	$utilityroomlabelHidden =  trim($_POST['utilityroomlabelHidden']);
	
	$homewarranty =  trim($_POST['homewarranty']);
	
	
	$html = '<style>
html, body{
	font-family:helvetica;
	color:#000000;
	margin:0;
	padding:0;
	font-size:12px;
	background:#FFFFFF;
}

td{
	font-family:helvetica;
	color:#000000;
	font-size:12px;
}

#mlsid{
	width:100px;
}

#directions{
	width:500px;	
}
#big{
	font-size:16px;	
	text-align:center;
	font-weight:bold;
	margin-left:auto!important;
	margin-right:auto!important;
}

.tdborder{
	border-bottom:1px solid #ccc;
	border-left:1px solid #ccc;
}

#bigcheck{
	font-size:16px;
}

</style>
<table cellpadding="0" cellspacing="1" border="0" width="100%">
<tr>
  <td align="left" valign="top"><img src="http://coldwellbankerapps.com/images/CBRB_3D.jpg" width="100" height="54" /></td>
  <td width="425" rowspan="11" valign="top" align="center"><img src="'.$housephoto.'" width="425" height="319" /><table border="0" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center"><span id="big" align="center">'.$address.'</span></td></tr></table>
<table width="450" border="0" cellpadding="3" cellspacing="0">
  <tr>
    <td width="36" rowspan="4" align="center"  style="border-top:1px solid #ccc;border-left:1px solid #ccc;"><img src="images/level.jpg"  border="0"></td>
    <td width="115" style="border-top:1px solid #ccc;border-left:1px solid #ccc;"><b>Property Type:</b></td>
    <td style="border-top:1px solid #ccc;border-right:1px solid #ccc;">'.$proptype.'</td>
  </tr>';
 
 //if($totalrooms != ""){
  $html .= '<tr>
    <td style="border-left:1px solid #ccc;"><b>Total Rooms:</b></td>
    <td style="border-right:1px solid #ccc;">'.$totalrooms.'</td>
  </tr>';
//}  need to adjust rowspan above;
 
  $html .= '<tr>
    <td style="border-left:1px solid #ccc;"><b>Bedrooms:</b></td>
    <td style="border-right:1px solid #ccc;">'.$bedrooms.'</td>
  </tr>
  <tr>
	  <td style="border-left:1px solid #ccc;"><b>Baths:</b></td>
      <td style="border-right:1px solid #ccc;">'.$bathspart.'</td>
  </tr>';
  
  $striped = false;
   
  if($livingroom != ""){
		 $striped = true;
		 $html .= '<tr style="background-color:#eeeeee"><td width="35" align="center" class="tdborder" style="border-top:1px solid #ccc">'.$level1.'</td>
			<td class="tdborder" style="border-top:1px solid #ccc"><b>'.$livingroomlabel.'</b></td>
			<td class="tdborder" style="border-top:1px solid #ccc;border-right:1px solid #ccc">'.$livingroom.'</td></tr>';  
  }
	if($livingroomHidden != ""){
		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
		 
		 $html .= '<td width="35" align="center" class="tdborder">'.$level1Hidden.'</td>
			<td class="tdborder"><b>'.$livingroomlabelHidden.'</b></td>
			<td class="tdborder" style="border-right:1px solid #ccc">'.$livingroomHidden.'</td>
	  </tr>';
	}
	
	if($diningroom != ""){
		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
 	 $html .= '<td width="35" align="center" class="tdborder">'.$level2.'</td>
	    <td class="tdborder" ><b>'.$diningroomlabel.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$diningroom.'</td>
  	</tr>';
	}
	if($diningroomHidden != ""){
 		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	 $html .= '<td width="35" align="center" class="tdborder">'.$level2Hidden.'</td>
	    <td class="tdborder" ><b>'.$diningroomlabelHidden.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$diningroomHidden.'</td>
  	</tr>';
	}
	
	if($kitchen != ""){
		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
 	 $html .= '<td width="35" align="center" class="tdborder">'.$level3.'</td>
	    <td class="tdborder"><b>'.$kitchenlabel.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$kitchen.'</td>
  	</tr>';
	}
	if($kitchenHidden != ""){
		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
 	 $html .= '
	    <td width="35" align="center" class="tdborder">'.$level3Hidden.'</td>
	    <td class="tdborder"><b>'.$kitchenlabelHidden.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$kitchenHidden.'</td>
  	</tr>';
	}
	
	if($familyroom != ""){
		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
 	 $html .= '<td width="35" align="center" class="tdborder">'.$level4.'</td>
	    <td class="tdborder"><b>'.$familyroomlabel.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$familyroom.'</td>
 	 </tr>';
	  }
	  if($familyroomHidden != ""){
		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
 	 	$html .= '<td width="35" align="center" class="tdborder">'.$level4Hidden.'</td>
	    <td class="tdborder"><b>'.$familyroomlabelHidden.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$familyroomHidden.'</td>
 	 </tr>';
	  }
	  
	  if($powderroom != ""){
		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	 	$html .= '<td width="35" align="center" class="tdborder">'.$level5.'</td>
	    <td class="tdborder"><b>'.$powderroomlabel.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$powderroom.'</td>
 		 </tr>';
	  }
	  if($powderroomHidden != ""){
		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	 	$html .= '<td width="35" align="center" class="tdborder">'.$level5Hidden.'</td>
	    <td class="tdborder"><b>'.$powderroomlabelHidden.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$powderroomHidden.'</td>
 		 </tr>';
	  }
	  
	  if($bath != ""){
		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	 	$html .= '<td width="35" align="center" class="tdborder">'.$level6.'</td>
	    <td class="tdborder" ><b>'.$bathlabel.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$bath.'</td>
  		</tr>';
	  }
  if($bathHidden != ""){
	  if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	 	$html .= '<td width="35" align="center" class="tdborder">'.$level6Hidden.'</td>
	    <td class="tdborder" ><b>'.$bathlabelHidden.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$bathHidden.'</td>
  		</tr>';
	  }
  
  if($masterbedroom != ""){
	 if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	 $html .= '<td width="35" align="center" class="tdborder">'.$level7.'</td>
	    <td class="tdborder"><b>'.$masterbedroomlabel.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$masterbedroom.'</td>
  		</tr>';
  }
   if($masterbedroomHidden != ""){
	   if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	 $html .= '<td width="35" align="center" class="tdborder">'.$level7Hidden.'</td>
	    <td class="tdborder"><b>'.$masterbedroomlabelHidden.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$masterbedroomHidden.'</td>
  		</tr>';
  }
  
   if($masterbath != ""){
	   if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	  $html .= '<td width="35" align="center" class="tdborder">'.$level8.'</td>
	    <td class="tdborder"><b>'.$masterbathlabel.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$masterbath.'</td>
  		</tr>';
   }
   if($masterbathHidden != ""){
	   if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	  $html .= '<td width="35" align="center" class="tdborder">'.$level8Hidden.'</td>
	    <td class="tdborder"><b>'.$masterbathlabelHidden.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$masterbathHidden.'</td>
  		</tr>';
   }
  
  if($bedroom1 != ""){
	  if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	  $html .= '<td width="35" align="center" class="tdborder">'.$level9.'</td>
	    <td class="tdborder"><b>'.$bedroom1label.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$bedroom1.'</td>
  	</tr>';
  }
  if($bedroom1Hidden != ""){
		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	  $html .= '<td width="35" align="center" class="tdborder">'.$level9Hidden.'</td>
	    <td class="tdborder"><b>'.$bedroom1labelHidden.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$bedroom1Hidden.'</td>
  	</tr>';
  }
  
  if($bedroom2 != ""){
	  if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	  $html .= '<td width="35" align="center" class="tdborder">'.$level10.'</td>
	    <td class="tdborder"><b>'.$bedroom2label.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$bedroom2.'</td>
  	</tr>';
  }
    if($bedroom2Hidden != ""){
		if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	  $html .= '<td width="35" align="center" class="tdborder">'.$level10Hidden.'</td>
	    <td class="tdborder"><b>'.$bedroom2labelHidden.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$bedroom2Hidden.'</td>
  	</tr>';
  }
  
   if($bedroom3 != ""){
	   if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	  $html .= '<td width="35" align="center" class="tdborder">'.$level11.'</td>
	    <td class="tdborder"><b>'.$bedroom3label.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$bedroom3.'</td>
  </tr>';
   }
   if($bedroom3Hidden != ""){
	   if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	  $html .= '<td width="35" align="center" class="tdborder">'.$level11Hidden.'</td>
	    <td class="tdborder"><b>'.$bedroom3labelHidden.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$bedroom3Hidden.'</td>
  </tr>';
   }
  
  if($utilityroom != ""){
	 if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	  $html .= '<td width="35" align="center" class="tdborder">'.$level12.'</td>
	    <td class="tdborder"><b>'.$utilityroomlabel.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$utilityroom.'</td>
  </tr>';
  }
 if($utilityroomHidden != ""){
	 if($striped == false){
			 $striped = true;
			 $html .= '<tr style="background-color:#eeeeee">';
	 	} else {
			$striped = false;
			 $html .= '<tr>';
		}
	  $html .= '<td width="35" align="center" class="tdborder">'.$level12Hidden.'</td>
	    <td class="tdborder"><b>'.$utilityroomlabelHidden.'</b></td>
	    <td class="tdborder" style="border-right:1px solid #ccc">'.$utilityroomHidden.'</td>
  </tr>';
  }
	 
		if($homewarranty != ""){
			$html .= '<tr><td style="border-left:1px solid #ccc;border-bottom:1px solid #ccc"></td><td style="border-bottom:1px solid #ccc"></td><td style="border-bottom:1px solid #ccc; border-right:1px solid #ccc"><b>'.$homewarranty.'</b></td></tr>';	
}
       	
	  $html .= '<tr>
	    <td colspan="3" class="tdborder" style="font-size:7px;border-right:1px solid #ccc;" >	
	      The information contained herein is furnished by the owner to the best of his her knowledge, but is subject to verification by the purchaser and agent assumes no responsibility for correctness. The sole offering is made subject to errors, omissions, change of price, prior sale or withdrawal without notice. In accordance with the law, this property is offered without respect to race, color, creed, national origin, physical limitations, or familial status. Room sizes are approximate.<br>
	      <img src="http://coldwellbankerapps.com/images/disclaimer_logo_house.gif" width="11" height="11">Owned and operated by NRT.</td>
      </tr></table>
  </td>
</tr>
<tr>
  <td align="left" valign="top">  <b>'.$agentname.'</b></td>
</tr>';

	if (($direct != "") && ($direct != "Direct:")){
		$html .='<tr><td align="left" valign="top">'.$direct.'</td></tr>';
	}
	
	if (($fax != "") && ($fax != "Fax:")){
		$html .='<tr><td align="left" valign="top">'.$fax.'</td></tr>';
	}
	
	if ($email != ""){
		$html .='<tr><td align="left" valign="top">'.$email.'</td></tr>';
	}
	
	if ($agentsite != ""){
		$html .='<tr><td align="left" valign="top">'.$agentsite.'</td></tr>';
	}
	
	if ($agentaddress != ""){
		$html .='<tr><td align="left" valign="top">'.$agentaddress.'</td></tr>';
	}
	
	if ($agentphoto != ""){
		$html .='<tr><td align="left" valign="top"><img src="'.$agentphoto.'" width="100" height="150" /></td></tr>';
	}
	
	if (($propstyle != "") && ($propstyle != "Property Style")){
		$html .='<tr><td align="left" valign="top">'.$propstyle.'</td></tr>';
	}
	
	if ($price != ""){
		$html .='<tr><td align="left" valign="top">'.$price.'</td></tr>';
	}
	
	$html .='<tr><td align="left" valign="top"><table cellpadding="0" cellspacing="0" width="100%">';
	
	if ($taxes != ""){
		$html .='<tr><td><b>Taxes: </b></td><td>'.$taxes.'</td></tr>';
	}
	
	if($association != ""){
		$html .= '<tr><td align="left" valign="top"><b>Association Dues: </b></td><td>'.$association.'</td></tr>';	
	}
	
	if($taxkey != ""){
		$html .= '<tr><td align="left" valign="top"><b>Tax Key #: </b></td><td>'.$taxkey.'</td></tr>';
	}
	
	if($village != ""){
		$html .= '<tr><td align="left" valign="top"><b>'.$villagelabel.' </b></td><td>'.$village.'</td></tr>';
	}
	
	if($county != ""){
		$html .= '<tr><td align="left" valign="top"><b>County: </b></td><td valign="top">'.$county.'</td></tr>';
	}
	
	if($schooldistrict != ""){
		$html .= '<tr><td align="left" valign="top"><b>School District: </b></td><td>'.$schooldistrict.'</td></tr>';
	}
	
	if($elementaryschool != ""){
		$html .= '<tr><td align="left" valign="top"><b>Elementary: </b></td><td>'.$elementaryschool.'</td></tr>';
	}
	
	if($middleschool != ""){
		$html .= '<tr><td align="left" valign="top"><b>Middle School: </b></td><td>'.$middleschool.'</td></tr>';
	}
	
	if($highschool != ""){
		$html .= '<tr><td align="left" valign="top"><b>High School:</b></td><td valign="top">'.$highschool.'</td></tr>';
	}
	
	if($location != ""){
		$html .= '<tr><td align="left" valign="top"><b>Location: </b></td><td>'.$location.'</td></tr>';
	}
	
	if($lotsize != ""){
		$html .= '<tr><td align="left" valign="top"><b>Lot Size: </b></td><td>'.$lotsize.'</td></tr>';
	}
	
	if($approximateage != ""){
		$html .= '<tr><td align="left" valign="top"><b>Year Built:</b></td><td valign="top">'.$approximateage.'</td></tr>';
	}
	
	if($exterior != ""){
		$html .= '<tr><td align="left" valign="top"><b>Exterior: </b></td><td>'.$exterior.'</td></tr>';
	}
	
	if($roof != ""){
		$html .= '<tr><td align="left" valign="top"><b>Roof: </b></td><td>'.$roof.'</td></tr>';
	}
	
	if($basement != ""){
		$html .= '<tr><td align="left" valign="top"><b>Basement: </b></td><td>'.$basement.'</td></tr>';
	}
	
	if($garage != ""){
		$html .= '<tr><td align="left" valign="top"><b>Garage:</b></td><td valign="top">'.$garage.'</td></tr>';
	}
	
	if($heatsystem != ""){
		$html .= '<tr><td align="left" valign="top"><b>Heat System: </b></td><td>'.$heatsystem.'</td></tr>';
	}
	
	if($centralair != ""){
		$html .= '<tr><td align="left" valign="top"><b>Central Air: </b></td><td>'.$centralair.'</td></tr>';
	}
	
	if($water != ""){
		$html .= '<tr><td align="left" valign="top"><b>Water: </b></td><td>'.$water.'</td></tr>';
	}
	
	if($sanitarysystem != ""){
		$html .= '<tr><td align="left" valign="top"><b>Sanitary System: </b></td><td>'.$sanitarysystem.'</td></tr>';
	}
	
	if($budget != ""){
		$html .= '<tr><td align="left" valign="top"><b>Utility Budget:</b></td><td valign="top">'.$budget.'</td></tr>';
	}
	
	if($floodplain != ""){
		$html .= '<tr><td align="left" valign="top"><b>Flood Plain: </b></td><td>'.$floodplain.'</td></tr>';
	}
	
	if($occupancy != ""){
		$html .= '<tr><td align="left" valign="top"><b>Occupancy: </b></td><td>'.$occupancy.'</td></tr>';
	}
	
	if($code != ""){
		$html .= '<tr><td align="left" valign="top"><b>Code Compliance: </b></td><td>'.$code.'</td></tr>';
	}
	
	if($mlsid != ""){
		$html .= '<tr><td align="left" valign="top"><b>MLS#:</b></td><td> '.$mlsid.'</td></tr>';
	}
		
		
	$html .= '</table></td></tr>';
		
	if($description != ""){
		$html .= '<tr><td colspan="2"><br><p>'.$description.'</p><br><br></td></tr>';
	}
	
	if($inclusions != ""){
		$html .= '<tr><td colspan="2"><b>Inclusions: </b>'.$inclusions.'</td></tr>';
	}
	 
	if($exclusions != ""){
		$html .= '<tr><td colspan="2"><b>Exclusions: </b>'.$exclusions.'</td></tr>';
	}
	
	if($directions != ""){
		$html .= '<tr><td colspan="2"><b>Directions: </b>'.$directions.'<br></td></tr>';
	}
	  
	$html .= '</table>';
		
	include($_SERVER['DOCUMENT_ROOT']."/shared/php/mpdf53/mpdf.php");
	
	$mpdf=new mPDF();
	$mpdf->WriteHTML($html);
	$mpdf->Output('wisconsin_'.$mlsid.'.pdf', 'D');
	?>
    <script>
	 var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-31321285-1']);
		  _gaq.push(['_trackPageview']);
		
		  (function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
	</script>    
    <?
} else {
	header("location:index.php");
}
?>