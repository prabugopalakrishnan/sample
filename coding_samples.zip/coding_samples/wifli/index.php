<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>Wisconsin Listings Flyers</title>
  <link rel="shortcut icon" href="http://coldwellbankerapps.com/favicon.ico">
  <link href="css/main.css" type="text/css" rel="stylesheet" />
  <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
  <script src="js/jquery.autocomplete.js" type="text/javascript"></script>
</head>
<body>
<table cellpadding="5" cellspacing="5" border="0" width="954" align="center">
<tr><td align="center" colspan="2">
<img src="images/header.jpg" width="374" height="30" alt="Wisconsin Listings Flyers">
</td>
</tr>
<tr>
<td width="50%" align="center">
<img src="images/flyer.jpg" alt="Listing Flyers" width="477" height="259" border="0">
</td>
<td width="50%" align="center">
<div id="mlsContainer">
    <form method="POST" action="flyer.php">
    <br><br>
      Enter the MLS Number<br>
      to create a flyer!
      <br>
      <br>
    <input type="text" name="mlsid" id="mlsid" size="20" autocomplete="off"  onkeyup="this.value=this.value.replace(/\D/g,'')"/>
       
        <br />
        <br>
        <input type="submit" value="Continue" id="submit1">
    </form>
    </div>
</td>
</tr>
<tr>
<td align="center" colspan="2">

<img src="images/logos.jpg" width="361" height="94">
<br><br><br>
<br>
<br>

<br>
    Realogy Corporation owns this computer system and restricts access and use to authorized persons only. Use of and/or access to this system, and any information obtained thereunder, is subject to Realogy Corporation's applicable policies and procedures.<br><br>
  &copy;<?php echo date(Y); ?>
				Coldwell Banker Residential Brokerage. All rights reserved. Owned and Operated by NRT LLC. Equal Housing Opportunity.&nbsp;<img src="http://coldwellbankerapps.com/images/disclaimer_logo_house.gif" alt="Equal Housing Opportunity" width="11" height="11" />&nbsp;Equal Housing Lender.<br />
</td></tr></table> 
	<script type="text/javascript">
		$(document).ready(function() {
            
			$("#mlsid").autocomplete("autocomplete-ajax.php", {
					minChars: 1,
					timeout: 100
			});
			
			
			setTimeout(function(){
				$("#mlsid").focus();
       		}, 500);
			
		});
		

		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-31321285-1']);
		  _gaq.push(['_trackPageview']);
		
		  (function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
	</script>
        <?php
			include "dbSave.inc";
			if (isset($_SERVER["HTTP_CLIENT_IP"])){
				$ip = $_SERVER["HTTP_CLIENT_IP"];
			} elseif (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
				$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
			} elseif (isset($_SERVER["HTTP_X_FORWARDED"])) {
				$ip = $_SERVER["HTTP_X_FORWARDED"];
			} elseif (isset($_SERVER["HTTP_FORWARDED_FOR"])) {
				$ip = $_SERVER["HTTP_FORWARDED_FOR"];
			} elseif (isset($_SERVER["HTTP_FORWARDED"])) {
				$ip = $_SERVER["HTTP_FORWARDED"];
			} else {
				$ip = $_SERVER["REMOTE_ADDR"];
			}
			mysql_query("INSERT INTO history (stamp, ip) VALUES (NOW(),'$ip')") or mysql_error();
		?>
</body>
</html>
