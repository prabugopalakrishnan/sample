<?php

if($_POST["mlsid"]){
	
	include "dbSave.inc";
	
	$agentname = mysql_real_escape_string(trim($_POST['agentname']));
	
	
	
	$direct =  mysql_real_escape_string(trim($_POST['direct']));
	
	$fax =  mysql_real_escape_string(trim($_POST['fax']));
	$email =  mysql_real_escape_string(trim($_POST['email']));		
	$agentsite = mysql_real_escape_string(trim($_POST['agentsite']));															
	$agentaddress =  mysql_real_escape_string(trim($_POST['agentaddress']));	
	$agentphoto =  mysql_real_escape_string(trim($_POST['agentphoto']));
	$propstyle =  mysql_real_escape_string(trim($_POST['propstyle']));
	$price =  mysql_real_escape_string(trim($_POST['price']));
	$taxes =  mysql_real_escape_string(trim($_POST['taxes']));
	$association =  mysql_real_escape_string(trim($_POST['association']));
	$taxkey =  mysql_real_escape_string(trim($_POST['taxkey']));
	$villagelabel = mysql_real_escape_string(trim($_POST['villagelabel']));
	$village =  mysql_real_escape_string(trim($_POST['village']));
	$county =  mysql_real_escape_string(trim($_POST['county']));
	$schooldistrict =  mysql_real_escape_string(trim($_POST['schooldistrict']));		

	$location =  mysql_real_escape_string(trim($_POST['location']));
	$lotsize =  mysql_real_escape_string(trim($_POST['lotsize']));
	$approximateage =  mysql_real_escape_string(trim($_POST['approximateage']));
	$exterior =  mysql_real_escape_string(trim($_POST['exterior']));
	$roof =  mysql_real_escape_string(trim($_POST['roof']));
	$basement =  mysql_real_escape_string(trim($_POST['basement']));
	$garage =  mysql_real_escape_string(trim($_POST['garage']));
	$heatsystem =  mysql_real_escape_string(trim($_POST['heatsystem']));
	$centralair =  mysql_real_escape_string(trim($_POST['centralair']));
	$budget =  mysql_real_escape_string(trim($_POST['budget']));
	$elementaryschool =  mysql_real_escape_string(trim($_POST['elementaryschool']));
	$middleschool =  mysql_real_escape_string(trim($_POST['middleschool']));
	$highschool =  mysql_real_escape_string(trim($_POST['highschool']));
	$water =  mysql_real_escape_string(trim($_POST['water']));
	$sanitarysystem =  mysql_real_escape_string(trim($_POST['sanitarysystem']));
	$floodplain =  mysql_real_escape_string(trim($_POST['floodplain']));
	$occupancy =  mysql_real_escape_string(trim($_POST['occupancy']));
	$code =  mysql_real_escape_string(trim($_POST['code']));
	$mlsid =  mysql_real_escape_string(trim($_POST['mlsid']));
	$description =  mysql_real_escape_string($_POST['description']);
	$inclusions =  mysql_real_escape_string(trim($_POST['inclusions']));
	$exclusions =  mysql_real_escape_string(trim($_POST['exclusions']));
	$directions =  mysql_real_escape_string(trim($_POST['directions']));	
	
	$housephoto = mysql_real_escape_string(trim($_POST['housephoto']));
	$address = mysql_real_escape_string(trim($_POST['address']));
	$proptype =  mysql_real_escape_string(trim($_POST['proptype']));	
	$totalrooms = mysql_real_escape_string(trim($_POST['totalrooms']));
	$bedrooms = mysql_real_escape_string(trim($_POST['bedrooms']));	
	$bathspart =  mysql_real_escape_string(trim($_POST['baths']));
	
	$level1 =  mysql_real_escape_string(trim($_POST['level1']));
	$livingroom =  mysql_real_escape_string(trim($_POST['livingroom']));	
	$livingroomlabel =  mysql_real_escape_string(trim($_POST['livingroomlabel']));
	$level1Hidden =  mysql_real_escape_string(trim($_POST['level1Hidden']));
	$livingroomHidden =  mysql_real_escape_string(trim($_POST['livingroomHidden']));	
	$livingroomlabelHidden =  mysql_real_escape_string(trim($_POST['livingroomlabelHidden']));
	
	$level2 =  mysql_real_escape_string(trim($_POST['level2']));	
	$diningroom =  mysql_real_escape_string(trim($_POST['diningroom']));
	$diningroomlabel =  mysql_real_escape_string(trim($_POST['diningroomlabel']));
	$level2Hidden =  mysql_real_escape_string(trim($_POST['level2Hidden']));	
	$diningroomHidden =  mysql_real_escape_string(trim($_POST['diningroomHidden']));
	$diningroomlabelHidden =  mysql_real_escape_string(trim($_POST['diningroomlabelHidden']));
	
	$level3 =  mysql_real_escape_string(trim($_POST['level3']));	
	$kitchen =  mysql_real_escape_string(trim($_POST['kitchen']));
	$kitchenlabel =  mysql_real_escape_string(trim($_POST['kitchenlabel']));
	$level3Hidden =  mysql_real_escape_string(trim($_POST['level3Hidden']));	
	$kitchenHidden =  mysql_real_escape_string(trim($_POST['kitchenHidden']));
	$kitchenlabelHidden =  mysql_real_escape_string(trim($_POST['kitchenlabelHidden']));
	
	$level4 =  mysql_real_escape_string(trim($_POST['level4']));
	$familyroom =  mysql_real_escape_string(trim($_POST['familyroom']));
	$familyroomlabel =  mysql_real_escape_string(trim($_POST['familyroomlabel']));
	$level4Hidden =  mysql_real_escape_string(trim($_POST['level4Hidden']));
	$familyroomHidden =  mysql_real_escape_string(trim($_POST['familyroomHidden']));
	$familyroomlabelHidden =  mysql_real_escape_string(trim($_POST['familyroomlabelHidden']));
	
	$level5 =  mysql_real_escape_string(trim($_POST['level5']));
	$powderroom =  mysql_real_escape_string(trim($_POST['powderroom']));
	$powderroomlabel =  mysql_real_escape_string(trim($_POST['powderroomlabel']));
	$level5Hidden =  mysql_real_escape_string(trim($_POST['level5Hidden']));
	$powderroomHidden =  mysql_real_escape_string(trim($_POST['powderroomHidden']));
	$powderroomlabelHidden =  mysql_real_escape_string(trim($_POST['powderroomlabelHidden']));
	
	$level6 =  mysql_real_escape_string(trim($_POST['level6']));
	$bath =  mysql_real_escape_string(trim($_POST['bath']));
	$bathlabel =  mysql_real_escape_string(trim($_POST['bathlabel']));
	$level6Hidden =  mysql_real_escape_string(trim($_POST['level6Hidden']));
	$bathHidden =  mysql_real_escape_string(trim($_POST['bathHidden']));
	$bathlabelHidden =  mysql_real_escape_string(trim($_POST['bathlabelHidden']));
	
	$level7 =  mysql_real_escape_string(trim($_POST['level7']));
	$masterbedroom =  mysql_real_escape_string(trim($_POST['masterbedroom']));
	$masterbedroomlabel =  mysql_real_escape_string(trim($_POST['masterbedroomlabel']));
	$level7Hidden =  mysql_real_escape_string(trim($_POST['level7Hidden']));
	$masterbedroomHidden =  mysql_real_escape_string(trim($_POST['masterbedroomHidden']));
	$masterbedroomlabelHidden =  mysql_real_escape_string(trim($_POST['masterbedroomlabelHidden']));
	
	$level8 =  mysql_real_escape_string(trim($_POST['level8']));
	$masterbath =  mysql_real_escape_string(trim($_POST['masterbath']));
	$masterbathlabel =  mysql_real_escape_string(trim($_POST['masterbathlabel']));
	$level8Hidden =  mysql_real_escape_string(trim($_POST['level8Hidden']));
	$masterbathHidden =  mysql_real_escape_string(trim($_POST['masterbathHidden']));
	$masterbathlabelHidden =  mysql_real_escape_string(trim($_POST['masterbathlabelHidden']));
	
	$level9 =  mysql_real_escape_string(trim($_POST['level9']));
	$bedroom1 =  mysql_real_escape_string(trim($_POST['bedroom1']));
	$bedroom1label =  mysql_real_escape_string(trim($_POST['bedroom1label']));
	$level9Hidden =  mysql_real_escape_string(trim($_POST['level9Hidden']));
	$bedroom1Hidden =  mysql_real_escape_string(trim($_POST['bedroom1Hidden']));
	$bedroom1labelHidden =  mysql_real_escape_string(trim($_POST['bedroom1labelHidden']));
	
	$level10 =  mysql_real_escape_string(trim($_POST['level10']));
	$bedroom2 =  mysql_real_escape_string(trim($_POST['bedroom2']));
	$bedroom2label =  mysql_real_escape_string(trim($_POST['bedroom2label']));
	$level10Hidden =  mysql_real_escape_string(trim($_POST['level10Hidden']));
	$bedroom2Hidden =  mysql_real_escape_string(trim($_POST['bedroom2Hidden']));
	$bedroom2labelHidden =  mysql_real_escape_string(trim($_POST['bedroom2labelHidden']));
	
	$level11 =  mysql_real_escape_string(trim($_POST['level11']));
	$bedroom3 =  mysql_real_escape_string(trim($_POST['bedroom3']));
	$bedroom3label =  mysql_real_escape_string(trim($_POST['bedroom3label']));
	$level11Hidden =  mysql_real_escape_string(trim($_POST['level11Hidden']));
	$bedroom3Hidden =  mysql_real_escape_string(trim($_POST['bedroom3Hidden']));
	$bedroom3labelHidden =  mysql_real_escape_string(trim($_POST['bedroom3labelHidden']));
	
	$level12 =  mysql_real_escape_string(trim($_POST['level12']));
	$utilityroom =  mysql_real_escape_string(trim($_POST['utilityroom']));
	$utilityroomlabel =  mysql_real_escape_string(trim($_POST['utilityroomlabel']));
	$level12Hidden =  mysql_real_escape_string(trim($_POST['level12Hidden']));
	$utilityroomHidden =  mysql_real_escape_string(trim($_POST['utilityroomHidden']));
	$utilityroomlabelHidden =  mysql_real_escape_string(trim($_POST['utilityroomlabelHidden']));
	
	$homewarranty =  mysql_real_escape_string(trim($_POST['homewarranty']));
	
		$check = mysql_query("SELECT * FROM listings WHERE mlsid = '$mlsid'");		
 		$check2 = mysql_num_rows($check);
	
	 	if ($check2 != 0) {			
				mysql_query("UPDATE listings SET agentname = '$agentname', direct = '$direct', fax = '$fax', email = '$email', agentsite = '$agentsite', agentaddress = '$agentaddress', agentphoto = '$agentphoto', propstyle = '$propstyle', price = '$price', taxes = '$taxes', association = '$association', taxkey = '$taxkey', villagelabel = '$villagelabel', village = '$village', county = '$county', schooldistrict = '$schooldistrict', location = '$location', lotsize = '$lotsize', approximateage = '$approximateage', exterior = '$exterior', roof = '$roof', basement = '$basement', garage = '$garage', heatsystem = '$heatsystem', centralair = '$centralair', budget = '$budget', elementaryschool = '$elementaryschool', middleschool = '$middleschool', highschool = '$highschool', water = '$water', sanitarysystem = '$sanitarysystem', floodplain = '$floodplain', occupancy = '$occupancy', code = '$code', description = '$description', inclusions = '$inclusions', exclusions = '$exclusions', directions = '$directions', housephoto = '$housephoto', address = '$address', proptype = '$proptype', totalrooms = '$totalrooms', bedrooms = '$bedrooms', baths = '$bathspart', level1 = '$level1', livingroom = '$livingroom', livingroomlabel= '$livingroomlabel', level1Hidden = '$level1Hidden', livingroomHidden = '$livingroomHidden', livingroomlabelHidden = '$livingroomlabelHidden', level2 = '$level2', diningroom = '$diningroom', diningroomlabel = '$diningroomlabel', level2Hidden = '$level2Hidden', diningroomHidden = '$diningroomHidden', diningroomlabelHidden = '$diningroomlabelHidden', level3 = '$level3', kitchen = '$kitchen', kitchenlabel = '$kitchenlabel', level3Hidden = '$level3Hidden', kitchenHidden = '$kitchenHidden', kitchenlabelHidden = '$kitchenlabelHidden', level4 = '$level4', familyroom = '$familyroom', familyroomlabel = '$familyroomlabel', level4Hidden = '$level4Hidden', familyroomHidden = '$familyroomHidden', familyroomlabelHidden = '$familyroomlabelHidden', level5 = '$level5', powderroom = '$powderroom', powderroomlabel = '$powderroomlabel', level5Hidden = '$level5Hidden', powderroomHidden = '$powderroomHidden', powderroomlabelHidden = '$powderroomlabelHidden', level6 = '$level6', bath = '$bath', bathlabel = '$bathlabel', level6Hidden = '$level6Hidden', bathHidden = '$bathHidden', bathlabelHidden = '$bathlabelHidden', level7 = '$level7', masterbedroom = '$masterbedroom', masterbedroomlabel = '$masterbedroomlabel', level7Hidden = '$level7Hidden', masterbedroomHidden = '$masterbedroomHidden', masterbedroomlabelHidden = '$masterbedroomlabelHidden', level8 = '$level8', masterbath = '$masterbath', masterbathlabel = '$masterbathlabel', level8Hidden = '$level8Hidden', masterbathHidden = '$masterbathHidden', masterbathlabelHidden = '$masterbathlabelHidden', level9 = '$level9', bedroom1 = '$bedroom1', bedroom1label = '$bedroom1label', level9Hidden = '$level9Hidden', bedroom1Hidden = '$bedroom1Hidden', bedroom1labelHidden = '$bedroom1labelHidden', level10 = '$level10', bedroom2 = '$bedroom2', bedroom2label = '$bedroom2label', level10Hidden = '$level10Hidden', bedroom2Hidden = '$bedroom2Hidden', bedroom2labelHidden = '$bedroom2labelHidden', level11 = '$level11', bedroom3 = '$bedroom3', bedroom3label = '$bedroom3label', level11Hidden = '$level11Hidden', bedroom3Hidden = '$bedroom3Hidden', bedroom3labelHidden = '$bedroom3labelHidden', level12 = '$level12', utilityroom = '$utilityroom', utilityroomlabel = '$utilityroomlabel', level12Hidden = '$level12Hidden', utilityroomHidden = '$utilityroomHidden', utilityroomlabelHidden = '$utilityroomlabelHidden', homewarranty = '$homewarranty'	
				 WHERE mlsid = '$mlsid'") or die(mysql_error());
			echo '{"success":"updated"}';
		} else {			
				mysql_query("INSERT INTO listings (agentname, mlsid, direct, fax, email, agentsite, agentaddress, agentphoto, propstyle, price, taxes, association, taxkey, villagelabel, village, county, schooldistrict, location, lotsize, approximateage, exterior, roof, basement, garage, heatsystem, centralair, budget, elementaryschool, middleschool, highschool, water, sanitarysystem, floodplain, occupancy, code, description, inclusions, exclusions, directions, housephoto, address, proptype, totalrooms, bedrooms, baths, level1, livingroom, livingroomlabel, level1Hidden, livingroomHidden, livingroomlabelHidden, level2, diningroom, diningroomlabel, level2Hidden, diningroomHidden, diningroomlabelHidden, level3, kitchen, kitchenlabel, level3Hidden, kitchenHidden, kitchenlabelHidden, level4, familyroom, familyroomlabel, level4Hidden, familyroomHidden, familyroomlabelHidden, level5, powderroom , powderroomlabel, level5Hidden, powderroomHidden, powderroomlabelHidden, level6, bath, bathlabel, level6Hidden , bathHidden, bathlabelHidden, level7, masterbedroom, masterbedroomlabel, level7Hidden, masterbedroomHidden, masterbedroomlabelHidden, level8, masterbath, masterbathlabel, level8Hidden, masterbathHidden, masterbathlabelHidden, level9, bedroom1, bedroom1label, level9Hidden, bedroom1Hidden, bedroom1labelHidden, level10, bedroom2, bedroom2label, level10Hidden, bedroom2Hidden, bedroom2labelHidden, level11, bedroom3, bedroom3label, level11Hidden, bedroom3Hidden, bedroom3labelHidden, level12, utilityroom, utilityroomlabel, level12Hidden, utilityroomHidden, utilityroomlabelHidden, homewarranty) VALUES ('$agentname', '$mlsid', '$direct', '$fax', '$email', '$agentsite', '$agentaddress', '$agentphoto', '$propstyle', '$price', '$taxes', '$association', '$taxkey', '$villagelabel', '$village', '$county', '$schooldistrict', '$location', '$lotsize', '$approximateage', '$exterior', '$roof', '$basement', '$garage', '$heatsystem', '$centralair', '$budget', '$elementaryschool', '$middleschool', '$highschool', '$water', '$sanitarysystem', '$floodplain', '$occupancy', '$code', '$description', '$inclusions', '$exclusions', '$directions', '$housephoto', '$address', '$proptype', '$totalrooms', '$bedrooms', '$bathspart', '$level1', '$livingroom', '$livingroomlabel', '$level1Hidden', '$livingroomHidden', '$livingroomlabelHidden', '$level2', '$diningroom', '$diningroomlabel', '$level2Hidden', '$diningroomHidden', '$diningroomlabelHidden', '$level3', '$kitchen', '$kitchenlabel', '$level3Hidden', '$kitchenHidden', '$kitchenlabelHidden', '$level4', '$familyroom', '$familyroomlabel', '$level4Hidden', '$familyroomHidden', '$familyroomlabelHidden', '$level5', '$powderroom', '$powderroomlabel', '$level5Hidden', '$powderroomHidden', '$powderroomlabelHidden', '$level6', '$bath', '$bathlabel', '$level6Hidden', '$bathHidden', '$bathlabelHidden', '$level7', '$masterbedroom', '$masterbedroomlabel', '$level7Hidden', '$masterbedroomHidden', '$masterbedroomlabelHidden', '$level8', '$masterbath', '$masterbathlabel',  '$level8Hidden', '$masterbathHidden', '$masterbathlabelHidden', '$level9', '$bedroom1', '$bedroom1label', '$level9Hidden', '$bedroom1Hidden', '$bedroom1labelHidden', '$level10', '$bedroom2', '$bedroom2label', '$level10Hidden', '$bedroom2Hidden', '$bedroom2labelHidden', '$level11', '$bedroom3', '$bedroom3label', '$level11Hidden', '$bedroom3Hidden', '$bedroom3labelHidden', '$level12', '$utilityroom', '$utilityroomlabel', '$level12Hidden', '$utilityroomHidden', '$utilityroomlabelHidden', '$homewarranty')") or die("There is an error in database: ".mysql_error());
	
			echo '{"success":"saved"}';
		}
	
	mysql_close($conn);
	
} else {
	header("location:index.php");
}
?>