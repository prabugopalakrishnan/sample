$(document).ready(function() {
	override = false;
	$.ajax({
		url: "loadFlyer.php",
		cache : false,
		type: "POST",
		dataType: "json",		 
		data:  {mlsid:$("#mls").val()},
		success: function(data) {	
			if(data != ""){
				$("#loadListing").show();
				override = true;
			}
		}
						 
	});
	
		$( "#saveListing" ).click(function() {
			if(override == true){
				var answer = confirm("This listing has been already saved. Are you sure you want to override your changes?");
			}
			if (((override == true) && (answer)) || (override != true)){
				homeywarranty = '';
				if ($('#homewarranty').is(":checked")){
					homeywarranty = 'checked';
				}
							$.ajax({
							 url: "saveFlyer.php",
							 cache : false,
							 type: "POST",
							 dataType: "json",		 
							 data:  {mlsid:$("#mls").val(), agentname:$("#agentname").val(), direct:$("#direct").val(), fax:$("#fax").val(), email:$("#email").val(), agentsite:$("#agentsite").val(), agentaddress:$("#agentaddress").val(), agentphoto:$("#agentphoto").val(), propstyle:$("#propstyle").val(), price:$("#price").val(), taxes:$("#taxes").val(), association:$("#association").val(), taxkey:$("#taxkey").val(), villagelabel:$("#villagelabel").val(), village:$("#village").val(), county:$("#county").val(), schooldistrict:$("#schooldistrict").val(), location:$("#location").val(), lotsize:$("#lotsize").val(), approximateage:$("#approximateage").val(), exterior:$("#exterior").val(), roof:$("#roof").val(), basement:$("#basement").val(), garage:$("#garage").val(), heatsystem:$("#heatsystem").val(), centralair:$("#centralair").val(), budget:$("#budget").val(), elementaryschool:$("#elementaryschool").val(), middleschool:$("#middleschool").val(), highschool:$("#highschool").val(), water:$("#water").val(), sanitarysystem:$("#sanitarysystem").val(), floodplain:$("#floodplain").val(), occupancy:$("#occupancy").val(), code:$("#code").val(), description:$("#description").val(), inclusions:$("#inclusions").val(), exclusions:$("#exclusions").val(), directions:$("#directions").val(), housephoto:$("#housephoto").val(), address:$("#address").val(), proptype:$("#proptype").val(), totalrooms:$("#totalrooms").val(), bedrooms:$("#bedrooms").val(), baths:$("#baths").val(), level1:$("#level1").val(), livingroom:$("#livingroom").val(), livingroomlabel:$("#livingroomlabel").val(), level1Hidden:$("#level1Hidden").val(), livingroomHidden:$("#livingroomHidden").val(), livingroomlabelHidden:$("#livingroomlabelHidden").val(), level2:$("#level2").val(), diningroom:$("#diningroom").val(), diningroomlabel:$("#diningroomlabel").val(), level2Hidden:$("#level2Hidden").val(), diningroomHidden:$("#diningroomHidden").val(), diningroomlabelHidden:$("#diningroomlabelHidden").val(), level3:$("#level3").val(), kitchen:$("#kitchen").val(), kitchenlabel:$("#kitchenlabel").val(), level3Hidden:$("#level3Hidden").val(), kitchenHidden:$("#kitchenHidden").val(), kitchenlabelHidden:$("#kitchenlabelHidden").val(), level4:$("#level4").val(), familyroom:$("#familyroom").val(), familyroomlabel:$("#familyroomlabel").val(), level4Hidden:$("#level4Hidden").val(), familyroomHidden:$("#familyroomHidden").val(), familyroomlabelHidden:$("#familyroomlabelHidden").val(), level5:$("#level5").val(), powderroom:$("#powderroom").val(), powderroomlabel:$("#powderroomlabel").val(), level5Hidden:$("#level5Hidden").val(), powderroomHidden:$("#powderroomHidden").val(), powderroomlabelHidden:$("#powderroomlabelHidden").val(), level6:$("#level6").val(), bath:$("#bath").val(), bathlabel:$("#bathlabel").val(), level6Hidden:$("#level6Hidden").val(), bathHidden:$("#bathHidden").val(), bathlabelHidden:$("#bathlabelHidden").val(), level7:$("#level7").val(), masterbedroom:$("#masterbedroom").val(), masterbedroomlabel:$("#masterbedroomlabel").val(), level7Hidden:$("#level7Hidden").val(), masterbedroomHidden:$("#masterbedroomHidden").val(), masterbedroomlabelHidden:$("#masterbedroomlabelHidden").val(), level8:$("#level8").val(), masterbath:$("#masterbath").val(), masterbathlabel:$("#masterbathlabel").val(), level8Hidden:$("#level8Hidden").val(), masterbathHidden:$("#masterbathHidden").val(), masterbathlabelHidden:$("#masterbathlabelHidden").val(), level9:$("#level9").val(), bedroom1:$("#bedroom1").val(), bedroom1label:$("#bedroom1label").val(), level9Hidden:$("#level9Hidden").val(), bedroom1Hidden:$("#bedroom1Hidden").val(), bedroom1labelHidden:$("#bedroom1labelHidden").val(), level10:$("#level10").val(), bedroom2:$("#bedroom2").val(), bedroom2label:$("#bedroom2label").val(), level10Hidden:$("#level10Hidden").val(), bedroom2Hidden:$("#bedroom2Hidden").val(), bedroom2labelHidden:$("#bedroom2labelHidden").val(), level11:$("#level11").val(), bedroom3:$("#bedroom3").val(), bedroom3label:$("#bedroom3label").val(), level11Hidden:$("#level11Hidden").val(), bedroom3Hidden:$("#bedroom3Hidden").val(), bedroom3labelHidden:$("#bedroom3labelHidden").val(), level12:$("#level12").val(), utilityroom:$("#utilityroom").val(), utilityroomlabel:$("#utilityroomlabel").val(), level12Hidden:$("#level12Hidden").val(), utilityroomHidden:$("#utilityroomHidden").val(), utilityroomlabelHidden:$("#utilityroomlabelHidden").val(), homewarranty:homeywarranty},
							 success: function(data) {	
							  if(data.success == "updated"){
									$("#status").html("Succesfully Updated.").fadeIn(500).delay(1500).fadeOut(500);
								} else if(data.success == "saved"){
									$("#status").html("Succesfully Saved").fadeIn(500).delay(1500).fadeOut(500);
								} else {
									alert("Error Saving. Please try again.")	
								}
							} 
						 });
				}
			});		
		
		$( "#loadListing" ).click(function() {
						$.ajax({
						 url: "loadFlyer.php",
						 cache : false,
						 type: "POST",
						 dataType: "json",		 
						 data:  {mlsid:$("#mls").val()},
						 success: function(data) {		
							$("#agentname").val(data[0].agentname);
							$("#direct").val(data[0].direct);
							$("#fax").val(data[0].fax);
							$("#email").val(data[0].email);
							$("#agentsite").val(data[0].agentsite);
							$("#agentaddress").val(data[0].agentaddress);
							$("#agentphoto").val(data[0].agentphoto);
							$("#propstyle").val(data[0].propstyle);
							$("#price").val(data[0].price);
							$("#taxes").val(data[0].taxes);
							if((data[0].association == "$0") || (data[0].association == "")){
								$("#associationContainer").hide();
								$("#deleteAssociation").text('+');
								$("#association").val('');
							} else {
								$("#associationContainer").show();
								$("#deleteAssociation").text('X');
								$("#association").val(data[0].association);
							}
							$("#taxkey").val(data[0].taxkey);
							$("#villagelabel").val(data[0].villagelabel);
							$("#village").val(data[0].village);
							$("#county").val(data[0].county);
							$("#schooldistrict").val(data[0].schooldistrict);
							$("#location").val(data[0].location);
							$("#lotsize").val(data[0].lotsize);
							$("#approximateage").val(data[0].approximateage);
							$("#exterior").val(data[0].exterior);
							$("#roof").val(data[0].roof);
							$("#basement").val(data[0].basement);
							$("#garage").val(data[0].garage);
							$("#heatsystem").val(data[0].heatsystem);
							$("#centralair").val(data[0].centralair);
							$("#budget").val(data[0].budget);
							$("#elementaryschool").val(data[0].elementaryschool);
							$("#middleschool").val(data[0].middleschool);
							$("#highschool").val(data[0].highschool);
							$("#water").val(data[0].water);
							$("#sanitarysystem").val(data[0].sanitarysystem);
							$("#floodplain").val(data[0].floodplain);
							$("#occupancy").val(data[0].occupancy);
							$("#code").val(data[0].code);
							$("#description").val(data[0].description);
							$("#inclusions").val(data[0].inclusions);
							$("#exclusions").val(data[0].exclusions);
							$("#directions").val(data[0].directions);
							$("#housephoto").val(data[0].housephoto);
							$("#address").val(data[0].address);
							$("#proptype").val(data[0].proptype);
							$("#totalrooms").val(data[0].totalrooms);
							$("#bedrooms").val(data[0].bedrooms);
							$("#baths").val(data[0].baths);
							$("#level1").val(data[0].level1);
							
							if(data[0].livingroom != ""){
								$("#LivingRoom").show();
								$("#livingroom").val(data[0].livingroom);
							} else {
								$("#LivingRoom").hide();
								$("#livingroom").val('');						
							}
							
							
							
							$("#livingroomlabel").val(data[0].livingroomlabel);
							$("#level1Hidden").val(data[0].level1Hidden);
							if(data[0].livingroomHidden != ""){
								$("#LivingRoomHidden").show();
							} else {
								$("#LivingRoomHidden").hide();
							}
							$("#livingroomHidden").val(data[0].livingroomHidden);							
							$("#livingroomlabelHidden").val(data[0].livingroomlabelHidden);							
							$("#level2").val(data[0].level2);
							
							if(data[0].diningroom != ""){	
								$("#DiningRoom").show();						
								$("#diningroom").val(data[0].diningroom);
							} else {
								$("#DiningRoom").hide();
								$("#diningroom").val("");
							}
													
							$("#diningroomlabel").val(data[0].diningroomlabel);
							$("#level2Hidden").val(data[0].level2Hidden);
							if(data[0].diningroomHidden != ""){
								$("#DiningRoomHidden").show();
							} else {
								$("#DiningRoomHidden").hide();
							}
							$("#diningroomHidden").val(data[0].diningroomHidden);
							$("#diningroomlabelHidden").val(data[0].diningroomlabelHidden);
							$("#level3").val(data[0].level3);
							
							if(data[0].kitchen != ""){
								$("#Kitchen").show();
								$("#kitchen").val(data[0].kitchen); 
							} else {
								$("#Kitchen").hide();
								$("#kitchen").val(''); 
							}
							
							$("#kitchenlabel").val(data[0].kitchenlabel);
							$("#level3Hidden").val(data[0].level3Hidden); 
							if(data[0].kitchenHidden != ""){
								$("#KitchenHidden").show();	
							} else {
								$("#KitchenHidden").hide();
							}
							$("#kitchenHidden").val(data[0].kitchenHidden); 
							$("#kitchenlabelHidden").val(data[0].kitchenlabelHidden);
							$("#level4").val(data[0].level4);
							
							if(data[0].familyroom != ""){
								$("#FamilyRoom").show();
								$("#familyroom").val(data[0].familyroom);
							} else {
								$("#FamilyRoom").hide();
								$("#familyroom").val("");
							}
							$("#familyroomlabel").val(data[0].familyroomlabel);
							$("#level4Hidden").val(data[0].level4Hidden);
							
							if(data[0].familyroomHidden != ""){
								$("#FamilyRoomHidden").show();
							} else {
								$("#FamilyRoomHidden").hide();
							}
							
							$("#familyroomHidden").val(data[0].familyroomHidden);
							$("#familyroomlabelHidden").val(data[0].familyroomlabelHidden);
							$("#level5").val(data[0].level5);
							
							if(data[0].powderroom != ""){
								$("#PowderRoom").show();				
								$("#powderroom").val(data[0].powderroom);
							} else {
								$("#PowderRoom").hide();
								$("#powderroom").val("");
							}
							
							$("#powderroomlabel").val(data[0].powderroomlabel);
							$("#level5Hidden").val(data[0].level5Hidden);
							
							if(data[0].powderroomHidden != ""){
								$("#PowderRoomHidden").show();
							} else {
								$("#PowderRoomHidden").hide();
							}
							
							$("#powderroomHidden").val(data[0].powderroomHidden);
							$("#powderroomlabelHidden").val(data[0].powderroomlabelHidden);
							$("#level6").val(data[0].level6);
							
							if(data[0].bath != ""){
								$("#Bath").show();			
								$("#bath").val(data[0].bath);
							} else {
								$("#Bath").hide();
								$("#bath").val("");
							}
							
							$("#bathlabel").val(data[0].bathlabel);
							$("#level6Hidden").val(data[0].level6Hidden);
							if(data[0].bathHidden != ""){
								$("#BathHidden").show();
							} else {
								$("#BathHidden").hide();
							}
							$("#bathHidden").val(data[0].bathHidden);
							$("#bathlabelHidden").val(data[0].bathlabelHidden);
							$("#level7").val(data[0].level7);
							
							if(data[0].masterbedroom != ""){
								$("#MasterBedroom").show();				
								$("#masterbedroom").val(data[0].masterbedroom);
							} else {
								$("#MasterBedroom").hide();	
								$("#masterbedroom").val("")
							}
							
							
							$("#masterbedroomlabel").val(data[0].masterbedroomlabel);
							$("#level7Hidden").val(data[0].level7Hidden);
							
							if(data[0].masterbedroomHidden != ""){
								$("#MasterBedroomHidden").show();
							} else {
								$("#MasterBedroomHidden").hide();
							}
							
							$("#masterbedroomHidden").val(data[0].masterbedroomHidden);
							$("#masterbedroomlabelHidden").val(data[0].masterbedroomlabelHidden);
							$("#level8").val(data[0].level8);
							
							if(data[0].masterbath != ""){
								$("#MasterBath").show();
								$("#masterbath").val(data[0].masterbath);
							} else {
								$("#MasterBath").hide();
								$("#masterbath").val("");	
							}
							
							
							$("#masterbathlabel").val(data[0].masterbathlabel);
							$("#level8Hidden").val(data[0].level8Hidden);
							
							if(data[0].masterbathHidden != ""){
								$("#MasterBathHidden").show();
							} else {
								$("#MasterBathHidden").hide();
							}
							$("#masterbathHidden").val(data[0].masterbathHidden);
							$("#masterbathlabelHidden").val(data[0].masterbathlabelHidden);
							$("#level9").val(data[0].level9);
							
							if(data[0].bedroom1 != ""){
								$("#Bedroom1").show();
								$("#bedroom1").val(data[0].bedroom1);
							} else {
								$("#Bedroom1").hide();
								$("#bedroom1").val("")
							}
							
							$("#bedroom1label").val(data[0].bedroom1label);
							$("#level9Hidden").val(data[0].level9Hidden);
							
							if(data[0].bedroom1Hidden != ""){
								$("#Bedroom1Hidden").show();
							} else {
								$("#Bedroom1Hidden").hide();
							}
							
							$("#bedroom1Hidden").val(data[0].bedroom1Hidden);
							$("#bedroom1labelHidden").val(data[0].bedroom1labelHidden);
							$("#level10").val(data[0].level10);
							
							if(data[0].bedroom2 != ""){
								$("#Bedroom2").show();				
								$("#bedroom2").val(data[0].bedroom2);
							} else {
								$("#Bedroom2").hide();	
								$("#bedroom2").val("");
							}
							
							$("#bedroom2label").val(data[0].bedroom2label);
							$("#level10Hidden").val(data[0].level10Hidden);
							
							
							if(data[0].bedroom2Hidden != ""){
								$("#Bedroom2Hidden").show();	
							} else {
								$("#Bedroom2Hidden").hide();	
							}
							
							$("#bedroom2Hidden").val(data[0].bedroom2Hidden);
							$("#bedroom2labelHidden").val(data[0].bedroom2labelHidden);
							$("#level11").val(data[0].level11);
							
							if(data[0].bedroom3 != ""){
								$("#Bedroom3").show();				
								$("#bedroom3").val(data[0].bedroom3);
							} else {
								$("#Bedroom3").hide();
								$("#bedroom3").val("")
							}
							
							$("#bedroom3label").val(data[0].bedroom3label);
							$("#level11Hidden").val(data[0].level11Hidden);
							
							if(data[0].bedroom3Hidden != ""){
								$("#Bedroom3Hidden").show();	
							} else {
								$("#Bedroom3Hidden").hide();	
							}
							
							
							$("#bedroom3Hidden").val(data[0].bedroom3Hidden);
							$("#bedroom3labelHidden").val(data[0].bedroom3labelHidden);
							$("#level12").val(data[0].level12);
							
							if(data[0].utilityroom != ""){
								$("#UtilityRoom").show();
								$("#utilityroom").val(data[0].utilityroom);
							} else {
								$("#UtilityRoom").hide();
								$("#utilityroom").val("");	
							}
							$("#utilityroomlabel").val(data[0].utilityroomlabel);
							$("#level12Hidden").val(data[0].level12Hidden);
							
							if(data[0].utilityroomHidden != ""){
								$("#UtilityRoomHidden").show();	
							} else {
								$("#UtilityRoomHidden").hide();	
							}
							
							$("#utilityroomHidden").val(data[0].utilityroomHidden);
							$("#utilityroomlabelHidden").val(data[0].utilityroomlabelHidden);
							
							if(data[0].homewarranty != ""){
								$("#homewarranty").prop("checked", true);
							}
						}
					 });
					});		
		
		
	
		  $('#propstyle').focus(function(){ 
			if($('#propstyle').val() == "Property Style") {
			  $('#propstyle').val('');
			}
		  });
		  
		  $('#propstyle').blur(function(){
			if($('#propstyle').val() == ''){
			  $('#propstyle').val('Property Style');
			} 
		  });
	
	
		/////////////BEGIN ADD ROWS FUNCTIONS////////////////
		rowCounter = 0;
		
		$( "#addLivingRoom" ).hover(function () {
			$( "#LivingRoom" ).css({'background-color': '#339900'});
		});
		$( "#addLivingRoom" ).mouseout(function () {
			$( "#LivingRoom" ).css({'background-color': '#ffffff'});
		});
		$( "#addLivingRoom" ).click(function() {
			if($( "#LivingRoomHidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#LivingRoomHidden" ).toggle();
			$("#livingroomHidden").val("");
		});
		
		////////
		
		$( "#addDiningRoom" ).hover(function () {
			$( "#DiningRoom" ).css({'background-color': '#339900'});
		});
		$( "#addDiningRoom" ).mouseout(function () {
			$( "#DiningRoom" ).css({'background-color': '#ffffff'});
		});
		$( "#addDiningRoom" ).click(function() {
			if($( "#DiningRoomHidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#DiningRoomHidden" ).toggle();
			$("#diningroomHidden").val("");
		});
		
		//////////////
		
		$( "#addKitchen" ).hover(function () {
			$( "#Kitchen" ).css({'background-color': '#339900'});
		});
		$( "#addKitchen" ).mouseout(function () {
			$( "#Kitchen" ).css({'background-color': '#ffffff'});
		});
		$( "#addKitchen" ).click(function() {
			if($( "#KitchenHidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#KitchenHidden" ).toggle();
			$("#kitchenHidden").val("");
		});
		
		////////////////
		
		$( "#addFamilyRoom" ).hover(function () {
			$( "#FamilyRoom" ).css({'background-color': '#339900'});
		});
		$( "#addFamilyRoom" ).mouseout(function () {
			$( "#FamilyRoom" ).css({'background-color': '#ffffff'});
		});
		$( "#addFamilyRoom" ).click(function() {
			if($( "#FamilyRoomHidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#FamilyRoomHidden" ).toggle()
			$("#familyroomHidden").val("");
		});
		
		///////////
		
		$( "#addPowderRoom" ).hover(function () {
			$( "#PowderRoom" ).css({'background-color': '#339900'});
		});
		$( "#addPowderRoom" ).mouseout(function () {
			$( "#PowderRoom" ).css({'background-color': '#ffffff'});
		});
		$( "#addPowderRoom" ).click(function() {
			if($( "#PowderRoomHidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#PowderRoomHidden" ).toggle();
			$("#powderroomHidden").val("");
		});
		
		////////////////
		
		$( "#addBath" ).hover(function () {
			$( "#Bath" ).css({'background-color': '#339900'});
		});
		$( "#addBath" ).mouseout(function () {
			$( "#Bath" ).css({'background-color': '#ffffff'});
		});
		$( "#addBath" ).click(function() {
			if($( "#BathHidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#BathHidden" ).toggle();
			$("#bathHidden").val("");
		});
		
		///////////////////
		
		$( "#addMasterBedroom" ).hover(function () {
			$( "#MasterBedroom" ).css({'background-color': '#339900'});
		});
		$( "#addMasterBedroom" ).mouseout(function () {
			$( "#MasterBedroom" ).css({'background-color': '#ffffff'});
		});
		$( "#addMasterBedroom" ).click(function() {
			if($( "#MasterBedroomHidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#MasterBedroomHidden" ).toggle();
			$("#masterbedroomHidden").val("");
		});
		
				
		///////////////////
		
		$( "#addMasterBath" ).hover(function () {
			$( "#MasterBath" ).css({'background-color': '#339900'});
		});
		$( "#addMasterBath" ).mouseout(function () {
			$( "#MasterBath" ).css({'background-color': '#ffffff'});
		});
		$( "#addMasterBath" ).click(function() {
			if($( "#MasterBathHidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#MasterBathHidden" ).toggle();
			$("#masterbathHidden").val("");
		});

		///////////////////
		
		$( "#addBedroom1" ).hover(function () {
			$( "#Bedroom1" ).css({'background-color': '#339900'});
		});
		$( "#addBedroom1" ).mouseout(function () {
			$( "#Bedroom1" ).css({'background-color': '#ffffff'});
		});
		$( "#addBedroom1" ).click(function() {
			if($( "#Bedroom1Hidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#Bedroom1Hidden" ).toggle();
			$("#bedroom1Hidden").val("");
		});
		
		///////////////////
		
		$( "#addBedroom2" ).hover(function () {
			$( "#Bedroom2" ).css({'background-color': '#339900'});
		});
		$( "#addBedroom2" ).mouseout(function () {
			$( "#Bedroom2" ).css({'background-color': '#ffffff'});
		});
		$( "#addBedroom2" ).click(function() {
			if($( "#Bedroom2Hidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#Bedroom2Hidden" ).toggle();
			$("#bedroom2Hidden").val("");
		});
		
		///////////////////
		
		$( "#addBedroom3" ).hover(function () {
			$( "#Bedroom3" ).css({'background-color': '#339900'});
		});
		$( "#addBedroom3" ).mouseout(function () {
			$( "#Bedroom3" ).css({'background-color': '#ffffff'});
		});
		$( "#addBedroom3" ).click(function() {
			if($( "#Bedroom3Hidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#Bedroom3Hidden" ).toggle();
			$("#bedroom3Hidden").val("");
		});
		
		///////////////////
		
		$( "#addUtilityRoom" ).hover(function () {
			$( "#UtilityRoom" ).css({'background-color': '#339900'});
		});
		$( "#addUtilityRoom" ).mouseout(function () {
			$( "#UtilityRoom" ).css({'background-color': '#ffffff'});
		});
		$( "#addUtilityRoom" ).click(function() {
			if($( "#UtilityRoomHidden" ).is(':visible')){
				rowCounter--;
			} else {
				rowCounter++;
			}
			if(rowCounter > 2){
				alert('Adding 3 or more rows may cause the pdf to be two pages.')	
			}
			$( "#UtilityRoomHidden" ).toggle();
			$("#utilityroomHidden").val("");
		});
		
	
		
		/////////////////////BEGIN DELETE FUNCTIONS//////////////////////////
		
		$( "#deleteAssociation" ).hover(function () {
			$( "#associationContainer" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteAssociation" ).mouseout(function () {
			$( "#associationContainer" ).css({'background-color': '#ffffff'});
		});
  		$( "#deleteAssociation" ).click(function() {
			if($( "#deleteAssociation" ).text() == "X"){
			var answer = confirm("Are you sure you want to delete this row?")
				if (answer){
					$( "#associationContainer" ).toggle();
					$( "#deleteAssociation" ).text('+');
					$( "#association" ).val('');
				}			
			} else {
				$( "#associationContainer" ).toggle();
				$( "#deleteAssociation" ).text('X');
			}
		});
		
		
		$( "#deleteLivingRoom" ).hover(function () {
			$( "#LivingRoom" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteLivingRoom" ).mouseout(function () {
			$( "#LivingRoom" ).css({'background-color': '#ffffff'});
		});
  		$( "#deleteLivingRoom" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#LivingRoom" ).toggle();
				$("#livingroom").val("");
			}			
		});
		
		$( "#deleteLivingRoomHidden" ).hover(function () {
			$( "#LivingRoomHidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteLivingRoomHidden" ).mouseout(function () {
			$( "#LivingRoomHidden" ).css({'background-color': '#ffffff'});
		});
  		$( "#deleteLivingRoomHidden" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#LivingRoomHidden" ).toggle();
				$("#livingroomHidden").val("");
			}			
		});
		
		
		////////////
		
		
		$( "#deleteDiningRoom" ).hover(function () {
			$( "#DiningRoom" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteDiningRoom" ).mouseout(function () {
			$( "#DiningRoom" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteDiningRoom" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#DiningRoom" ).toggle();
				$("#diningroom").val("");
			}
		});
		
		$( "#deleteDiningRoomHidden" ).hover(function () {
			$( "#DiningRoomHidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteDiningRoomHidden" ).mouseout(function () {
			$( "#DiningRoomHidden" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteDiningRoomHidden" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#DiningRoomHidden" ).toggle();
				$("#diningroomHidden").val("");
			}
		});
		
		/////////////////
		
		
		$( "#deleteKitchen" ).hover(function () {
			$( "#Kitchen" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteKitchen" ).mouseout(function () {
			$( "#Kitchen" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteKitchen" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){	
				rowCounter--;
				$( "#Kitchen" ).toggle();
				$("#kitchen").val("");
			}
		});
		
		$( "#deleteKitchenHidden" ).hover(function () {
			$( "#KitchenHidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteKitchenHidden" ).mouseout(function () {
			$( "#KitchenHidden" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteKitchenHidden" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){	
				rowCounter--;
				$( "#KitchenHidden" ).toggle();
				$("#kitchenHidden").val("");
			}
		});
		
		
		/////////////////
		
		
		$( "#deleteFamilyRoom" ).hover(function () {
			$( "#FamilyRoom" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteFamilyRoom" ).mouseout(function () {
			$( "#FamilyRoom" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteFamilyRoom" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#FamilyRoom" ).toggle();
				$("#familyroom").val("");
			}
		});
		
		$( "#deleteFamilyRoomHidden" ).hover(function () {
			$( "#FamilyRoomHidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteFamilyRoomHidden" ).mouseout(function () {
			$( "#FamilyRoomHidden" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteFamilyRoomHidden" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#FamilyRoomHidden" ).toggle();
				$("#familyroomHidden").val("");
			}
		});
		
		//////////////
		
		
		$( "#deletePowderRoom" ).hover(function () {
			$( "#PowderRoom" ).css({'background-color': '#cc0000'});
		});
		$( "#deletePowderRoom" ).mouseout(function () {
			$( "#PowderRoom" ).css({'background-color': '#ffffff'});
		});
		$( "#deletePowderRoom" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#PowderRoom" ).toggle();
				$("#powderroom").val("");
			}
		});
		
		$( "#deletePowderRoomHidden" ).hover(function () {
			$( "#PowderRoomHidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deletePowderRoomHidden" ).mouseout(function () {
			$( "#PowderRoomHidden" ).css({'background-color': '#ffffff'});
		});
		$( "#deletePowderRoomHidden" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#PowderRoomHidden" ).toggle();
				$("#powderroomHidden").val("");
			}
		});
		
		
		////////////////
		
		
		$( "#deleteBath" ).hover(function () {
			$( "#Bath" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteBath" ).mouseout(function () {
			$( "#Bath" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteBath" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#Bath" ).toggle();
				$("#bath").val("");
			}
		});
		
		$( "#deleteBathHidden" ).hover(function () {
			$( "#BathHidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteBathHidden" ).mouseout(function () {
			$( "#BathHidden" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteBathHidden" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#BathHidden" ).toggle();
				$("#bathHidden").val("");
			}
		});
		
		
		/////////////////////
		
		
		$( "#deleteMasterBedroom" ).hover(function () {
			$( "#MasterBedroom" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteMasterBedroom" ).mouseout(function () {
			$( "#MasterBedroom" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteMasterBedroom" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#MasterBedroom" ).toggle();
				$("#masterbedroom").val("")
			}
		});
		
		$( "#deleteMasterBedroomHidden" ).hover(function () {
			$( "#MasterBedroomHidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteMasterBedroomHidden" ).mouseout(function () {
			$( "#MasterBedroomHidden" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteMasterBedroomHidden" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#MasterBedroomHidden" ).toggle();
				$("#masterbedroomHidden").val("");
			}
		});
		
		//////////////////////
		
		
		
		$( "#deleteMasterBath" ).hover(function () {
			$( "#MasterBath" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteMasterBath" ).mouseout(function () {
			$( "#MasterBath" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteMasterBath" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#MasterBath" ).toggle();
				$("#masterbath").val("");
			}
		});
		
		$( "#deleteMasterBathHidden" ).hover(function () {
			$( "#MasterBathHidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteMasterBathHidden" ).mouseout(function () {
			$( "#MasterBathHidden" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteMasterBathHidden" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#MasterBathHidden" ).toggle();
				$("#masterbathHidden").val("");
			}
		});
		
		
		//////////////////
		
		
		$( "#deleteBedroom1" ).hover(function () {
			$( "#Bedroom1" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteBedroom1" ).mouseout(function () {
			$( "#Bedroom1" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteBedroom1" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#Bedroom1" ).toggle();
				$("#bedroom1").val("")
			}
		});
		
		$( "#deleteBedroom1Hidden" ).hover(function () {
			$( "#Bedroom1Hidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteBedroom1Hidden" ).mouseout(function () {
			$( "#Bedroom1Hidden" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteBedroom1Hidden" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#Bedroom1Hidden" ).toggle();
				$("#bedroom1Hidden").val("");
			}
		});
		
		
		////////////////
		
		
		$( "#deleteBedroom2" ).hover(function () {
			$( "#Bedroom2" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteBedroom2" ).mouseout(function () {
			$( "#Bedroom2" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteBedroom2" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#Bedroom2" ).toggle();
				$("#bedroom2").val("");
			}
		});
		
		$( "#deleteBedroom2Hidden" ).hover(function () {
			$( "#Bedroom2Hidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteBedroom2Hidden" ).mouseout(function () {
			$( "#Bedroom2Hidden" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteBedroom2Hidden" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#Bedroom2Hidden" ).toggle();
				$("#bedroom2Hidden").val("");
			}
		});
		
		/////////////////
		
		
		$( "#deleteBedroom3" ).hover(function () {
			$( "#Bedroom3" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteBedroom3" ).mouseout(function () {
			$( "#Bedroom3" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteBedroom3" ).click(function() {
		var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#Bedroom3" ).toggle();
				$("#bedroom3").val("")
			}
		});
		
		$( "#deleteBedroom3Hidden" ).hover(function () {
			$( "#Bedroom3Hidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteBedroom3Hidden" ).mouseout(function () {
			$( "#Bedroom3Hidden" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteBedroom3Hidden" ).click(function() {
		var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#Bedroom3Hidden" ).toggle();
				$("#bedroom3Hidden").val("")
			}
		});
		
		
		///////////////////
		
		
		$( "#deleteUtilityRoom" ).hover(function () {
			$( "#UtilityRoom" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteUtilityRoom" ).mouseout(function () {
			$( "#UtilityRoom" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteUtilityRoom" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#UtilityRoom" ).toggle();
				$("#utilityroom").val("");
			}
		});
		
		$( "#deleteUtilityRoomHidden" ).hover(function () {
			$( "#UtilityRoomHidden" ).css({'background-color': '#cc0000'});
		});
		$( "#deleteUtilityRoomHidden" ).mouseout(function () {
			$( "#UtilityRoomHidden" ).css({'background-color': '#ffffff'});
		});
		$( "#deleteUtilityRoomHidden" ).click(function() {
			var answer = confirm("Are you sure you want to delete this row?")
			if (answer){
				rowCounter--;
				$( "#UtilityRoomHidden" ).toggle();
				$("#utilityroomHidden").val("");
			}
		});
		///////////////////////// END DELETE FUNCTIONS///////////////////////
	});