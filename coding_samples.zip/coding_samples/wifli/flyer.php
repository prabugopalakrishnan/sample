<?php
if($_POST['mlsid_text']){
		
	include "db.inc";
	setlocale(LC_MONETARY, "en_US.UTF-8");
	
	function format_tel_num($number){
		return preg_replace('/\d{3}/', '$0-', str_replace('-', null, trim($number)), 2);
	} 

	$mlsid = mysql_real_escape_string($_POST['mlsid_text']);
	
	$sql = "SELECT * FROM Listings WHERE MLSID='$mlsid'";
	$result = mysql_query($sql);
	
	while ($row = mysql_fetch_array($result)) 	{
		$housephoto =  $row['LeadPhoto'];
		$agentFName = $row['AgentFirstName'];
		$agentLName = $row['AgentLastName'];
		
		$propstyle =  $row['PropStyle'];
		$price = money_format('%.0n', $row['Price']);
		$taxes = money_format('%.0n', $row['Taxes']);
		$association = money_format('%.0n', $row['association']);
		$taxkey =  $row['TaxKey'];
		$village =  $row['City'];
		$county =  $row['CountyName'];
		$location =  $row['location'];
		$lotsize =  $row['LotSize'];
		$approximateage =  $row['YearBuilt'];
		$exterior =  $row['Exterior'];
		$roof =  $row['Roof'];
		$basement =  $row['Basement'];
		$garage =  $row['GarageParkingSpace'];
		$heatsystem =  $row['HeatSystem'];
		$centralair =  $row['CentralAir'];
		$budget =  $row['budget'];
		$schooldistrict =  $row['SchoolDistrict'];
		$elementaryschool =  $row['ElementarySchool'];
		$middleschool =  $row['MiddleSchool'];
		$highschool =  $row['HighSchool'];
		$water =  $row['Water'];
		$sanitarysystem =  $row['SanitarySystem'];
		$floodplain =  $row['FloodPlain'];
		if($floodplain == "0"){
			$floodplain = "No";	
		} else if($floodplain == "1"){
			$floodplain = "Yes";
		}else {}
		$occupancy =  $row['occupancy'];		
		$description =  $row['Description'];
		$inclusions =  $row['Inclusions'];
		$exclusions =  $row['exclusions'];
		$directions =  $row['Directions'];
		
		$address = $row['Address']." ".$row['City'].", WI ".$row['Zip'];
		$proptype =  $row['PropType'];	
		$totalrooms = $row['totalrooms'];//
		$bedrooms = $row['BedRooms'];
		if ($row['BathsPartial'] == "1"){
			$bathspartial = ".5";	
		} else {
			$bathspartial = "";	
		}
		$bathspart =  $row['BathsFull'].$bathspartial;
		$livingroom =  $row['LivingRoom'];//
		$diningroom =  $row['DiningRoom'];//
		$kitchen =  $row['Kitchen'];//
		$familyroom =  $row['FamilyRoom'];//
		$powderroom =  $row['powderroom'];//
		$bath =  $row['BathDescription'];//
		$masterbedroom =  $row['MasterBedroom'];//
		$masterbath =  $row['masterbath'];//
		$bedroom1 =  $row['Bedroom1'];//
		$bedroom2 =  $row['Bedroom2'];//
		$bedroom3 =  $row['Bedroom3'];//
		$utilityroom =  $row['Utility'];//
		
		$homewarranty =  $row['homewarranty'];//
		$fax =  format_tel_num($row['PrimaryAgentFax']);

	}
	
	$sql2 = "SELECT AgentFirstName, AgentLastName, DirectPhone, CellPhone, OfficePhone, Email, OfficeAddress, OfficeCity, PhotoURL FROM Agent_Data WHERE AgentFirstName='$agentFName' AND AgentLastName='$agentLName'";
	$result2 = mysql_query($sql2);
	
	while ($row2 = mysql_fetch_array($result2)){
		$agentname = $row2['AgentFirstName'] ." ". $row2['AgentLastName'];
		
		
		if($row2['DirectPhone'] != ""){
			$direct =  format_tel_num($row2['DirectPhone']);
		} else if($row2['CellPhone'] != ""){
			$direct =  format_tel_num($row2['CellPhone']);
		} else if($row2['OfficePhone'] != ""){
			$direct =  format_tel_num($row2['OfficePhone']);
		} else {}
		
		$email =  $row2['Email'];		
		$agentsite = "ColdwellBankerOnline.com/".$row2['AgentFirstName'].$row2['AgentLastName'];															
		$agentaddress =  $row2['OfficeAddress'].", ".$row2['OfficeCity'];
		$agentphoto =  $row2['PhotoURL'];
	}
	
	mysql_close($conn);
	
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>Wisconsin Listing Flyers</title>
  <link rel="shortcut icon" href="http://coldwellbankerapps.com/favicon.ico">
  <link href="css/main.css" type="text/css" rel="stylesheet" />
  <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
  <script type="text/javascript" src="js/main.js"></script>
</head>
<body>
<form method="post" action="generateFlyer.php" name="flyers">
<div id="flyer">
 
    
    <?php	
    echo '<table cellpadding="0" cellspacing="0" border="0" width="100%"><tr><td valign="top" width="325">
    <img src="http://coldwellbankerapps.com/images/ColdwellBanker_3d_small.jpg" alt="" width="100" height="54" /><br><input id="agentname" name="agentname" value="'.$agentname.'" /><br>
    <input id="direct" name="direct" value="Direct: '.$direct.'" /><br>
    <input id="fax" name="fax" value="Fax: '.$fax.'" /><br>
    <input id="email" name="email" value="'.$email.'" /><br>
    <input id="agentsite" name="agentsite" value="'.$agentsite.'" /><br>
    <input id="agentaddress" name="agentaddress" value="'.$agentaddress.'"/><br>
    <img src="'.$agentphoto.'" width="100" height="150" id="agentphotos" />
	<input value="'.$agentphoto.'" type="hidden" id="agentphoto" name="agentphoto" /><br>';
    
	if($propstyle != ""){
		echo '<input id="propstyle" name="propstyle" value="'.$propstyle.'" class="front" id="propstyle" /><br>';
	} else {
		echo '<input id="propstyle" name="propstyle" value="Property Style" class="front" id="propstyle" /><br>';	
	}
	
	echo '<input id="price" name="price" value="'.$price.'" class="front" /><br>
    <b>Taxes:</b> <input id="taxes" name="taxes" value="'.$taxes.'" class="front" /><br>
    <span id="associationContainer"><b>Association Dues:</b> <input id="association" name="association" value="'.$association.'" class="front" style="width:170px!important;" /></span><span style="cursor:pointer;color:#F00;font-weight:bold;border:1px solid #C00;position:relative; left:0px!important" id="deleteAssociation">X</span><br>  
    <b>Tax Key #:</b> <input id="taxkey" name="taxkey" value="'.$taxkey.'" class="front" /><br>
    <input id="villagelabel" name="villagelabel" value="Municipality:" class="label" style="color:#444444!important;position:relative;right:3px;" /> <input id="village" name="village" value="'.$village.'" class="front" /><br>
    <b>County:</b> <input id="county" name="county" value="'.$county.'" class="front" /><br>
    <b>School District:</b> <input id="schooldistrict" name="schooldistrict" value="'.$schooldistrict.'" class="front" /><br>
    <b>Elementary:</b> <input id="elementaryschool" name="elementaryschool" value="'.$elementaryschool.'" class="front" /><br>
    <b>Middle School:</b> <input id="middleschool" name="middleschool" value="'.$middleschool.'" class="front" /><br>
    <b>High School:</b> <input id="highschool" name="highschool" value="'.$highschool.'" class="front" /><br>    
    <b>Location:</b> <input id="location" name="location" value="'.$location.'" class="front" /><br>
    <b>Lot Size:</b> <input id="lotsize" name="lotsize" value="'.$lotsize.'" class="front" /><br>
    <b>Year Built:</b> <input id="approximateage" name="approximateage" value="'.$approximateage.'" class="front" /><br>
    <b>Exterior:</b> <input id="exterior" name="exterior" value="'.$exterior.'" class="front" /><br>    <b>Roof: </b><input id="roof" name="roof" value="'.$roof.'" class="front" /><br>
     <b>Basement:</b> <input id="basement" name="basement" value="'.$basement.'" class="front" /><br>
     <b>Garage:</b> <input id="garage" name="garage" value="'.$garage.'" class="front" /><br>
     <b>Heat System:</b> <input id="heatsystem" name="heatsystem" value="'.$heatsystem.'" class="front" /><br>
     <b>Central Air:</b> <input id="centralair" name="centralair" value="'.$centralair.'" class="front" /><br>    
     <b>Water:</b> <input id="water" name="water" value="'.$water.'" class="front" /><br>   
     <b>Sanitary System:</b> <input id="sanitarysystem" name="sanitarysystem" value="'.$sanitarysystem.'" class="front" /><br>
	 <b>Utility Budget:</b> <input id="budget" name="budget" value="'.$budget.'" class="front" /><br>
     <b>Flood Plain:</b> <input id="floodplain" name="floodplain" value="'.$floodplain.'" class="front" /><br>  
     <b>Occupancy:</b> <input id="occupancy" name="occupancy" value="'.$occupancy.'" class="front" /><br>
     <b>Code Compliance:</b>   <select name="code" id="code" class="single">
            <option value="Yes" selected>Yes</option>
            <option value="No">No</option>
        </select><br> 
     <b>MLS #:</b> <input id="mls" name="mlsid" value="'.$mlsid.'" class="front" /><br>	
	</td><td valign="top" align="center">
	<img src="'.$housephoto.'" width="425" height="319" id="housephotos"/>
	<input value="'.$housephoto.'" type="hidden" id="housephoto" name="housephoto"/>
	<input value="'.$address.'" type="text" name="address" id="address"><br>
	<table width="450" border="0" cellpadding="3" cellspacing="0"><tr>
	  <td width="72" align="center" style="border:1px solid #cccccc"><img src="images/level.jpg" width="11" height="38" border="0"></td>
	  <td colspan="2" align="left" style="border:1px solid #cccccc">
	    <b>Property Type:</b> <input id="proptype" name="proptype" value="'.$proptype.'" class="shorter"/><br>
	    <b>Total Rooms:</b> <input id="totalrooms" name="totalrooms" value="'.$totalrooms.'" class="shorter" /><br>
	    <b>Bedrooms:</b> <input id="bedrooms" name="bedrooms" value="'.$bedrooms.'" class="shorter" /><br>
	    <b>Baths:</b> <input id="baths" name="baths" value="'.$bathspart.'" class="shorter" />      </td>
	  </tr>
	  <tr id="LivingRoom">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addLivingRoom">+</span>
        <select name="level1" id="level1" class="single">
            <option value="U" selected>U</option>
            <option value="M">M</option>
            <option value="L">L</option>
        </select>
        </td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="livingroomlabel" name="livingroomlabel" value="Living Room:" class="label" /><span class="delete" id="deleteLivingRoom">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="livingroom" name="livingroom" value="'.$livingroom.'" class="shorter" /></td>
	    </tr>
         <tr id="LivingRoomHidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden">+</span>
        <select name="level1Hidden" id="level1Hidden" class="single">
        	<option value="" selected></option>
            <option value="U">U</option>
            <option value="M">M</option>
            <option value="L">L</option>
        </select>
        </td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="livingroomlabelHidden" name="livingroomlabelHidden" value="" class="label" /><span class="delete" id="deleteLivingRoomHidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="livingroomHidden" name="livingroomHidden" value="" class="shorter" /></td>
	    </tr>
	  <tr id="DiningRoom">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addDiningRoom">+</span>
        <select name="level2" id="level2" class="single">
	      <option value="U" selected>U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="diningroomlabel" name="diningroomlabel" value="Dining Room:" class="label" /><span class="delete" id="deleteDiningRoom">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="diningroom" name="diningroom" value="'.$diningroom.'" class="shorter" /></td>
	    </tr>
         <tr id="DiningRoomHidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden" id="addDiningRoomHidden">+</span>
        <select name="level2Hidden" id="level2Hidden" class="single">
          <option value="" selected></option>
	      <option value="U">U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="diningroomlabelHidden" name="diningroomlabelHidden" value="" class="label" /><span class="delete" id="deleteDiningRoomHidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="diningroomHidden" name="diningroomHidden" value="" class="shorter" /></td>
	    </tr>
	  <tr id="Kitchen">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addKitchen">+</span>
        <select name="level3" id="level3" class="single">
	      <option value="U" selected>U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="kitchenlabel" name="kitchenlabel" value="Kitchen:" class="label" /><span class="delete" id="deleteKitchen">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="kitchen" name="kitchen" value="'.$kitchen.'" class="shorter" /></td>
	    </tr>
        <tr id="KitchenHidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden">+</span>
        <select name="level3Hidden" id="level3Hidden" class="single">
	   	  <option value="" selected></option>
          <option value="U">U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="kitchenlabelHidden" name="kitchenlabelHidden" value="" class="label" /><span class="delete" id="deleteKitchenHidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="kitchenHidden" name="kitchenHidden" value="" class="shorter" /></td>
	    </tr>
	  <tr id="FamilyRoom">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addFamilyRoom">+</span>
        <select name="level4" id="level4" class="single">
	      <option value="U" selected>U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="familyroomlabel" name="familyroomlabel" value="Family Room:" class="label" /><span class="delete" id="deleteFamilyRoom">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="familyroom" name="familyroom" value="'.$familyroom.'" class="shorter" /></td>
	    </tr>
        <tr id="FamilyRoomHidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden">+</span>
        <select name="level4Hidden" id="level4Hidden" class="single">
          <option value="" selected></option>
	      <option value="U">U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="familyroomlabelHidden" name="familyroomlabelHidden" value="" class="label" /><span class="delete" id="deleteFamilyRoomHidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="familyroomHidden" name="familyroomHidden" value="" class="shorter" /></td>
	    </tr>
	  <tr id="PowderRoom">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addPowderRoom">+</span>
        <select name="level5" id="level5" class="single">
	      <option value="U" selected>U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="powderroomlabel" name="powderroomlabel" value="Powder Room:" class="label" /><span class="delete" id="deletePowderRoom">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="powderroom" name="powderroom" value="'.$powderroom.'" class="shorter" /></td>
	    </tr>
         <tr id="PowderRoomHidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden">+</span>
        <select name="level5Hidden" id="level5Hidden" class="single">
          <option value="" selected></option>
	      <option value="U">U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="powderroomlabelHidden" name="powderroomlabelHidden" value="" class="label" /><span class="delete" id="deletePowderRoomHidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="powderroomHidden" name="powderroomHidden" value="" class="shorter" /></td>
	    </tr>
	  <tr id="Bath">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addBath">+</span>
        <select name="level6" id="level6" class="single">
	      <option value="U" selected>U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="bathlabel" name="bathlabel" value="Bath:" class="label" /><span class="delete" id="deleteBath">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="bath" name="bath" value="'.$bath.'" class="shorter" /></td>
	    </tr>
          <tr id="BathHidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden">+</span>
        <select name="level6Hidden" id="level6Hidden" class="single">
          <option value="" selected></option>
	      <option value="U">U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="bathlabelHidden" name="bathlabelHidden" value="" class="label" /><span class="delete" id="deleteBathHidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="bathHidden" name="bathHidden" value="" class="shorter" /></td>
	    </tr>
	  <tr id="MasterBedroom">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addMasterBedroom">+</span>
        <select name="level7" id="level7" class="single">
	      <option value="U" selected>U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="masterbedroomlabel" name="masterbedroomlabel" value="Master Bedroom:" class="label" /><span class="delete" id="deleteMasterBedroom">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="masterbedroom" name="masterbedroom" value="'.$masterbedroom.'" class="shorter" /></td>
	    </tr>
          <tr id="MasterBedroomHidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden">+</span>
        <select name="level7Hidden" id="level7Hidden" class="single">
          <option value="" selected></option>
	      <option value="U">U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="masterbedroomlabelHidden" name="masterbedroomlabelHidden" value="" class="label" /><span class="delete" id="deleteMasterBedroomHidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="masterbedroomHidden" name="masterbedroomHidden" value="" class="shorter" /></td>
	    </tr>       
	  <tr id="MasterBath">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addMasterBath">+</span>
        <select name="level8" id="level8" class="single">
	      <option value="U" selected>U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="masterbathlabel" name="masterbathlabel" value="Master Bath:" class="label" /><span class="delete" id="deleteMasterBath">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="masterbath" name="masterbath" value="'.$masterbath.'" class="shorter" /></td>
	    </tr>
        
        <tr id="MasterBathHidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden">+</span>
        <select name="level8Hidden" id="level8Hidden" class="single">
          <option value="" selected></option>
	      <option value="U">U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="masterbathlabelHidden" name="masterbathlabelHidden" value="" class="label" /><span class="delete" id="deleteMasterBathHidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="masterbathHidden" name="masterbathHidden" value="" class="shorter" /></td>
	    </tr>       
	  <tr id="Bedroom1">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addBedroom1">+</span>
        <select name="level9" id="level9" class="single">
	      <option value="U" selected>U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="bedroom1label" name="bedroom1label" value="Bedroom:" class="label" /><span class="delete" id="deleteBedroom1">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="bedroom1" name="bedroom1" value="'.$bedroom1.'" class="shorter" /></td>
	    </tr>
	  <tr id="Bedroom1Hidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden">+</span>
        <select name="level9Hidden" id="level9Hidden" class="single">
          <option value="" selected></option>
	      <option value="U" >U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="bedroom1labelHidden" name="bedroom1labelHidden" value="" class="label" /><span class="delete" id="deleteBedroom1Hidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="bedroom1Hidden" name="bedroom1Hidden" value="" class="shorter" /></td>
	    </tr>
	  <tr id="Bedroom2">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addBedroom2">+</span>
        <select name="level10" id="level10" class="single">
	      <option value="U" selected>U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="bedroom2label" name="bedroom2label" value="Bedroom:" class="label" /><span class="delete" id="deleteBedroom2">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="bedroom2" name="bedroom2" value="'.$bedroom2.'" class="shorter" /></td>
	    </tr>
        <tr id="Bedroom2Hidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden">+</span>
        <select name="level10Hidden" id="level10Hidden" class="single">
          <option value="" selected></option>
	      <option value="U" >U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="bedroom2labelHidden" name="bedroom2labelHidden" value="" class="label" /><span class="delete" id="deleteBedroom2Hidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="bedroom2Hidden" name="bedroom2Hidden" value="" class="shorter" /></td>
	    </tr>
          <tr id="Bedroom3">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addBedroom3">+</span>
        <select name="level11" id="level11" class="single">
	      <option value="U" selected>U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="bedroom3label" name="bedroom3label" value="Bedroom:" class="label" /><span class="delete" id="deleteBedroom3">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="bedroom3" name="bedroom3" value="'.$bedroom3.'" class="shorter" /></td>
	    </tr>
	  <tr id="Bedroom3Hidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden">+</span>
        <select name="level11Hidden" id="level11Hidden" class="single">
          <option value="" selected></option>
	      <option value="U">U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="bedroom3labelHidden" name="bedroom3labelHidden" value="" class="label" /><span class="delete" id="deleteBedroom3Hidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="bedroom3Hidden" name="bedroom3Hidden" value="" class="shorter" /></td>
	    </tr>
	  <tr id="UtilityRoom">
	    <td style="border:1px solid #cccccc">
        <span class="add" id="addUtilityRoom">+</span>
        <select name="level12" id="level12" class="single">
	      <option value="U" selected>U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="utilityroomlabel" name="utilityroomlabel" value="Utility Room:" class="label" /><span class="delete" id="deleteUtilityRoom">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="utilityroom" name="utilityroom" value="'.$utilityroom.'" class="shorter" /></td>
	    </tr>
        <tr id="UtilityRoomHidden">
	    <td style="border:1px solid #cccccc">
        <span class="addHidden">+</span>
        <select name="level12Hidden" id="level12Hidden" class="single">
          <option value="" selected></option>
	      <option value="U">U</option>
	      <option value="M">M</option>
	      <option value="L">L</option>
	      </select></td>
	    <td width="125" align="left" style="border:1px solid #cccccc"><input id="utilityroomlabelHidden" name="utilityroomlabelHidden" value="" class="label" /><span class="delete" id="deleteUtilityRoomHidden">X</span></td>
	    <td align="left" style="border:1px solid #cccccc"><input id="utilityroomHidden" name="utilityroomHidden" value="" class="shorter" /></td>
	    </tr>
	  <tr>
      <td style="border-top:1px solid #cccccc;border-left:1px solid #cccccc;border-bottom:1px solid #cccccc"></td><td style="border-top:1px solid #cccccc;border-bottom:1px solid #cccccc"></td>
	    <td align="left" style="border-top:1px solid #cccccc;border-right:1px solid #cccccc;border-bottom:1px solid #cccccc"><b>Home Warranty:</b><input type="checkbox" class="single" value="Home Warranty Included" name="homewarranty" id="homewarranty" /></td>
	    </tr>
	  <tr>
	    <td colspan="3" style="border:1px solid #cccccc" align="left"><font size="1"><br>	
	      The information contained herein is furnished by the owner to the best of his her knowledge, but is subject to verification by the purchaser and agent assumes no responsibility for correctness. The sole offering is made subject to errors, omissions, change of price, prior sale or withdrawal without notice. In accordance with the law, this property is offered without respect to race, color, creed, national origin, physical limitations, or familial status. Room sizes are approximate.<br>
	      <br>
	      <img src="http://coldwellbankerapps.com/images/disclaimer_logo_house.gif" width="11" height="11">Owned and operated by NRT.</font></td>
      </tr></table>
	</td></tr>
  <tr>
    <td colspan="2"><br><br><textarea id="description" name="description">'.$description.'</textarea><br><br>	
	Inclusions: <input id="inclusions" name="inclusions" value="'.$inclusions.'" class="long" /><br>
	Exclusions: <input id="exclusions" name="exclusions" value="'.$exclusions.'" class="long" /><br>
	Directions: <input id="directions" name="directions" value="'.$directions.'" class="long" /></td>
  </tr>
</table>';

    ?>
</div>



<p align="center">
<input type="submit" value="GENERATE PDF"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <button type="button" onClick="window.location.replace('index.php')">Create New Flyer</button><br><br>
<button type="button" id="saveListing">Save Listing</button>  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <button type="button" id="loadListing">Load Listing</button>
</p>
<div id="status" class="center"></div>
<br><br>
</form>
<script>
 		var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-31321285-1']);
		  _gaq.push(['_trackPageview']);
		
		  (function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
</script>
</body>
</html>

<?php
  
} else {
	header("location:http://coldwellbankerapps.com/wi_flyers");	
}

?>