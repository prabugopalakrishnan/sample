var app = angular.module('signoutReport', ['mpages','ngGrid']);

app.controller('MainController', function ($scope, mpages) {
	$scope.currentReport = "Hospitalist Signout Report";
	$scope.signoutReports = [
		"Hospitalist Signout Report",
		"Hospitalist Signout Report 1",
		"Hospitalist Signout Report 2",
		"Hospitalist Signout Report 3",
		"Hospitalist Signout Report 4",
		"Hospitalist Signout Report 5",
		"Hospitalist Signout Report 6",
		"Hospitalist Signout Report 7"
	];
	
	$scope.patientLists = [
		"patient list 1",
		"patient list 2",
		"patient list 3",
		"patient list 4",
		"patient list 5",
		"patient list 6",
		"patient list 7",
	];
	
	$scope.loading = false; //true;
	$scope.dataLogFlag = false; //true;
	$scope.showConfirmModal = false;
	$scope.confirmFunction = $.noop;
	$scope.confirmFunctionParams = [];
	$scope.blockInput = false;
	$scope.pListCurrent = {
		NAME:"Select Patient List",
		PATIENT_LIST_ID: -1
	}
	$scope.obData = [];
	
	$scope.confirm = function (text, func, paramsArray) {
		$scope.confirmText = text;
		$scope.confirmFunction = func;

		if (angular.isArray(paramsArray))
			$scope.confirmFunctionParams = paramsArray;
		else
			$scope.confirmFunctionParams = [];

		$scope.showConfirmModal = true;
	};

	$scope.confirmAction = function () {
		$scope.confirmFunction.apply(this, $scope.confirmFunctionParams);
		$scope.showConfirmModal = false;
	};	

	mpages.loadCCL({ scriptName: 'nmh_get_patient_lists_by_user', prompts: ['',mpages.params.userId,''], recordName: 'patientLists'},function(reply){
		$scope.pLists = mpages.data.patientLists.LIST;
	});
	
	$scope.Patients = 
				[{name: "Jones, Moroni", age: "50 Years", eid: 1, unit: "Feinberg 12 W", dob: "01/05/1954", room: "1242",MRN: "009900000268", patientData: {}, showData: true },
				{name: "Blaker, Tiancum", age: "43 Years", eid: 2, unit: "Feinberg 13 E", dob: "03/05/1957", room: "1315",MRN: "009900000263", patientData: {}, showData: false},
				{name: "Paul, Jacob", age: "27 Years", eid: 3, unit: "CT Scan", dob: "10/07/1959", room: "",MRN: "009900000333", patientData: {}, showData: false},
				{name: "Halters, Nephi", age: "29 Years", eid: 4, unit: "Diag Test Cent", dob: "04/05/1964", room: "",MRN: "009900000264", patientData: {}, showData: false},
				{name: "Prest, Enos", age: "34 Years", eid: 5, unit: "Feinberg 12 W", dob: "11/05/1959",room: "1244",MRN: "009900000265", patientData: {}, showData: false}];

	
	$scope.headers = [
		{head: "Patient Name", column: "name"},
		{head: "Age", column: "age"},
		{head: "DOB", column: "dob"},
		{head: "Unit", column: "unit"},
		{head: "Room", column: "room"},
		{head: "MRN", column: "MRN"}
	];
		
	$scope.sort = {
		column: 'subStatus',
		descending: false
	};
		
	$scope.changeSorting = function(curSort, column) {
		var sort = curSort;
		
		if (sort.column == column) {
			sort.descending = !sort.descending;
		} else {
			sort.column = column;
			sort.descending = false;
		}
	};
	
	
});