var app = angular.module('highRiskOBTracker', ['mpages','ngGrid']);

app.controller('MainController', function ($scope, mpages) {
	$scope.pageTitle = "High Risk OB Tracker";
	$scope.curPage = 'ob_tracker';
	$scope.loading = false; //true;
	$scope.dataLogFlag = false; //true;
	$scope.showConfirmModal = false;
	$scope.confirmFunction = $.noop;
	$scope.confirmFunctionParams = [];
	$scope.blockInput = false;
	$scope.pListCurrent = {
		NAME:"Select Patient List",
		PATIENT_LIST_ID: -1
	}
	$scope.obData = [];
	
	$scope.confirm = function (text, func, paramsArray) {
		$scope.confirmText = text;
		$scope.confirmFunction = func;

		if (angular.isArray(paramsArray))
			$scope.confirmFunctionParams = paramsArray;
		else
			$scope.confirmFunctionParams = [];

		$scope.showConfirmModal = true;
	};

	$scope.confirmAction = function () {
		$scope.confirmFunction.apply(this, $scope.confirmFunctionParams);
		$scope.showConfirmModal = false;
	};	

	mpages.loadCCL({ scriptName: 'nmh_get_patient_lists_by_user', prompts: ['',mpages.params.userId,''], recordName: 'patientLists'},function(reply){
		$scope.pLists = mpages.data.patientLists.LIST;
	});
	
	$scope.getPatients = function(list){
		$scope.pListCurrent = list;
		
		// get patients for this list
		$scope.blockInput = true;
		mpages.loadCCL({ scriptName: 'nmh_get_patients_by_plist', prompts: ['',list.PATIENT_LIST_ID], recordName: 'patients'},function(reply){
			$scope.blockInput = false;
			var patients = mpages.data.patients.LIST;
			console.log(mpages.data);
			
			for(p in patients){
				var ph = [];
				//build Phone tooltip and exclude all zero phone numbers
				for(phNum in patients[p].PHONE)
					if(patients[p].PHONE[phNum].NUMBER != "(000) 000-0000")
						ph.push({"number": patients[p].PHONE[phNum].NUMBER ,"type": patients[p].PHONE[phNum].TYPE.replace("Pager personal","Mobile")});				
			
				$scope.obData.push(
					{name: patients[p].PATIENT_NAME
					, age: patients[p].AGE
					, eid: patients[p].ENCNTR_ID
					, edc: "05-"+(+p+1)+"-2013"
					, dob: patients[p].DOB.substr(0,10)
					, priOb: "Dr. Bill"
					, priObSaveBtn: false
					, phone: (ph.length) ? (ph[0].number + " " + ph[0].type):""
					, fullPhone: ph
					, gravPara: "GP text " + patients[p].ENCNTR_ID 
					, comment: "Comments "+p+"....."}
				);
			}
		});	
	}	
	
/* $scope.obData = 
				[{name: "Jones, Moroni", age: "50 Years", eid: 1, edc: "05/25/2013", dob: "01/05/1954", priOb: "Dr. Bill",phone: "(773) 874-6648 Home", gravPara: "GP text 1", comment: "Comments 1....."},
				{name: "Blake, Tiancum", age: "43 Years", eid: 2, edc: "04/25/2011", dob: "03/05/1957", priOb: "Dr. Wong",phone: "(312) 874-6648 Home", gravPara: "GP text 2", comment: "Comments 2....."},
				{name: "Raul, Jacob", age: "27 Years", eid: 3, edc: "03/25/2012", dob: "10/07/1959", priOb: "Dr. Chin",phone: "(708) 874-6648 Home", gravPara: "GP text 3", comment: "Comments 3....."},
				{name: "Walters, Nephi", age: "29 Years", eid: 4, edc: "02/25/2010", dob: "04/05/1964", priOb: "Dr. Walters",phone: "(663) 874-6648 Home", gravPara: "GP text 4", comment: "Comments 4....."},
				{name: "Preston, Enos", age: "34 Years", eid: 5, edc: "01/25/2013", dob: "11/05/1959", priOb: "Dr. John",phone: "(847) 874-6648 Home", gravPara: "GP text 5", comment: "Comments 5....."}];
*/
	
	$scope.gridOptions = { 
		data: 'obData',
		columnDefs: [
			{displayName: "Patient Name", field: "name"},
			{displayName: "DOB", field: "dob", width: 90},
			{displayName: "Age", field: "age", width: 75},
			{displayName: "Primary OB", field: "priOb",
				cellTemplate:'<input ng-model="row.entity[col.field]" ng-dblclick="makeEditable(row,col)" class="stealthInput" title="Double click to edit Primary OB" id="OB{{row.getProperty(\'eid\')}}" readonly="readonly">'
							+'<a class="btn btn-small btn-danger" id="obSaveBtn" ng-model="row.entity[\'priObSaveBtn\']"><i class="icon-hdd icon-white"></i></a></input>'},
			{displayName: "Phone Number", field: "phone",
				cellTemplate:'<div class="dispLine" ng-dblclick="makeEditable(row,col)" ng-mouseenter="tooltipEnter($event)" ng-mouseleave="tooltipLeave($event,false)">{{row.entity[col.field]}}</div>'
							+'<div class="ttip" ng-mouseleave="tooltipLeave($event,true)"><ul>'
							+'<li ng-repeat="ph in row.entity[\'fullPhone\']">{{ph.number}} {{ph.type}}</li>'
							+'</ul></div>'},
			{displayName: "Gravida/Para", field: "gravPara",
				cellTemplate:'<textarea ng-model="row.entity[col.field]" class="stealthInput" title="Double click to edit Gravida/Para" id="GP{{row.getProperty(\'eid\')}}" readonly="readonly"></textarea>'
							+'<div class="dispLine" ng-dblclick="makeEditable(row,col)" ng-mouseenter="tooltipEnter($event)" ng-mouseleave="tooltipLeave($event,false)">{{row.entity[col.field]}}</div>'
							+'<div class="ttip" ng-mouseleave="tooltipLeave($event,true)">{{row.entity[col.field]}}</div>'},
			{displayName: "EDC", field: "edc", width: 100,
				cellTemplate: '<input ui-date="dateOptions" ui-date-format="mm-dd-yy" ng-dblclick="makeEditable(row,col)" class="stealthInput" ng-model="row.entity[col.field]" title="Double click to Select Date" id="EDC{{row.getProperty(\'eid\')}}" />',
				sortFn: edcSortFunc},
			{displayName: "Comments", field: "comment",
				cellTemplate:'<textarea ng-model="row.entity[col.field]" class="stealthInput" title="Double click to Select Date" id="COM{{row.getProperty(\'eid\')}}" readonly="readonly"></textarea>'
							+'<div class="dispLine" ng-dblclick="makeEditable(row,col)" ng-mouseenter="tooltipEnter($event)" ng-mouseleave="tooltipLeave($event,false)">{{row.entity[col.field]}}</div>'
							+'<div class="ttip" ng-mouseleave="tooltipLeave($event,true)">{{row.entity[col.field]}}</div>'}
		],
		multiSelect: false,
		showFilter: true,
		showColumnMenu: true
	};
	
	$scope.dateOptions = {
		dateFormat: "mm-dd-yy",
		showOn: "button"
	};
	
	$scope.tooltipEnter = function(ev){
		var el = (ev.target||ev.srcElment);
		if (angular.element(el).text() != ''){
			//Relocate tooltip outside of table so it can show on top of table
			angular.element(el).siblings("div.ttip").detach().appendTo("#tblContainer");
			
			var pos = mpages.findElePosition(el);
			
			//Close any open tooltips prior to opening the new one
			angular.element("div.ttip").hide();
			angular.element("#tblContainer > div.ttip").css({'top':(pos.top-30)+'px','left':(pos.left-280)+'px'}).fadeIn();
		}
	}
	
	$scope.tooltipLeave = function(ev, closeAll){
		if(closeAll)
			angular.element("div.ttip").hide();
		else{
			var ttEl = angular.element("#tblContainer > div.ttip");
			ttEl.hide();
			ttEl.detach().appendTo(angular.element((ev.target||ev.srcElment)).parent());					
		}
	}

	$scope.makeEditable = function(row,col){
		//Find cell element
		var el = angular.element(row.elm).find(".col" + col.index +" :input")[0];
		var rowHeight;
		
		if(!el)
			return;
		
		angular.element(el).css("background-color","white");
		angular.element(el).css("border", "1px inset #000");
		angular.element(el).removeAttr("readonly");
		//row.entity['priObSaveBtn'] = true;
		console.log(row)
		el.select();
		
		console.log(angular.element(el))
		
		//trigger date picker
		if(angular.element(el).attr('ui-date'))
			angular.element(el).siblings("button").click();
		else if(angular.element(el).siblings('div').hasClass('dispLine')){
			angular.element(el).parent().css('height','218px');
			angular.element(el).parent().css('z-index','100'); //div container
			angular.element(el).parent().parent().css('z-index','1'); //row
			angular.element(el).css('height','210px');
			angular.element(el).css('overflow-y','auto');
			angular.element(el).css('white-space','normal');
			
			//Swap text area and table row display
			angular.element(el).siblings('div').hide();
			angular.element(el).show();
			angular.element(el).focus();
		}
		/*else if(){
			
		}*/
		
		angular.element(el).blur(function(){
			angular.element(this).css("background-color","transparent");
			angular.element(this).css("border", "none");
			angular.element(this).attr("readonly", "readonly");
			
			angular.element(this).css('overflow-y','hidden');
			angular.element(this).css('height','30px').parent().css('height','30px');
			angular.element(this).css('white-space','nowrap');
			//reset z-index on all rows
			angular.element(this).parent().parent().css('z-index','0').siblings().css('z-index','0');	
			
			if(angular.element(this).siblings('div').hasClass('dispLine')){
				//Swap text area and table row display
				angular.element(this).hide();
				angular.element(this).siblings('.dispLine').show();
			}
		});
	}
				
	function edcSortFunc(x,y){
		var dateRegEx = /(\d{1,2})-(\d{1,2})-(\d{4})/;
		var dateTextX = x;
		var dateTextY = y;
		var dateArray = dateRegEx.exec(dateTextX);
		//check if either dateText is not a valid date and re-execute
		if(dateArray == null){
			dateTextX = "01-01-1900";
			dateArray = dateRegEx.exec(dateTextX);
		}

		var a = new Date( 
			(+dateArray[3]), //year
			(+dateArray[1])-1, // Careful, month starts at 0!
			(+dateArray[2]) //day
		 );
		
		dateArray = dateRegEx.exec(dateTextY); 
		if(dateArray == null){
			dateTextY = "01-01-1900";
			dateArray = dateRegEx.exec(dateTextY);
		}
		var b = new Date(
			(+dateArray[3]), //year
			(+dateArray[1])-1, // Careful, month starts at 0!
			(+dateArray[2]) //day
		);

		return ((a < b) ? -1 : ((a > b) ?  1 : 0));			
	}

	function resizeTable(){
		//console.log(newHeight)
		var newHeight = angular.element(window).height() - 62 /*42px navbar + 20px margin bottom*/ - ((mpages.isIE7())?30:0) /*account for mpage pctoolbar*/;
		angular.element('.obTable').css("height", newHeight ); //subtract one pixel to stop initial overflow
	}			
	angular.element(window).resize(resizeTable);
	resizeTable();
});		
		
		
// var app = angular.module('trelloStatusReport', ['ui', 'ngResource']);

// app.config(['$routeProvider', function($routeProvider) {
	// $routeProvider.when('/report/:board', {  templateUrl: 'report.html', controller: 'BoardReport' })
				// .when('/workOrders', {  templateUrl: 'workOrders.html', controller: 'WorkOrders' })
				// .when('/closuresReport', {  templateUrl: 'closes.html', controller: 'Closes' })
				// .when('/capacity', {  templateUrl: 'capacity.html', controller: 'CapacityPlan' })
				// .when('/timeTracking', {  templateUrl: 'timeTracking.html', controller: 'TimeTracking' });
// }]);

// // this is used to allow angular to post to php nicely.
// app.config(function($httpProvider)
// {
  // // Use x-www-form-urlencoded Content-Type
  // $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
 
  // // Override $http service's default transformRequest
  // $httpProvider.defaults.transformRequest = [function(data)
  // {
    // return angular.isObject(data) && String(data) !== '[object File]' ? jQuery.param(data) : data;
  // }];
// });


// app.controller('MainController', function ($scope, $routeParams) {
    // $scope.Date = {};
    // $scope.Date.parse = Date.parse;
	// $scope.Boards = [
		// { id: '4f74b4dfcce84e564726ed53', title: 'Optimizations', active: false },
		// { id: '50dcd4e44b2cb9d71f0005df', title: 'General Requests', active: false },
		// { id: '50dcd4ee58aeb8e51f000221', title: 'Projects', active: false }
	// ];
	// $scope.curPage = 'status_reports';
// });

// app.controller('WorkOrders', function ($scope, $routeParams) {
	// $("#mainNav > li").removeClass('active');
	// $("#workOrdersNav").addClass('active');
	
	// $scope.we = 'Todo...';
// });


// var globals = {};

// globals.headers = [
	// {head: "Status", column: "closed"},
	// {head: "Name", column: "name"},
	// {head: "Score", column: "score"},
	// {head: "Scope", column: "scope"},
	// {head: "Requester", column: "requester"},
	// {head: "Requested Date", column: "requested"},
	// {head: "Ticket", column: "ticket"},
	// {head: "Category", column: "category"},
	// {head: "Sub-Status", column: "subStatus"},
	// {head: "Lever/Project", column: "listName"},
	// {head: "Assignee(s)", column: "members[0].fullName"},
	// {head: "Last Update", column: "lastCommentDtTm"},
	// {head: "Opened Date", column: "created_at"},
	// {head: "Due Date", column: "due"},
	// {head: "Closed Date", column: "closed_at"}
// ];
	
// globals.sort = {
	// column: 'subStatus',
	// descending: false
// };
	
// globals.changeSorting = function(curSort, column) {
	// var sort = curSort;
	
	// if (sort.column == column) {
		// sort.descending = !sort.descending;
	// } else {
		// sort.column = column;
		// sort.descending = false;
	// }
// };

// globals.beginYearDate = new Date();
// globals.oneWeekAgoDate = new Date();
// globals.oneMonthAgoDate = new Date();

// globals.beginYearDate.setMonth(0);
// globals.beginYearDate.setDate(1);
// globals.beginYearDate.setHours(0);
// globals.beginYearDate.setMinutes(0);
// globals.beginYearDate.setSeconds(0);
// globals.oneWeekAgoDate.setDate(globals.oneWeekAgoDate.getDate() - 7);
// globals.oneMonthAgoDate.setMonth(globals.oneMonthAgoDate.getMonth() - 1);

// // This function takes an array of cards from trello and an array of lists from trello
// //	and returns a new list of cards that has all the additional data elements that we
// //	need for reporting. In a sense it takes the Trello model and transforms it into
// //	our view-model which has extra data elements based on the Trello model.
// globals.processCardsAndLists = function(cardsInput, lists){
	// var comments = "";
	// var cards = cardsInput.slice(0); // make a copy so we don't mess with the original
	// var t = 0;
	// var d;
	// var h = "";
	
	// for (var i in cards){
	
		// for (var j in lists){
			// if (cards[i].idList == lists[j].id){
				// cards[i].listName = lists[j].name;
				// break;
			// }
		// } // match card to list
			
		// cards[i].comments = [];
		
		// if (cards[i].due){
			// d = new Date();
			// d.setFullYear(parseInt(cards[i].due.substring(0,4)),parseInt(cards[i].due.substring(5,7))-1,parseInt(cards[i].due.substring(8,10)));
			// cards[i].dueDate = d;
		// }
		
		// cards[i].hours = 0;
		// cards[i].hoursArray = [];
		
		
		// /* this is the area that parses through the description to pull out the back-dated closed date */
		// cards[i].closed_at = "";
		
		// if (cards[i].desc.indexOf("[closed:") > -1)
			// cards[i].closed_at = cards[i].desc.substring(cards[i].desc.indexOf("[closed:")+8, cards[i].desc.indexOf("]",cards[i].desc.indexOf("[closed:")+8));
		
		// for (var k in cards[i].actions){
			// if (cards[i].actions[k].type == 'createCard'){
				// d = new Date();
				// d.setFullYear(parseInt(cards[i].actions[k].date.substring(0,4)),parseInt(cards[i].actions[k].date.substring(5,7))-1,parseInt(cards[i].actions[k].date.substring(8,10)));
				// cards[i].creator = cards[i].actions[k].memberCreator.fullName;
				// cards[i].created_at = (d.getMonth() + 1) +'/'+ d.getDate() +'/'+ d.getFullYear();
				// cards[i].createdDate = d;
			// } else if (cards[i].actions[k].type == 'updateCard' && cards[i].closed){
				// d = new Date();
				// d.setFullYear(parseInt(cards[i].actions[k].date.substring(0,4)),parseInt(cards[i].actions[k].date.substring(5,7))-1,parseInt(cards[i].actions[k].date.substring(8,10)));
				
				// cards[i].closer = cards[i].actions[k].memberCreator.fullName;
				// if (cards[i].closed_at == ""){
					// cards[i].closed_at = (d.getMonth() + 1) +'/'+ d.getDate() +'/'+ d.getFullYear();
				// }
				// cards[i].closedDate = d;
				
				// if (d < globals.oneMonthAgoDate)
					// cards[i].filterOldClosed = true;
					
			// } else if (cards[i].actions[k].type == 'commentCard'){
				// d = new Date();
				// d.setFullYear(parseInt(cards[i].actions[k].date.substring(0,4)),parseInt(cards[i].actions[k].date.substring(5,7))-1,parseInt(cards[i].actions[k].date.substring(8,10)));

				// t = cards[i].actions[k].data.text.indexOf("[hours:");
				
				// if (t > -1){
					// h = parseInt(cards[i].actions[k].data.text.substring(t+7, cards[i].actions[k].data.text.indexOf("]",t+7)));
					// cards[i].hoursArray.push([d,h]);
					
					// if (cards[i].hours == 0){
						// cards[i].hours = h;
					// }
				// }
				
				
				// cards[i].comments.push(d.getMonth() + 1 + '/' + d.getDate() +'/'+ d.getFullYear() + ' (' + cards[i].actions[k].memberCreator.initials + '): ' + cards[i].actions[k].data.text);
				// if (!cards[i].lastCommentDtTm )
					// cards[i].lastCommentDtTm = d;
			// }
		// }
		
		// /* this is the area that parses through the description to pull out descrete elements */
		// if (cards[i].desc.indexOf("[score:") > -1 && parseInt(cards[i].desc.substring(cards[i].desc.indexOf("[score:")+7, cards[i].desc.indexOf("]",cards[i].desc.indexOf("[score:")+7))))
			// cards[i].score = parseInt(cards[i].desc.substring(cards[i].desc.indexOf("[score:")+7, cards[i].desc.indexOf("]",cards[i].desc.indexOf("[score:")+7)));
		// else 
			// cards[i].score = -1;
			
		// cards[i].category = "";
		// if (cards[i].desc.indexOf("[category:") > -1)
			// cards[i].category = cards[i].desc.substring(cards[i].desc.indexOf("[category:")+10, cards[i].desc.indexOf("]",cards[i].desc.indexOf("[category:")+10));
			
		// if (cards[i].desc.indexOf("[scope:") > -1)
			// cards[i].scope = cards[i].desc.substring(cards[i].desc.indexOf("[scope:")+7, cards[i].desc.indexOf("]",cards[i].desc.indexOf("[scope:")+7));
		// else 
			// cards[i].scope = 0;
			
		// cards[i].requester = "";
		// if (cards[i].desc.indexOf("[requestor:") > -1)
			// cards[i].requester = cards[i].desc.substring(cards[i].desc.indexOf("[requestor:")+11, cards[i].desc.indexOf("]",cards[i].desc.indexOf("[requestor:")+11));
			
		// if (cards[i].desc.indexOf("[requester:") > -1)
			// cards[i].requester = cards[i].desc.substring(cards[i].desc.indexOf("[requester:")+11, cards[i].desc.indexOf("]",cards[i].desc.indexOf("[requester:")+11));
		
		// if (cards[i].desc.indexOf("[requested:") > -1)
			// cards[i].requested = cards[i].desc.substring(cards[i].desc.indexOf("[requested:")+11, cards[i].desc.indexOf("]",cards[i].desc.indexOf("[requested:")+11));
			
		// if (cards[i].desc.indexOf("[ticket:") > -1)
			// cards[i].ticket = cards[i].desc.substring(cards[i].desc.indexOf("[ticket:")+8, cards[i].desc.indexOf("]",cards[i].desc.indexOf("[ticket:")+8));
		// else
			// cards[i].ticket = "";
			
		// cards[i].subStatus = "";
		// cards[i].color = "";
		
		// if (cards[i].closed){
			// cards[i].color = "grey";
		// } else {
			// for (var l in cards[i].labels){
				// if (l > 0)
					// cards[i].subStatus += ", ";
				// else
					// cards[i].color = cards[i].labels[l].color;
					
				// cards[i].subStatus += cards[i].labels[l].name;							
			// }	
		// }
			
	// } // loop cards
	
	// return cards;
// };

// app.controller('Closes', function ($scope, $routeParams, $http) {
	// $("#mainNav > li").removeClass('active');
	// $("#closesNav").addClass('active');
	// $scope.Cards = [];
	// $scope.headers = [
		// {head: "Status", column: "closed"},
		// {head: "Name", column: "name"},
		// {head: "Score", column: "score"},
		// {head: "Scope", column: "scope"},
		// {head: "requester", column: "requester"},
		// {head: "Requested Date", column: "requested"},
		// {head: "Ticket", column: "ticket"},
		// {head: "Category", column: "category"},
		// {head: "Sub-Status", column: "subStatus"},
		// {head: "Lever/Project", column: "listName"},
		// {head: "Bucket", column: "boardName"},
		// {head: "Assignee(s)", column: "members[0].fullName"},
		// {head: "Opened Date", column: "created_at"},
		// {head: "Due Date", column: "due"},
		// {head: "Closed Date", column: "closed_at"}
	// ];
	// $scope.sort = globals.sort;
	// $scope.changeSorting = globals.changeSorting;
	
	// var d;
	
	// $scope.startDate = new Date();
	// $scope.startDate.setDate($scope.startDate.getDate() - 7);
	// $scope.endDate = new Date();
	// $scope.endDate.setHours(23,59,59);
	
	// $scope.startDateInput = ($scope.startDate.getMonth() + 1) + '/' + $scope.startDate.getDate() + '/' + $scope.startDate.getFullYear();
	// $scope.endDateInput =($scope.endDate.getMonth() + 1) + '/' + $scope.endDate.getDate() + '/' + $scope.endDate.getFullYear();
	
	// $scope.searchDateRangeFromInput = function(){
		// $scope.startDate = new Date(Date.parse($scope.startDateInput));
		// $scope.endDate = new Date(Date.parse($scope.endDateInput));
		// $scope.endDate.setHours(23,59,59);
		
		// $scope.searchDateRange();
	// };
	
	// $scope.searchDateRange = function(){
		
		// angular.forEach($scope.closesMatrix, function(board){
			
			// for ( var y in board.boardLists ){
			
				// board.boardLists[y].closesCnt = 0;
				
				// for ( var z in board.boardLists[y].cards){
					// if (board.boardLists[y].cards[z].closed){
						// d = new Date(board.boardLists[y].cards[z].actions[0].date)
						// if (d > $scope.startDate && d < $scope.endDate){
							// board.boardLists[y].closesCnt++;						
						// }
					// }
				// } // end cards loop
			// } // end list loop
		// }); //end foreach board
	// };
	
	// $scope.closesMatrix = [
		// { boardTitle: $scope.Boards[0].title + ' Closed', boardId: $scope.Boards[0].id, boardLists: []},
		// { boardTitle: $scope.Boards[1].title + ' Closed', boardId: $scope.Boards[1].id, boardLists: []}
	// ];
	
	// var queryCards = function(){
		
		// var callbackCnt = 0;
		// $scope.Cards = [];
		
		// //&before='+$scope.endDate.toISOString()+'&since='+$scope.startDate.toISOString()
		// angular.forEach($scope.closesMatrix, function(board){
			// $http.post('trello_proxy.php',{Url:'/boards/'+board.boardId+'/cards',Options:'filter=closed&actions=updateCard:closed&members=true'}).success(function(cards){
				
				// for ( var k in cards){
					// for ( var l in board.boardLists ){
						// if (cards[k].idList == board.boardLists[l].id)
							// board.boardLists[l].cards.push(cards[k]);
					// }
					// for ( var i in $scope.closesMatrix ){
						// if ($scope.closesMatrix[i].boardId == cards[k].idBoard){
							// cards[k].boardName = $scope.closesMatrix[i].boardTitle;
						// }
					// }
				// }
				
				// callbackCnt++;
				// if (callbackCnt == $scope.closesMatrix.length){
					// $scope.searchDateRange();
					// $scope.loading = false;
				// }
				// $scope.Cards = $scope.Cards.concat(globals.processCardsAndLists(cards, $scope.Lists));
			// }); // end get cards
		// });
	// };
	
	// $scope.Lists = [];
	
	// var queryTrello = function(){
		// $scope.loading = true;
		
		// angular.forEach($scope.closesMatrix, function(board){
		
			// if ($scope.Lists.length){
				// queryCards();
			// } else {
				// $http.post('trello_proxy.php',{Url: '/boards/'+board.boardId+'/lists'}).success(function(lists){
					// $scope.Lists = lists;
					// for ( var j in lists){
						// board.boardLists.push(angular.extend(lists[j],{cards: [], closesCnt: 0}));
					// }
					// queryCards();
				// });// end get lists
			// }
	
		// }); // end for closes matrix
	// };
	// queryTrello();
// });


// // This control is bound to the body and is used for all views of this app.
// app.controller('BoardReport', function ($scope, $http, $routeParams) {
	// $("#mainNav > li").removeClass('active');
	// for ( var b in $scope.Boards ){
		// if ($routeParams.board == $scope.Boards[b].id)
			// $scope.Boards[b].active = true;
		// else
			// $scope.Boards[b].active = false;
	// }
	
	// $scope.Lists = [];
	// $scope.Cards = [];
	// $scope.totalClosed = 0;
	// $scope.totalOpen = 0;
	// $scope.closedLastWeek = 0;
	// $scope.closedYTD = 0;
	// $scope.labelCounts = [];
	
	// $scope.showClosed = false;
	// $scope.showAllActivity = false;
	
	// // initialize all of the labels
	// for (var i = 0; i < 6; i++ ){
		// $scope.labelCounts.push({
			// name : "",
			// val : 0
		// });
	// }
	
	// var beginYearDate = globals.beginYearDate;
	// var oneWeekAgoDate = globals.oneWeekAgoDate;
	// var oneMonthAgoDate = globals.oneMonthAgoDate;
	// $scope.oneWeekAgoDate = globals.oneWeekAgoDate;
	// $scope.headers = globals.headers;
	// $scope.sort = globals.sort;
	// $scope.changeSorting = globals.changeSorting;
	
	// $scope.totalRows = 0;
	// $scope.totalFilteredRows = 0;
	
	// var updateTotalRows = function(){
		// $scope.totalFilteredRows = _.filter($scope.Cards, function(card){ return !card.hideFromSearch; }).length;
		// $scope.totalRows = $scope.Cards.length;
		
		// for ( var i in $scope.labelCounts)
			// $scope.labelCounts[i].val = 0;
		
		// $scope.totalOpen = 0;
		// $scope.totalClosed = 0;
		// var cnt = 0;
		// _.each($scope.Cards, function(card){
		
			// if (!card.hideFromSearch){
			
				// //for (var l in card.labels)
				// if (card.closed){
					// $scope.totalClosed++;
				// } else {
					// $scope.totalOpen++;
					
					// if (card.labels.length){
						// switch(card.labels[0].color) {
							// case 'green':
							  // $scope.labelCounts[0].val++;
							  // break;
							// case 'yellow':
							  // $scope.labelCounts[1].val++;
							  // break;
							// case 'orange':
							  // $scope.labelCounts[2].val++;
							  // break;
							// case 'red':
							  // $scope.labelCounts[3].val++;
							  // break;
							// case 'purple':
							  // $scope.labelCounts[4].val++;
							  // break;
							// case 'blue':
							  // $scope.labelCounts[5].val++;
							  // break;
						// }	
					// }
				// }	
			// }
		// });

	// };
	// $scope.searchText = "";	
	// $scope.searchMemberName = "";
	// $scope.searchTicket = "";
	// $scope.searchRequesters = "";
	// $scope.searchCategory = "";
	// $scope.searchSubStatus = "";

	// $scope.filterCards = function(){
		// var m;
		
		// for (var c in $scope.Cards){
		
			// $scope.Cards[c].hideFromSearch = false;
			
			// if ($scope.searchMemberName > ""){
				// m = _.pluck($scope.Cards[c].members, 'fullName').join();
				// if (m.toUpperCase().indexOf($scope.searchMemberName.toUpperCase()) < 0){
					// $scope.Cards[c].hideFromSearch = true;
				// }
			// }
			
			// if ($scope.filteredList > "" && $scope.Cards[c].listName != $scope.filteredList)
				// $scope.Cards[c].hideFromSearch = true;
				
			// if ($scope.filteredCategorization > "" && $scope.Cards[c].boardName != $scope.filteredCategorization)
				// $scope.Cards[c].hideFromSearch = true;
				
			// if ($scope.searchSubStatus > "" && $scope.Cards[c].subStatus.toUpperCase().indexOf($scope.searchSubStatus.toUpperCase()) < 0)
				// $scope.Cards[c].hideFromSearch = true;
				
			// if ($scope.searchRequesters > "" && $scope.Cards[c].requester.toUpperCase().indexOf($scope.searchRequesters.toUpperCase()) < 0)
				// $scope.Cards[c].hideFromSearch = true;
			
			// if ($scope.searchCategory > "" && $scope.Cards[c].category.toUpperCase().indexOf($scope.searchCategory.toUpperCase()) < 0)
				// $scope.Cards[c].hideFromSearch = true;			
				
				
			// if ($scope.filteredOpenClose > ""){
				// if ($scope.filteredOpenClose == "Closed" && !$scope.Cards[c].closed)
					// $scope.Cards[c].hideFromSearch = true;
				// else if ($scope.filteredOpenClose == "Open" && $scope.Cards[c].closed)
					// $scope.Cards[c].hideFromSearch = true;
			// }
			
			// if ($scope.Cards[c].ticket.toUpperCase().indexOf($scope.searchTicket.toUpperCase()) < 0)
				// $scope.Cards[c].hideFromSearch = true;
				
			// if ($scope.Cards[c].name.toUpperCase().indexOf($scope.searchText.toUpperCase()) < 0 && $scope.Cards[c].ticket.toUpperCase().indexOf($scope.searchText.toUpperCase()) < 0)
				// $scope.Cards[c].hideFromSearch = true;
		// }
		
		// updateTotalRows();
	// };
	
	
	
	// // optimizations board
    // var queryTrello = function(){
		// $scope.loading = true;
		
		// $http.post('trello_proxy.php', {'Url': '/boards/'+$routeParams.board+'/labelNames'}).success(function(labels){
			// $scope.labelCounts[0].name = labels.green;
			// $scope.labelCounts[1].name = labels.yellow;
			// $scope.labelCounts[2].name = labels.orange;
			// $scope.labelCounts[3].name = labels.red;
			// $scope.labelCounts[4].name = labels.purple;
			// $scope.labelCounts[5].name = labels.blue;
		// });
		
		// $http.post('trello_proxy.php',{'Url': '/boards/'+$routeParams.board+'/lists'}).success(function(lists){
			// $scope.Lists = lists;
			// $http.post('trello_proxy.php', {'Url': '/boards/'+$routeParams.board+'/cards', 'Options': 'filter=all&members=true&checklists=all&actions=commentCard,createCard,updateCard:closed'}).success(function(cards){
					

					
				// $scope.Cards = globals.processCardsAndLists(cards, lists);
				// updateTotalRows();
				// $scope.loading = false;
				
			// }); // get cards
									
		// }); // get lists
		
	// }; // onAuthorize
	// queryTrello();
// });


// app.controller('CapacityPlan',function($scope, $http){
	// $("#mainNav > li").removeClass('active');
	// $("#capacityNav").addClass('active');
	
	// var startDate = new Date();
	// var endDate = new Date();
	// var callbackCnt = 0;
	// var cardsArray = [];
	// $scope.dateHeaders = [];
	// $scope.Cards = [];
	
	// var oneMonthAgoDate = new Date();
	// oneMonthAgoDate.setMonth(oneMonthAgoDate.getMonth() - 1);
	
	// $scope.searchMemberName = "";
	
	// $scope.filterCards = function(){
		// var m;
		
		// for (var c in $scope.Cards){
		
			// $scope.Cards[c].hideFromSearch = false;
			
			// if ($scope.searchMemberName > ""){
				// m = _.pluck($scope.Cards[c].members, 'fullName').join();
				// if (m.toUpperCase().indexOf($scope.searchMemberName.toUpperCase()) < 0){
					// $scope.Cards[c].hideFromSearch = true;
				// }
			// }
			
			// if ($scope.filteredList > "" && $scope.Cards[c].listName != $scope.filteredList)
				// $scope.Cards[c].hideFromSearch = true;
				
			// if ($scope.filteredCategorization > "" && $scope.Cards[c].boardName != $scope.filteredCategorization)
				// $scope.Cards[c].hideFromSearch = true;
				
			// if ($scope.searchSubStatus > "" && $scope.Cards[c].subStatus.toUpperCase().indexOf($scope.searchSubStatus.toUpperCase()) < 0)
				// $scope.Cards[c].hideFromSearch = true;
				
			// if ($scope.filteredOpenClose > ""){
				// if ($scope.filteredOpenClose == "Closed" && !$scope.Cards[c].closed)
					// $scope.Cards[c].hideFromSearch = true;
				// else if ($scope.filteredOpenClose == "Open" && $scope.Cards[c].closed)
					// $scope.Cards[c].hideFromSearch = true;
			// }
		// }
	// };
	
	
	// var drawTable = function(cardsArray){
	
		// if ( !$scope.dateHeaders.length || $scope.dateHeaders.length && ($scope.dateHeaders[0] < startDate || _.last($scope.dateHeaders) > endDate) ){
			// var t = new Date(startDate.valueOf());
			// t.setDate(1);
			// t.setHours(0,0,0,0);
			// $scope.dateHeaders = [];
			// $scope.dateHeaders.push(new Date(t));
			
			// while ( t < endDate ){
				// t.setDate(1);
				// t.setMonth(t.getMonth()+1);
				// t.setHours(0,0,0,0);	
				// $scope.dateHeaders.push(new Date(t));
			// }
		// }
		
		// _.each(cardsArray, function(card){
			// var d = new Date();
			
			
			// if (card.dueDate){

				// var d2 = new Date(card.dueDate.valueOf());
				// d2.setDate(1);
				// d2.setHours(0,0,0,0);
				// card.dueDateSection = d2;
			// } else {
				// card.dueDateSection = "";
			// }
						
			// if (card.createdDate){
				// var d2 = new Date(card.createdDate.valueOf());
				// d2.setDate(1);
				// d2.setHours(0,0,0,0);
				// card.createdDateSection = d2;
			// }
			
			// if (card.closedDate){
				// var d2 = new Date(card.closedDate.valueOf());
				// d2.setDate(1);
				// d2.setHours(0,0,0,0);
				// card.closedDateSection = d2;
			// }
		// });
		
		// // push the new cardsArray to the total list of cards, then sort the total list by due date
		// $scope.Cards = _.sortBy($scope.Cards.concat(cardsArray), 'dueDate');
	// };
	

	// _.each($scope.Boards, function(board){
		// $http.post('trello_proxy.php',{'Url': '/boards/'+board.id+'/lists'}).success(function(lists){
			// $scope.Lists = lists;
			// $http.post('trello_proxy.php', {'Url': '/boards/'+board.id+'/cards', 'Options': 'filter=all&members=true&actions=createCard,updateCard:closed'}).success(function(cards){
			
				// var processedCards = globals.processCardsAndLists(cards, lists);
				// _.each(cards, function(card){
					// for ( var i in $scope.Boards ){
						// if ($scope.Boards[i].id == card.idBoard){
							// card.boardName = $scope.Boards[i].title;
						// }
					// }
				// });
				
				// // process cards, filter cards that are open or closed in the past 30 days
				// var processedFilteredSortedCards = _.filter(processedCards, function(card){
					// return !card.closedDate || card.closedDate > globals.oneMonthAgoDate;
				// });
				
				// var earliestCreatedDate = _.chain(processedFilteredSortedCards).pluck('createdDate').min().value();
				
				// if (earliestCreatedDate.valueOf() < startDate.valueOf())
					// startDate = new Date(earliestCreatedDate.valueOf());
					
				// var latestDueDate = _.chain(processedFilteredSortedCards).filter(function(card){ return card.dueDate; }).pluck('dueDate').max().value();

				// if ( latestDueDate != -Infinity && latestDueDate.valueOf() > endDate.valueOf() )
					// endDate = latestDueDate;		
				
				// drawTable(processedFilteredSortedCards);
			// });
		// });
	// });
// });

// app.controller('TimeTracking', function($scope, $http){
	// $("#mainNav > li").removeClass('active');
	// $("#timeTrackingNav").addClass('active');
	// $scope.Cards = []
	// //var plot1 = $.jqplot ('chart', [[3,7,9,1,4,6,8,2,5]]);
	// var scopeVals = [];
	// var hoursVals = [];
	// var scopeTotal = 0;
	// var callbackCnt = 0;
	// var lastDate = new Date();
	
	// _.each($scope.Boards, function(board){
		// $http.post('trello_proxy.php',{'Url': '/boards/'+board.id+'/lists'}).success(function(lists){
			// $scope.Lists = lists;
			// $http.post('trello_proxy.php', {'Url': '/boards/'+board.id+'/cards', 'Options': 'filter=all&members=true&actions=commentCard,createCard,updateCard:closed'}).success(function(cards){
			
				// $scope.Cards = $scope.Cards.concat(globals.processCardsAndLists(cards, lists));
				// _.each($scope.Cards,function(card){
					// //scopeTotal += parseInt(card.scope);
					// hoursVals = hoursVals.concat(card.hoursArray);
					// if (card.dueDate)
						// scopeVals = scopeVals.concat([[card.dueDate, parseInt(card.scope)]]);
				// });
				
				// callbackCnt++;
				// if (callbackCnt == $scope.Boards.length){
					// $.jqplot ('chart', [scopeVals, hoursVals],{
						// title:'Actual Hours vs Estimated Optimizations/General Requests/Projects',
						// series: [
							// { label: 'Scoped Hours' },
							// { label: 'Actual Hours' }
						// ],
						// axes:{
							// yaxis:{
							  // label:'Hours'
							// },
							// xaxis:{
							  // label:'Date',
							  // renderer:$.jqplot.DateAxisRenderer,
							  // tickOptions:{
								// formatString:'%b&nbsp;%#d&nbsp;%y'
							  // } 
							// },
						// },
					  // highlighter: {
						// show: true,
						// sizeAdjust: 7.5
					  // },
					  // cursor: {
						// show: false
					  // }, 
					  // legend: { show:true, location: 'e' }
					// });
				// }

			// });
		// });
	// });
// });
